/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.config;

import com.laprizmo.core.CryptoEngine;

import java.io.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Менеджер конфигурации приложения.
 * Обеспечивает загрузку, сохранение и доступ к настройкам приложения.
 */
public class ConfigManager {
    
    private static final Logger LOGGER = Logger.getLogger(ConfigManager.class.getName());
    
    // Название файла конфигурации
    private static final String CONFIG_FILENAME = "l2crypt.properties";
    
    // Ключи свойств конфигурации
    public static final String CRYPTO_VERSION = "crypto.version";
    public static final String GAME_PATH = "game.path";
    public static final String OUTPUT_PATH = "output.path";
    public static final String SERVER_HOST = "server.host";
    public static final String SERVER_PORT = "server.port";
    public static final String PROXY_PORT = "proxy.port";
    public static final String UI_THEME = "ui.theme";
    public static final String PLUGINS_PATH = "plugins.path";
    public static final String RECENT_FILES = "recent.files";
    public static final String DEBUG_MODE = "debug.mode";
    
    // Значения по умолчанию
    private static final String DEFAULT_CRYPTO_VERSION = CryptoEngine.CryptoVersion.L2VER51X.name();
    private static final String DEFAULT_GAME_PATH = "";
    private static final String DEFAULT_OUTPUT_PATH = "";
    private static final String DEFAULT_SERVER_HOST = "127.0.0.1";
    private static final String DEFAULT_SERVER_PORT = "2106";
    private static final String DEFAULT_PROXY_PORT = "8888";
    private static final String DEFAULT_UI_THEME = "System";
    private static final String DEFAULT_PLUGINS_PATH = "plugins";
    private static final String DEFAULT_RECENT_FILES = "";
    private static final String DEFAULT_DEBUG_MODE = "false";
    
    // Свойства конфигурации
    private final Properties properties = new Properties();
    
    // Файл конфигурации
    private final File configFile;
    
    // Singleton экземпляр
    private static ConfigManager instance;
    
    /**
     * Возвращает экземпляр менеджера конфигурации.
     *
     * @return экземпляр менеджера конфигурации
     */
    public static synchronized ConfigManager getInstance() {
        if (instance == null) {
            instance = new ConfigManager();
        }
        return instance;
    }
    
    /**
     * Создает новый менеджер конфигурации.
     */
    private ConfigManager() {
        // Определяем путь к файлу конфигурации
        String userHome = System.getProperty("user.home");
        File configDir = new File(userHome, ".laprizmo");
        
        // Создаем каталог конфигурации, если он не существует
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
        
        configFile = new File(configDir, CONFIG_FILENAME);
        
        // Загружаем конфигурацию
        loadConfig();
    }
    
    /**
     * Загружает конфигурацию из файла.
     */
    private void loadConfig() {
        // Сначала устанавливаем значения по умолчанию
        setDefaultProperties();
        
        // Затем загружаем значения из файла, если он существует
        if (configFile.exists()) {
            try (FileInputStream fis = new FileInputStream(configFile)) {
                properties.load(fis);
                LOGGER.info("Configuration loaded from " + configFile.getAbsolutePath());
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Error loading configuration", e);
            }
        } else {
            // Создаем файл конфигурации со значениями по умолчанию
            saveConfig();
        }
    }
    
    /**
     * Устанавливает значения свойств по умолчанию.
     */
    private void setDefaultProperties() {
        properties.setProperty(CRYPTO_VERSION, DEFAULT_CRYPTO_VERSION);
        properties.setProperty(GAME_PATH, DEFAULT_GAME_PATH);
        properties.setProperty(OUTPUT_PATH, DEFAULT_OUTPUT_PATH);
        properties.setProperty(SERVER_HOST, DEFAULT_SERVER_HOST);
        properties.setProperty(SERVER_PORT, DEFAULT_SERVER_PORT);
        properties.setProperty(PROXY_PORT, DEFAULT_PROXY_PORT);
        properties.setProperty(UI_THEME, DEFAULT_UI_THEME);
        properties.setProperty(PLUGINS_PATH, DEFAULT_PLUGINS_PATH);
        properties.setProperty(RECENT_FILES, DEFAULT_RECENT_FILES);
        properties.setProperty(DEBUG_MODE, DEFAULT_DEBUG_MODE);
    }
    
    /**
     * Сохраняет конфигурацию в файл.
     */
    public void saveConfig() {
        try (FileOutputStream fos = new FileOutputStream(configFile)) {
            properties.store(fos, "LaPrizmo Configuration");
            LOGGER.info("Configuration saved to " + configFile.getAbsolutePath());
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error saving configuration", e);
        }
    }
    
    /**
     * Возвращает значение свойства.
     *
     * @param key ключ свойства
     * @return значение свойства
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    /**
     * Возвращает значение свойства или значение по умолчанию, если свойство не найдено.
     *
     * @param key          ключ свойства
     * @param defaultValue значение по умолчанию
     * @return значение свойства или значение по умолчанию
     */
    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
    
    /**
     * Устанавливает значение свойства.
     *
     * @param key   ключ свойства
     * @param value значение свойства
     */
    public void setProperty(String key, String value) {
        properties.setProperty(key, value);
    }
    
    /**
     * Возвращает значение свойства как целое число.
     *
     * @param key ключ свойства
     * @return значение свойства как целое число
     * @throws NumberFormatException если значение не является целым числом
     */
    public int getIntProperty(String key) {
        return Integer.parseInt(getProperty(key));
    }
    
    /**
     * Возвращает значение свойства как целое число или значение по умолчанию,
     * если свойство не найдено или не является целым числом.
     *
     * @param key          ключ свойства
     * @param defaultValue значение по умолчанию
     * @return значение свойства как целое число или значение по умолчанию
     */
    public int getIntProperty(String key, int defaultValue) {
        try {
            return Integer.parseInt(getProperty(key));
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
    
    /**
     * Устанавливает значение свойства как целое число.
     *
     * @param key   ключ свойства
     * @param value значение свойства
     */
    public void setIntProperty(String key, int value) {
        setProperty(key, Integer.toString(value));
    }
    
    /**
     * Возвращает значение свойства как логическое значение.
     *
     * @param key ключ свойства
     * @return значение свойства как логическое значение
     */
    public boolean getBooleanProperty(String key) {
        return Boolean.parseBoolean(getProperty(key));
    }
    
    /**
     * Возвращает значение свойства как логическое значение или значение по умолчанию,
     * если свойство не найдено.
     *
     * @param key          ключ свойства
     * @param defaultValue значение по умолчанию
     * @return значение свойства как логическое значение или значение по умолчанию
     */
    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = getProperty(key);
        return value != null ? Boolean.parseBoolean(value) : defaultValue;
    }
    
    /**
     * Устанавливает значение свойства как логическое значение.
     *
     * @param key   ключ свойства
     * @param value значение свойства
     */
    public void setBooleanProperty(String key, boolean value) {
        setProperty(key, Boolean.toString(value));
    }
    
    /**
     * Возвращает версию шифрования.
     *
     * @return версия шифрования
     */
    public CryptoEngine.CryptoVersion getCryptoVersion() {
        String versionName = getProperty(CRYPTO_VERSION);
        try {
            return CryptoEngine.CryptoVersion.valueOf(versionName);
        } catch (IllegalArgumentException e) {
            LOGGER.warning("Invalid crypto version in configuration: " + versionName);
            return CryptoEngine.CryptoVersion.L2VER51X;
        }
    }
    
    /**
     * Устанавливает версию шифрования.
     *
     * @param version версия шифрования
     */
    public void setCryptoVersion(CryptoEngine.CryptoVersion version) {
        setProperty(CRYPTO_VERSION, version.name());
    }
    
    /**
     * Возвращает путь к игровым файлам.
     *
     * @return путь к игровым файлам
     */
    public String getGamePath() {
        return getProperty(GAME_PATH);
    }
    
    /**
     * Устанавливает путь к игровым файлам.
     *
     * @param path путь к игровым файлам
     */
    public void setGamePath(String path) {
        setProperty(GAME_PATH, path);
    }
    
    /**
     * Возвращает путь к выходным файлам.
     *
     * @return путь к выходным файлам
     */
    public String getOutputPath() {
        return getProperty(OUTPUT_PATH);
    }
    
    /**
     * Устанавливает путь к выходным файлам.
     *
     * @param path путь к выходным файлам
     */
    public void setOutputPath(String path) {
        setProperty(OUTPUT_PATH, path);
    }
    
    /**
     * Возвращает хост сервера.
     *
     * @return хост сервера
     */
    public String getServerHost() {
        return getProperty(SERVER_HOST);
    }
    
    /**
     * Устанавливает хост сервера.
     *
     * @param host хост сервера
     */
    public void setServerHost(String host) {
        setProperty(SERVER_HOST, host);
    }
    
    /**
     * Возвращает порт сервера.
     *
     * @return порт сервера
     */
    public int getServerPort() {
        return getIntProperty(SERVER_PORT, Integer.parseInt(DEFAULT_SERVER_PORT));
    }
    
    /**
     * Устанавливает порт сервера.
     *
     * @param port порт сервера
     */
    public void setServerPort(int port) {
        setIntProperty(SERVER_PORT, port);
    }
    
    /**
     * Возвращает порт прокси.
     *
     * @return порт прокси
     */
    public int getProxyPort() {
        return getIntProperty(PROXY_PORT, Integer.parseInt(DEFAULT_PROXY_PORT));
    }
    
    /**
     * Устанавливает порт прокси.
     *
     * @param port порт прокси
     */
    public void setProxyPort(int port) {
        setIntProperty(PROXY_PORT, port);
    }
    
    /**
     * Возвращает тему пользовательского интерфейса.
     *
     * @return тема пользовательского интерфейса
     */
    public String getUITheme() {
        return getProperty(UI_THEME);
    }
    
    /**
     * Устанавливает тему пользовательского интерфейса.
     *
     * @param theme тема пользовательского интерфейса
     */
    public void setUITheme(String theme) {
        setProperty(UI_THEME, theme);
    }
    
    /**
     * Возвращает путь к каталогу с плагинами.
     *
     * @return путь к каталогу с плагинами
     */
    public String getPluginsPath() {
        return getProperty(PLUGINS_PATH);
    }
    
    /**
     * Устанавливает путь к каталогу с плагинами.
     *
     * @param path путь к каталогу с плагинами
     */
    public void setPluginsPath(String path) {
        setProperty(PLUGINS_PATH, path);
    }
    
    /**
     * Возвращает список недавно использованных файлов.
     *
     * @return список недавно использованных файлов
     */
    public String[] getRecentFiles() {
        String recentFiles = getProperty(RECENT_FILES);
        if (recentFiles == null || recentFiles.isEmpty()) {
            return new String[0];
        }
        return recentFiles.split(";");
    }
    
    /**
     * Добавляет файл в список недавно использованных файлов.
     *
     * @param filePath путь к файлу
     */
    public void addRecentFile(String filePath) {
        String[] recentFiles = getRecentFiles();
        
        // Проверяем, есть ли уже этот файл в списке
        boolean exists = false;
        for (String path : recentFiles) {
            if (path.equals(filePath)) {
                exists = true;
                break;
            }
        }
        
        if (!exists) {
            // Добавляем новый файл в начало списка
            StringBuilder sb = new StringBuilder();
            sb.append(filePath);
            
            // Добавляем остальные файлы, ограничивая список 10 элементами
            for (int i = 0; i < recentFiles.length && i < 9; i++) {
                sb.append(";").append(recentFiles[i]);
            }
            
            setProperty(RECENT_FILES, sb.toString());
        }
    }
    
    /**
     * Возвращает режим отладки.
     *
     * @return true, если режим отладки включен
     */
    public boolean isDebugMode() {
        return getBooleanProperty(DEBUG_MODE);
    }
    
    /**
     * Устанавливает режим отладки.
     *
     * @param debugMode режим отладки
     */
    public void setDebugMode(boolean debugMode) {
        setBooleanProperty(DEBUG_MODE, debugMode);
    }
}
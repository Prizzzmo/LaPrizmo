/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Расширение OutputStream, добавляющее метод finish() для завершения шифрования.
 * Используется в алгоритмах шифрования, которые требуют дополнительной обработки данных
 * в конце потока (например, добавление padding или запись заключительных блоков).
 */
public abstract class FinishableOutputStream extends OutputStream {
    
    /**
     * Завершает шифрование и записывает заключительные данные в выходной поток.
     * Этот метод должен быть вызван перед закрытием потока для корректного завершения шифрования.
     *
     * @throws IOException если возникла ошибка ввода/вывода
     */
    public abstract void finish() throws IOException;
    
    /**
     * Записывает указанный байт в выходной поток.
     *
     * @param b байт для записи
     * @throws IOException если возникла ошибка ввода/вывода
     */
    @Override
    public abstract void write(int b) throws IOException;
    
    /**
     * Записывает указанный массив байт в выходной поток.
     *
     * @param b массив байт для записи
     * @throws IOException если возникла ошибка ввода/вывода
     */
    @Override
    public void write(byte[] b) throws IOException {
        write(b, 0, b.length);
    }
    
    /**
     * Записывает указанную часть массива байт в выходной поток.
     *
     * @param b   массив байт для записи
     * @param off начальная позиция в массиве
     * @param len количество байт для записи
     * @throws IOException если возникла ошибка ввода/вывода
     */
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        for (int i = 0; i < len; i++) {
            write(b[off + i]);
        }
    }
    
    /**
     * Закрывает выходной поток и освобождает связанные с ним ресурсы.
     * Этот метод автоматически вызывает метод finish() перед закрытием потока.
     *
     * @throws IOException если возникла ошибка ввода/вывода
     */
    @Override
    public void close() throws IOException {
        try {
            finish();
        } finally {
            super.close();
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import com.laprizmo.crypto.CryptoException;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Входной поток для чтения данных, зашифрованных с помощью RSA.
 */
public class RSAInputStream extends FilterInputStream {
    
    private static final Logger LOGGER = Logger.getLogger(RSAInputStream.class.getName());
    
    // Движок RSA
    private final RSAEngine engine;
    
    // Размер блока RSA в байтах
    private final int blockSize;
    
    // Буфер для расшифрованных данных
    private byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    // Количество доступных байт в буфере
    private int bufferAvailable;
    
    // Флаг конца потока
    private boolean endOfStream;
    
    /**
     * Создает новый входной поток для чтения зашифрованных данных.
     *
     * @param in     базовый входной поток с зашифрованными данными
     * @param engine движок RSA
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public RSAInputStream(InputStream in, RSAEngine engine) throws CryptoException {
        super(in);
        
        this.engine = engine;
        this.blockSize = (engine.getPublicKey().getModulus().bitLength() + 7) / 8;
        
        this.buffer = new byte[0];
        this.bufferPos = 0;
        this.bufferAvailable = 0;
        this.endOfStream = false;
    }
    
    @Override
    public int read() throws IOException {
        if (bufferPos >= bufferAvailable) {
            if (endOfStream) {
                return -1;
            }
            fillBuffer();
            if (bufferAvailable == 0) {
                return -1;
            }
        }
        
        return buffer[bufferPos++] & 0xFF;
    }
    
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        }
        
        if (len == 0) {
            return 0;
        }
        
        if (endOfStream && bufferPos >= bufferAvailable) {
            return -1;
        }
        
        int bytesRead = 0;
        
        while (bytesRead < len) {
            if (bufferPos >= bufferAvailable) {
                fillBuffer();
                if (bufferAvailable == 0) {
                    break;
                }
            }
            
            int available = Math.min(bufferAvailable - bufferPos, len - bytesRead);
            System.arraycopy(buffer, bufferPos, b, off + bytesRead, available);
            
            bufferPos += available;
            bytesRead += available;
        }
        
        return bytesRead > 0 ? bytesRead : -1;
    }
    
    /**
     * Заполняет буфер расшифрованными данными.
     *
     * @throws IOException если возникла ошибка ввода-вывода
     */
    private void fillBuffer() throws IOException {
        if (endOfStream) {
            bufferAvailable = 0;
            return;
        }
        
        try {
            // Сначала считываем размер блока RSA
            byte[] encryptedBlock = new byte[blockSize];
            int bytesRead = 0;
            
            // Читаем полный блок
            while (bytesRead < blockSize) {
                int read = in.read(encryptedBlock, bytesRead, blockSize - bytesRead);
                if (read == -1) {
                    if (bytesRead == 0) {
                        // Если ничего не прочитано, значит конец потока
                        endOfStream = true;
                        bufferAvailable = 0;
                        return;
                    } else {
                        // Если прочитана только часть блока, значит ошибка
                        throw new IOException("Incomplete RSA block read: " + bytesRead + " bytes");
                    }
                }
                bytesRead += read;
            }
            
            // Расшифровываем блок
            buffer = engine.decrypt(encryptedBlock);
            bufferPos = 0;
            bufferAvailable = buffer.length;
        } catch (CryptoException e) {
            LOGGER.log(Level.SEVERE, "Error decrypting RSA block", e);
            throw new IOException("Error decrypting RSA block: " + e.getMessage(), e);
        }
    }
    
    @Override
    public long skip(long n) throws IOException {
        if (n <= 0) {
            return 0;
        }
        
        long skipped = 0;
        while (skipped < n) {
            if (bufferPos >= bufferAvailable) {
                fillBuffer();
                if (bufferAvailable == 0) {
                    break;
                }
            }
            
            long available = Math.min(bufferAvailable - bufferPos, n - skipped);
            bufferPos += available;
            skipped += available;
        }
        
        return skipped;
    }
    
    @Override
    public int available() throws IOException {
        return bufferAvailable - bufferPos;
    }
    
    @Override
    public void close() throws IOException {
        in.close();
    }
    
    @Override
    public synchronized void mark(int readlimit) {
        // Не поддерживается
    }
    
    @Override
    public synchronized void reset() throws IOException {
        throw new IOException("Mark/reset not supported");
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
}
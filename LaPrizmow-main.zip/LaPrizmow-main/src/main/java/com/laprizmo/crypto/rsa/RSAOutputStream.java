/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Выходной поток для записи данных с шифрованием RSA.
 */
public class RSAOutputStream extends FinishableOutputStream {
    
    private static final Logger LOGGER = Logger.getLogger(RSAOutputStream.class.getName());
    
    // Движок RSA
    private final RSAEngine engine;
    
    // Выходной поток для записи зашифрованных данных
    private final OutputStream out;
    
    // Размер блока для шифрования
    private final int blockSize;
    
    // Буфер для накопления данных перед шифрованием
    private byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    // Флаг, указывающий, был ли поток закрыт
    private boolean closed;
    
    /**
     * Создает новый выходной поток для записи данных с шифрованием.
     *
     * @param out    базовый выходной поток для записи зашифрованных данных
     * @param engine движок RSA
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public RSAOutputStream(OutputStream out, RSAEngine engine) throws CryptoException {
        super(out);
        
        this.out = out;
        this.engine = engine;
        this.blockSize = engine.getBlockSize();
        
        this.buffer = new byte[blockSize];
        this.bufferPos = 0;
        this.closed = false;
    }
    
    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        buffer[bufferPos++] = (byte) b;
        
        if (bufferPos == blockSize) {
            encryptAndWrite();
        }
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        if (b == null) {
            throw new NullPointerException();
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        }
        
        int bytesWritten = 0;
        
        while (bytesWritten < len) {
            int available = Math.min(blockSize - bufferPos, len - bytesWritten);
            System.arraycopy(b, off + bytesWritten, buffer, bufferPos, available);
            
            bufferPos += available;
            bytesWritten += available;
            
            if (bufferPos == blockSize) {
                encryptAndWrite();
            }
        }
    }
    
    /**
     * Шифрует данные из буфера и записывает их в выходной поток.
     *
     * @throws IOException если возникла ошибка ввода-вывода
     */
    private void encryptAndWrite() throws IOException {
        if (bufferPos == 0) {
            return;
        }
        
        try {
            // Если буфер заполнен не полностью, создаем временный буфер нужного размера
            byte[] dataToEncrypt;
            if (bufferPos < blockSize) {
                dataToEncrypt = new byte[bufferPos];
                System.arraycopy(buffer, 0, dataToEncrypt, 0, bufferPos);
            } else {
                dataToEncrypt = buffer;
            }
            
            // Шифруем данные
            byte[] encryptedData = engine.encrypt(dataToEncrypt);
            
            // Записываем зашифрованные данные в выходной поток
            out.write(encryptedData);
            
            // Сбрасываем позицию буфера
            bufferPos = 0;
        } catch (CryptoException e) {
            LOGGER.log(Level.SEVERE, "Error encrypting data", e);
            throw new IOException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void flush() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        out.flush();
    }
    
    @Override
    public void finish() throws IOException {
        if (closed) {
            return;
        }
        
        // Шифруем и записываем оставшиеся данные в буфере
        if (bufferPos > 0) {
            encryptAndWrite();
        }
        
        out.flush();
    }
    
    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        try {
            finish();
        } finally {
            closed = true;
            out.close();
        }
    }
}
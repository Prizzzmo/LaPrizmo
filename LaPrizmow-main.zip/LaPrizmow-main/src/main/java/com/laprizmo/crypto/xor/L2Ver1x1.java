/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Константы и методы для работы с алгоритмом XOR в файлах Lineage 2 версии 1.x.1
 */
public interface L2Ver1x1 {
    /**
     * Статический ключ XOR для версии 1.1.1
     */
    byte[] XOR_KEY_111 = {
        (byte) 0xc7, (byte) 0x83, (byte) 0x54, (byte) 0x5a, (byte) 0xd3, (byte) 0x94, (byte) 0xd8, (byte) 0x8d
    };

    /**
     * Генерирует динамический ключ XOR для версии 1.2.1 на основе имени файла.
     *
     * @param fileName имя файла, используемое для генерации ключа
     * @return сгенерированный ключ XOR
     */
    static byte[] getXORKey121(String fileName) {
        try {
            // Хеш SHA-1 от имени файла
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            byte[] nameBytes = fileName.getBytes(StandardCharsets.UTF_8);
            byte[] hashBytes = digest.digest(nameBytes);

            // Генерируем XOR ключ длиной 8 байт на основе хеша
            byte[] key = new byte[8];
            for (int i = 0; i < 8; i++) {
                key[i] = hashBytes[i % hashBytes.length];
            }
            return key;
        } catch (NoSuchAlgorithmException e) {
            // Если SHA-1 не доступен, используем простой метод генерации ключа
            byte[] key = new byte[8];
            byte[] nameBytes = fileName.getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < 8; i++) {
                int idx = i % nameBytes.length;
                key[i] = (byte) (nameBytes[idx] ^ (i + 1));
            }
            return key;
        }
    }

    /**
     * Генерирует динамический ключ XOR для версии 1.2.1 на основе файла.
     *
     * @param file файл, используемый для генерации ключа
     * @return сгенерированный ключ XOR
     */
    static byte[] getXORKey121(File file) {
        return getXORKey121(file.getName());
    }
}
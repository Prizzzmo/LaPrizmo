/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.aes;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/**
 * Реализация алгоритма шифрования Lineage 2 версии 5.1.x.
 * Использует AES-128 в режиме CBC с PKCS5Padding.
 */
public class L2Ver51x {
    
    // AES параметры
    private static final String AES_TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final String AES_ALGORITHM = "AES";
    private static final int AES_BLOCK_SIZE = 16; // 128 бит = 16 байт
    
    // Стандартный ключ для версии 5.1.x
    private static final byte[] DEFAULT_KEY = {
        (byte) 0xA8, (byte) 0x25, (byte) 0x6F, (byte) 0xD5,
        (byte) 0x07, (byte) 0xC7, (byte) 0x19, (byte) 0x40,
        (byte) 0xD2, (byte) 0x93, (byte) 0xE9, (byte) 0x79,
        (byte) 0x5F, (byte) 0x8C, (byte) 0xB2, (byte) 0x04
    };
    
    // Вектор инициализации по умолчанию
    private static final byte[] DEFAULT_IV = {
        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
    };
    
    // Ключ шифрования и вектор инициализации
    private final byte[] key;
    private final byte[] iv;
    
    // Шифры для шифрования и дешифрования
    private Cipher encryptCipher;
    private Cipher decryptCipher;
    
    /**
     * Создает новый объект шифрования с ключом и вектором инициализации по умолчанию.
     */
    public L2Ver51x() {
        this(DEFAULT_KEY, DEFAULT_IV);
    }
    
    /**
     * Создает новый объект шифрования с указанным ключом и вектором инициализации по умолчанию.
     *
     * @param key ключ шифрования (должен быть 16, 24 или 32 байта для AES-128, AES-192 или AES-256)
     */
    public L2Ver51x(byte[] key) {
        this(key, DEFAULT_IV);
    }
    
    /**
     * Создает новый объект шифрования с указанным ключом и вектором инициализации.
     *
     * @param key ключ шифрования (должен быть 16, 24 или 32 байта для AES-128, AES-192 или AES-256)
     * @param iv  вектор инициализации (должен быть 16 байт)
     */
    public L2Ver51x(byte[] key, byte[] iv) {
        if (key == null || (key.length != 16 && key.length != 24 && key.length != 32)) {
            throw new IllegalArgumentException("Key must be 16, 24 or 32 bytes for AES-128, AES-192 or AES-256");
        }
        if (iv == null || iv.length != 16) {
            throw new IllegalArgumentException("IV must be 16 bytes");
        }
        
        this.key = Arrays.copyOf(key, key.length);
        this.iv = Arrays.copyOf(iv, iv.length);
        
        initCiphers();
    }
    
    /**
     * Инициализирует шифры.
     */
    private void initCiphers() {
        try {
            // Создаем ключ и параметры
            SecretKey secretKey = new SecretKeySpec(key, AES_ALGORITHM);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            
            // Инициализируем шифр для шифрования
            encryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
            encryptCipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
            
            // Инициализируем шифр для дешифрования
            decryptCipher = Cipher.getInstance(AES_TRANSFORMATION);
            decryptCipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | 
                 InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new RuntimeException("Failed to initialize AES ciphers", e);
        }
    }
    
    /**
     * Шифрует массив байт.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        try {
            return encryptCipher.doFinal(data);
        } catch (Exception e) {
            throw new CryptoException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Дешифрует массив байт.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        try {
            return decryptCipher.doFinal(data);
        } catch (Exception e) {
            throw new CryptoException("Error decrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Создает входной поток для дешифрования.
     *
     * @param in входной поток с зашифрованными данными
     * @return входной поток с дешифрованными данными
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public InputStream getDecryptionInputStream(InputStream in) throws CryptoException {
        return new L2Ver51xInputStream(in, this);
    }
    
    /**
     * Создает выходной поток для шифрования.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public OutputStream getEncryptionOutputStream(OutputStream out) throws CryptoException {
        return new L2Ver51xOutputStream(out, this);
    }
    
    /**
     * Возвращает используемый ключ шифрования.
     *
     * @return ключ шифрования
     */
    public byte[] getKey() {
        return Arrays.copyOf(key, key.length);
    }
    
    /**
     * Возвращает используемый вектор инициализации.
     *
     * @return вектор инициализации
     */
    public byte[] getIV() {
        return Arrays.copyOf(iv, iv.length);
    }
    
    /**
     * Возвращает размер блока шифрования.
     *
     * @return размер блока в байтах
     */
    public int getBlockSize() {
        return AES_BLOCK_SIZE;
    }
    
    /**
     * Получает шифр для шифрования.
     *
     * @return шифр для шифрования
     */
    protected Cipher getEncryptCipher() {
        return encryptCipher;
    }
    
    /**
     * Получает шифр для дешифрования.
     *
     * @return шифр для дешифрования
     */
    protected Cipher getDecryptCipher() {
        return decryptCipher;
    }
}
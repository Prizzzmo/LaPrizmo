/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.FinishableOutputStream;
import com.laprizmo.crypto.xor.L2Ver111.L2Ver1x1;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Выходной поток для шифрования данных Lineage 2 версии 1.x.1 с использованием XOR.
 */
public final class L2Ver1x1OutputStream extends FinishableOutputStream implements L2Ver1x1 {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver1x1OutputStream.class.getName());
    
    private final OutputStream out;
    private final byte[] key;
    private int keyIndex = 0;
    private boolean closed = false;

    /**
     * Создает новый шифрующий поток XOR.
     *
     * @param output выходной поток для записи зашифрованных данных
     * @param key    ключ XOR для шифрования
     */
    public L2Ver1x1OutputStream(OutputStream output, byte[] key) {
        super(output);
        
        this.out = Objects.requireNonNull(output, "output stream cannot be null");
        
        if (key == null || key.length == 0) {
            throw new IllegalArgumentException("XOR key cannot be null or empty");
        }
        
        this.key = key.clone();
    }

    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        // Шифруем байт с помощью XOR и текущего байта ключа
        int encrypted = b ^ key[keyIndex];
        keyIndex = (keyIndex + 1) % key.length;
        
        out.write(encrypted);
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        // Буфер для зашифрованных данных
        byte[] encryptedBuffer = new byte[len];
        
        // Шифруем данные
        for (int i = 0; i < len; i++) {
            encryptedBuffer[i] = (byte) (b[off + i] ^ key[keyIndex]);
            keyIndex = (keyIndex + 1) % key.length;
        }
        
        // Записываем зашифрованные данные
        out.write(encryptedBuffer, 0, len);
    }
    
    @Override
    public void flush() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        out.flush();
    }
    
    @Override
    public void finish() throws IOException {
        if (closed) {
            return;
        }
        
        out.flush();
    }
    
    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        try {
            finish();
        } finally {
            closed = true;
            out.close();
        }
    }
}
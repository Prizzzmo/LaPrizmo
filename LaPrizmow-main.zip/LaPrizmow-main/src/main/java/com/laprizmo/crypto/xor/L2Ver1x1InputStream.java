/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.xor.L2Ver111.L2Ver1x1;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Входной поток для дешифрования данных Lineage 2 версии 1.x.1 с использованием XOR.
 */
public final class L2Ver1x1InputStream extends FilterInputStream implements L2Ver1x1 {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver1x1InputStream.class.getName());
    
    private final byte[] key;
    private int keyIndex = 0;

    /**
     * Создает новый дешифрующий поток XOR.
     *
     * @param input входной поток с зашифрованными данными
     * @param key   ключ XOR для дешифрования
     */
    public L2Ver1x1InputStream(InputStream input, byte[] key) {
        super(Objects.requireNonNull(input, "input stream cannot be null"));
        
        if (key == null || key.length == 0) {
            throw new IllegalArgumentException("XOR key cannot be null or empty");
        }
        
        this.key = key.clone();
    }

    @Override
    public int read() throws IOException {
        int value = in.read();
        if (value == -1) {
            return -1;
        }
        
        // Применяем XOR с текущим байтом ключа и переходим к следующему
        int decrypted = value ^ key[keyIndex];
        keyIndex = (keyIndex + 1) % key.length;
        
        return decrypted & 0xFF;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        if (len == 0) {
            return 0;
        }
        
        int bytesRead = in.read(b, off, len);
        if (bytesRead == -1) {
            return -1;
        }
        
        // Дешифруем все прочитанные байты
        for (int i = 0; i < bytesRead; i++) {
            b[off + i] = (byte) (b[off + i] ^ key[keyIndex]);
            keyIndex = (keyIndex + 1) % key.length;
        }
        
        return bytesRead;
    }
    
    @Override
    public long skip(long n) throws IOException {
        // При пропуске данных нужно также пропустить соответствующее количество байтов ключа
        long skipped = in.skip(n);
        keyIndex = (int) ((keyIndex + skipped) % key.length);
        return skipped;
    }
    
    @Override
    public void close() throws IOException {
        in.close();
    }
    
    @Override
    public synchronized void mark(int readlimit) {
        throw new UnsupportedOperationException("Mark not supported");
    }
    
    @Override
    public synchronized void reset() throws IOException {
        throw new UnsupportedOperationException("Reset not supported");
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
}
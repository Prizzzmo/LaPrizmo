/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.blowfish;

import java.io.IOException;
import java.io.InputStream;

/**
 * Входной поток для дешифрования данных, зашифрованных алгоритмом Lineage 2 версии 2.1.x (Blowfish).
 * Поддерживает потоковое дешифрование блоков данных.
 */
public class L2Ver21xInputStream extends InputStream {
    
    // Размер блока данных
    private static final int BLOCK_SIZE = 8;
    
    // Входной поток с зашифрованными данными
    private final InputStream in;
    
    // Движок Blowfish
    private final BlowfishEngine engine;
    
    // Буфер для дешифрованных данных
    private byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    // Размер буфера (количество валидных байт)
    private int bufferSize;
    
    // Флаг конца потока
    private boolean endOfStream;
    
    /**
     * Создает новый входной поток для дешифрования.
     *
     * @param in     входной поток с зашифрованными данными
     * @param engine движок Blowfish
     */
    public L2Ver21xInputStream(InputStream in, BlowfishEngine engine) {
        this.in = in;
        this.engine = engine;
        this.buffer = new byte[0];
        this.bufferPos = 0;
        this.bufferSize = 0;
        this.endOfStream = false;
    }
    
    @Override
    public int read() throws IOException {
        if (bufferPos >= bufferSize) {
            if (endOfStream) {
                return -1;
            }
            fillBuffer();
            if (bufferSize == 0) {
                return -1;
            }
        }
        
        return buffer[bufferPos++] & 0xFF;
    }
    
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        }
        
        if (len == 0) {
            return 0;
        }
        
        // Проверяем, нужно ли заполнить буфер
        if (bufferPos >= bufferSize) {
            if (endOfStream) {
                return -1;
            }
            fillBuffer();
            if (bufferSize == 0) {
                return -1;
            }
        }
        
        // Определяем, сколько байт можно прочитать
        int bytesToRead = Math.min(len, bufferSize - bufferPos);
        System.arraycopy(buffer, bufferPos, b, off, bytesToRead);
        bufferPos += bytesToRead;
        
        return bytesToRead;
    }
    
    /**
     * Заполняет буфер дешифрованными данными.
     */
    private void fillBuffer() throws IOException {
        // Читаем блок зашифрованных данных
        byte[] encryptedBlock = new byte[BLOCK_SIZE];
        int bytesRead = in.read(encryptedBlock);
        
        if (bytesRead == -1) {
            // Конец входного потока
            endOfStream = true;
            bufferSize = 0;
            return;
        }
        
        if (bytesRead < BLOCK_SIZE) {
            // Неполный блок, дополняем нулями
            for (int i = bytesRead; i < BLOCK_SIZE; i++) {
                encryptedBlock[i] = 0;
            }
        }
        
        try {
            // Дешифруем блок
            byte[] decryptedBlock = engine.decryptBlock(encryptedBlock);
            buffer = decryptedBlock;
            bufferPos = 0;
            bufferSize = decryptedBlock.length;
        } catch (Exception e) {
            throw new IOException("Error decrypting data: " + e.getMessage(), e);
        }
    }
    
    @Override
    public long skip(long n) throws IOException {
        if (n <= 0) {
            return 0;
        }
        
        long remaining = n;
        while (remaining > 0) {
            if (bufferPos >= bufferSize) {
                if (endOfStream) {
                    break;
                }
                fillBuffer();
                if (bufferSize == 0) {
                    break;
                }
            }
            
            long skip = Math.min(remaining, bufferSize - bufferPos);
            bufferPos += skip;
            remaining -= skip;
        }
        
        return n - remaining;
    }
    
    @Override
    public int available() throws IOException {
        return bufferSize - bufferPos;
    }
    
    @Override
    public void close() throws IOException {
        in.close();
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
}
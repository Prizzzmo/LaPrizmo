/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

/**
 * Расширенная конфигурация для RSA шифрования.
 * Предоставляет расширенную поддержку ключей для разных версий протоколов Lineage 2.
 * Включает дополнительные ключи из open-l2encdec.
 */
public class EnhancedRSAConfig extends RSAConfig {
    
    // Дополнительные модули для различных клиентов
    private static final Map<Integer, String> ADDITIONAL_CLIENT_MODULUS = new HashMap<>();
    
    // Дополнительные экспоненты для различных клиентов
    private static final Map<Integer, String> ADDITIONAL_CLIENT_EXPONENT = new HashMap<>();
    
    static {
        // Модуль для протокола 413 (Gracia Final)
        ADDITIONAL_CLIENT_MODULUS.put(413, 
            "75b4d6de5c016dc1db60a8141b2c12bdb9d7ee4edf371e80438585717f5d7e602a0dd359644b2471332f4b0da424b83f2b" +
            "07849a83c4bcd150428ddb624ad1b3a1ed1fd83af1b550c2beef6bc5bd92fec5a3214fafb94dedaee7c3f3ecbb505f2e7a" +
            "dfcd59d7583b22214eb8763923923a97d0f3ae100cc1339df905cde9e8ba");
            
        // Экспонента для протокола 413 (Gracia Final)
        ADDITIONAL_CLIENT_EXPONENT.put(413, "1d");
        
        // Модуль для протокола 414 (Gracia Epilogue)
        ADDITIONAL_CLIENT_MODULUS.put(414, 
            "a1f9299d32f2959e1baea91e9fd1e8eb6ba7ebcd35e9ba20966f96d6b9dd9d9e16cf0b66c4acea79379a75ad61eddfc8d0" +
            "7a5cecf9c7894db610aae917d0c88b1df6e8111bc36d324dbe9b77ba346e56c33aab20521d8864efa547b795d59a21447a" +
            "ef8061616a1a55bee2c296df31f83c483ca2595bd16afef301937f2df19a9");
            
        // Экспонента для протокола 414 (Gracia Epilogue)
        ADDITIONAL_CLIENT_EXPONENT.put(414, "1d");
        
        // Модуль для протокола 416 (Freya)
        ADDITIONAL_CLIENT_MODULUS.put(416, 
            "a9cdb1fe14cdbe58bc9b68cc9e756a89cc583342c4ade533a5c48490909af774d63969cb683598cc8e9242691c680c826f" +
            "cb9e15249f246566a11e540d9b9b86cee5081b0709a9e05ef5d07d3478f9952e7feaab59d9a9f47a11b110f5b888abf599" +
            "9d384cfcfb05b7ae49f1c46a1a3e645cc9dde5da99c3aef9c9104e29e072");
            
        // Экспонента для протокола 416 (Freya)
        ADDITIONAL_CLIENT_EXPONENT.put(416, "25");
    }
    
    /**
     * Создает новую конфигурацию с заданными параметрами.
     *
     * @param modulus модуль в шестнадцатеричном виде
     * @param exponent экспонента в шестнадцатеричном виде
     * @param protocol версия протокола (для выбора блока обфускации)
     */
    public EnhancedRSAConfig(String modulus, String exponent, int protocol) {
        super(modulus, exponent, protocol);
    }
    
    /**
     * Создает новую конфигурацию с заданными параметрами в виде BigInteger.
     *
     * @param modulus модуль
     * @param exponent экспонента
     * @param protocol версия протокола (для выбора блока обфускации)
     */
    public EnhancedRSAConfig(BigInteger modulus, BigInteger exponent, int protocol) {
        super(modulus, exponent, protocol);
    }
    
    /**
     * Возвращает конфигурацию для указанного протокола.
     *
     * @param protocol версия протокола
     * @param useLegacy использовать ли устаревшие ключи
     * @return конфигурация для указанного протокола
     */
    public static RSAConfig getForProtocol(int protocol, boolean useLegacy) {
        // Проверяем наличие дополнительных ключей для протокола
        if (ADDITIONAL_CLIENT_MODULUS.containsKey(protocol) && ADDITIONAL_CLIENT_EXPONENT.containsKey(protocol)) {
            return new EnhancedRSAConfig(
                    ADDITIONAL_CLIENT_MODULUS.get(protocol),
                    ADDITIONAL_CLIENT_EXPONENT.get(protocol),
                    protocol);
        }
        
        // Если дополнительных ключей нет, используем стандартные
        return RSAConfig.getForProtocol(protocol, useLegacy);
    }
    
    /**
     * Возвращает все доступные протоколы с расширенными ключами.
     *
     * @return массив версий протоколов
     */
    public static int[] getSupportedProtocols() {
        // Объединяем стандартные и дополнительные протоколы
        int[] baseProtocols = {411, 412, 413, 414};
        int[] additionalProtocols = ADDITIONAL_CLIENT_MODULUS.keySet().stream()
                .mapToInt(Integer::intValue)
                .toArray();
        
        // Объединяем массивы
        int[] result = new int[baseProtocols.length + additionalProtocols.length];
        System.arraycopy(baseProtocols, 0, result, 0, baseProtocols.length);
        System.arraycopy(additionalProtocols, 0, result, baseProtocols.length, additionalProtocols.length);
        
        return result;
    }
    
    /**
     * Добавляет пользовательскую конфигурацию для протокола.
     *
     * @param protocol версия протокола
     * @param modulus модуль в шестнадцатеричном виде
     * @param exponent экспонента в шестнадцатеричном виде
     */
    public static void addCustomConfig(int protocol, String modulus, String exponent) {
        if (protocol >= 400 && protocol < 500) {
            ADDITIONAL_CLIENT_MODULUS.put(protocol, modulus);
            ADDITIONAL_CLIENT_EXPONENT.put(protocol, exponent);
        }
    }
    
    /**
     * Удаляет пользовательскую конфигурацию для протокола.
     *
     * @param protocol версия протокола
     * @return true, если конфигурация была удалена
     */
    public static boolean removeCustomConfig(int protocol) {
        if (ADDITIONAL_CLIENT_MODULUS.containsKey(protocol) && ADDITIONAL_CLIENT_EXPONENT.containsKey(protocol)) {
            ADDITIONAL_CLIENT_MODULUS.remove(protocol);
            ADDITIONAL_CLIENT_EXPONENT.remove(protocol);
            return true;
        }
        return false;
    }
    
    /**
     * Проверяет, существует ли конфигурация для протокола.
     *
     * @param protocol версия протокола
     * @return true, если конфигурация существует
     */
    public static boolean hasConfigForProtocol(int protocol) {
        return ADDITIONAL_CLIENT_MODULUS.containsKey(protocol) || (protocol >= 411 && protocol <= 414);
    }
    
    /**
     * Возвращает модуль для протокола.
     *
     * @param protocol версия протокола
     * @return модуль в шестнадцатеричном виде или null, если протокол не поддерживается
     */
    public static String getModulusForProtocol(int protocol) {
        if (ADDITIONAL_CLIENT_MODULUS.containsKey(protocol)) {
            return ADDITIONAL_CLIENT_MODULUS.get(protocol);
        }
        
        // Возвращаем стандартный модуль
        switch (protocol) {
            case 411:
                return N_411_STRING;
            case 412:
                return N_412_STRING;
            case 413:
                return N_413_STRING;
            case 414:
                return N_414_STRING;
            default:
                return null;
        }
    }
    
    /**
     * Возвращает экспоненту для протокола.
     *
     * @param protocol версия протокола
     * @return экспонента в шестнадцатеричном виде или null, если протокол не поддерживается
     */
    public static String getExponentForProtocol(int protocol) {
        if (ADDITIONAL_CLIENT_EXPONENT.containsKey(protocol)) {
            return ADDITIONAL_CLIENT_EXPONENT.get(protocol);
        }
        
        // Возвращаем стандартную экспоненту
        switch (protocol) {
            case 411:
            case 412:
            case 413:
            case 414:
                return "10001"; // Стандартная экспонента
            default:
                return null;
        }
    }
    
    /**
     * Выполняет расширенный дамп конфигурации.
     *
     * @return строка с описанием конфигурации
     */
    @Override
    public String dumpConfig() {
        StringBuilder sb = new StringBuilder(super.dumpConfig());
        
        sb.append("\nAdditional Configs:");
        for (Map.Entry<Integer, String> entry : ADDITIONAL_CLIENT_MODULUS.entrySet()) {
            int protocol = entry.getKey();
            sb.append("\n  Protocol: ").append(protocol);
            sb.append("\n    Modulus: ").append(entry.getValue());
            sb.append("\n    Exponent: ").append(ADDITIONAL_CLIENT_EXPONENT.get(protocol));
        }
        
        return sb.toString();
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.lamecrypt;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.util.Arrays;

/**
 * Реализация алгоритма шифрования Lineage 2 версии 1.2.0.
 * Это XOR-шифр, который использует динамический ключ, зависящий от позиции байта.
 */
public class L2Ver120 {
    
    // Стандартный ключ шифрования для версии 1.2.0
    private static final byte[] DEFAULT_SEED = {
        (byte) 0xD3, (byte) 0xB5, (byte) 0xA6, (byte) 0xC1, (byte) 0x8F, (byte) 0x4A, (byte) 0x19, (byte) 0xE8
    };
    
    // Ключ шифрования
    private final byte[] seed;
    private final SecureRandom random;
    
    /**
     * Создает новый объект шифрования с ключом по умолчанию.
     */
    public L2Ver120() {
        this(DEFAULT_SEED);
    }
    
    /**
     * Создает новый объект шифрования с указанным ключом.
     *
     * @param seed начальное значение (seed) для генератора ключа
     */
    public L2Ver120(byte[] seed) {
        if (seed == null || seed.length == 0) {
            throw new IllegalArgumentException("Seed cannot be null or empty");
        }
        this.seed = Arrays.copyOf(seed, seed.length);
        this.random = new SecureRandom(seed);
    }
    
    /**
     * Шифрует массив байт.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     */
    public byte[] encrypt(byte[] data) {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        byte[] result = Arrays.copyOf(data, data.length);
        encrypt(result, 0, result.length);
        return result;
    }
    
    /**
     * Шифрует указанную часть массива байт.
     *
     * @param data массив байт для шифрования
     * @param offset начальная позиция
     * @param length количество байт для шифрования
     */
    public void encrypt(byte[] data, int offset, int length) {
        if (data == null || offset < 0 || length < 0 || offset + length > data.length) {
            throw new IllegalArgumentException("Invalid data, offset or length");
        }
        
        // Сбрасываем генератор случайных чисел для получения одинакового ключа
        SecureRandom localRandom = new SecureRandom(seed);
        
        // Генерируем ключ для шифрования
        byte[] key = new byte[length];
        localRandom.nextBytes(key);
        
        // Шифруем данные с помощью сгенерированного ключа
        for (int i = 0; i < length; i++) {
            data[offset + i] ^= key[i];
        }
    }
    
    /**
     * Дешифрует массив байт.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     */
    public byte[] decrypt(byte[] data) {
        // Для XOR шифрования операции шифрования и дешифрования идентичны
        return encrypt(data);
    }
    
    /**
     * Дешифрует указанную часть массива байт.
     *
     * @param data массив байт для дешифрования
     * @param offset начальная позиция
     * @param length количество байт для дешифрования
     */
    public void decrypt(byte[] data, int offset, int length) {
        // Для XOR шифрования операции шифрования и дешифрования идентичны
        encrypt(data, offset, length);
    }
    
    /**
     * Создает входной поток для дешифрования.
     *
     * @param in входной поток с зашифрованными данными
     * @return входной поток с дешифрованными данными
     */
    public InputStream getDecryptionInputStream(InputStream in) {
        return new L2Ver120InputStream(in, seed);
    }
    
    /**
     * Создает выходной поток для шифрования.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     */
    public OutputStream getEncryptionOutputStream(OutputStream out) {
        return new L2Ver120OutputStream(out, seed);
    }
    
    /**
     * Входной поток для дешифрования данных.
     */
    private static class L2Ver120InputStream extends FilterInputStream {
        private final SecureRandom random;
        
        /**
         * Создает новый входной поток для дешифрования.
         *
         * @param in входной поток с зашифрованными данными
         * @param seed начальное значение (seed) для генератора ключа
         */
        public L2Ver120InputStream(InputStream in, byte[] seed) {
            super(in);
            this.random = new SecureRandom(seed);
        }
        
        @Override
        public int read() throws IOException {
            int b = in.read();
            if (b == -1) {
                return -1;
            }
            
            // Генерируем ключ для текущего байта
            byte[] key = new byte[1];
            random.nextBytes(key);
            
            // Дешифруем байт
            byte decrypted = (byte) (b ^ key[0]);
            
            return decrypted & 0xFF;
        }
        
        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int bytesRead = in.read(b, off, len);
            if (bytesRead == -1) {
                return -1;
            }
            
            // Генерируем ключ для прочитанных байтов
            byte[] key = new byte[bytesRead];
            random.nextBytes(key);
            
            // Дешифруем прочитанные байты
            for (int i = 0; i < bytesRead; i++) {
                b[off + i] ^= key[i];
            }
            
            return bytesRead;
        }
        
        @Override
        public long skip(long n) throws IOException {
            // При пропуске байтов необходимо генерировать ключи для них
            long skipped = 0;
            while (skipped < n) {
                // Генерируем ключ для пропускаемого байта
                byte[] key = new byte[1];
                random.nextBytes(key);
                
                // Пропускаем один байт
                long s = super.skip(1);
                if (s <= 0) {
                    // Достигнут конец потока
                    break;
                }
                
                skipped += s;
            }
            
            return skipped;
        }
        
        @Override
        public void close() throws IOException {
            super.close();
        }
    }
    
    /**
     * Выходной поток для шифрования данных.
     */
    private static class L2Ver120OutputStream extends FinishableOutputStream {
        private final OutputStream out;
        private final SecureRandom random;
        
        /**
         * Создает новый выходной поток для шифрования.
         *
         * @param out выходной поток для записи зашифрованных данных
         * @param seed начальное значение (seed) для генератора ключа
         */
        public L2Ver120OutputStream(OutputStream out, byte[] seed) {
            this.out = out;
            this.random = new SecureRandom(seed);
        }
        
        @Override
        public void write(int b) throws IOException {
            // Генерируем ключ для текущего байта
            byte[] key = new byte[1];
            random.nextBytes(key);
            
            // Шифруем байт
            byte encrypted = (byte) (b ^ key[0]);
            
            out.write(encrypted & 0xFF);
        }
        
        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            // Создаем копию данных для шифрования
            byte[] encrypted = Arrays.copyOfRange(b, off, off + len);
            
            // Генерируем ключ для шифрования
            byte[] key = new byte[len];
            random.nextBytes(key);
            
            // Шифруем данные
            for (int i = 0; i < len; i++) {
                encrypted[i] ^= key[i];
            }
            
            // Записываем зашифрованные данные
            out.write(encrypted);
        }
        
        @Override
        public void finish() throws IOException {
            // Для XOR шифрования не требуется дополнительных действий
            out.flush();
        }
        
        @Override
        public void close() throws IOException {
            super.close();
        }
    }
}
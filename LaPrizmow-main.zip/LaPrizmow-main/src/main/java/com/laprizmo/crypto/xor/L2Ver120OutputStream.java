/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.FinishableOutputStream;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Выходной поток для шифрования данных Lineage 2 версии 1.2.0 с использованием XOR.
 * Отличается от стандартного XOR тем, что ключ динамически меняется в процессе шифрования.
 */
public final class L2Ver120OutputStream extends FinishableOutputStream {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver120OutputStream.class.getName());
    
    private final OutputStream out;
    private byte key;
    private boolean closed = false;

    /**
     * Создает новый шифрующий поток XOR для версии 1.2.0.
     *
     * @param output выходной поток для записи зашифрованных данных
     */
    public L2Ver120OutputStream(OutputStream output) {
        super(output);
        this.out = Objects.requireNonNull(output, "output stream cannot be null");
        this.key = L2Ver120.INITIAL_KEY;
    }

    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        // Шифруем байт с помощью текущего ключа
        byte encrypted = (byte) (b ^ key);
        
        // Обновляем ключ для следующего байта
        key = (byte) ((key + L2Ver120.KEY_INCREMENT) & 0xFF);
        
        out.write(encrypted & 0xFF);
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        // Создаем копию буфера для шифрования, чтобы не изменять оригинал
        byte[] encryptedBuffer = new byte[len];
        
        // Шифруем все байты
        for (int i = 0; i < len; i++) {
            encryptedBuffer[i] = (byte) (b[off + i] ^ key);
            key = (byte) ((key + L2Ver120.KEY_INCREMENT) & 0xFF);
        }
        
        // Записываем зашифрованные данные
        out.write(encryptedBuffer, 0, len);
    }
    
    @Override
    public void flush() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        out.flush();
    }
    
    @Override
    public void finish() throws IOException {
        if (closed) {
            return;
        }
        
        out.flush();
    }
    
    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        try {
            finish();
        } finally {
            closed = true;
            out.close();
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.aes;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Выходной поток для шифрования данных Lineage 2 версии 5.1.x с использованием AES.
 */
public final class L2Ver51xOutputStream extends FinishableOutputStream {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver51xOutputStream.class.getName());
    
    // Размер буфера для накопления данных перед шифрованием
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    
    // Выходной поток для записи зашифрованных данных
    private final OutputStream out;
    
    // Шифровальщик AES
    private final Cipher cipher;
    
    // Буфер для накопления данных перед шифрованием
    private byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    // Флаг, указывающий, был ли поток закрыт
    private boolean closed;
    
    /**
     * Создает новый шифрующий поток AES.
     *
     * @param output выходной поток для записи зашифрованных данных
     * @param key    ключ AES (должен быть 32 байта)
     * @param iv     вектор инициализации AES (должен быть 16 байт)
     * @throws CryptoException если возникла ошибка при инициализации
     */
    public L2Ver51xOutputStream(OutputStream output, byte[] key, byte[] iv) throws CryptoException {
        super(output);
        
        this.out = Objects.requireNonNull(output, "output stream cannot be null");
        
        if (key == null || key.length != 32) {
            throw new IllegalArgumentException("AES key must be 32 bytes");
        }
        
        if (iv == null || iv.length != 16) {
            throw new IllegalArgumentException("AES IV must be 16 bytes");
        }
        
        try {
            // Инициализируем шифр
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            
            // Инициализируем буфер
            buffer = new byte[DEFAULT_BUFFER_SIZE];
            bufferPos = 0;
            closed = false;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize AES stream", e);
            throw new CryptoException("Failed to initialize AES stream: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        if (bufferPos >= buffer.length) {
            flushBuffer();
        }
        
        buffer[bufferPos++] = (byte) b;
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        // Шифруем непосредственно, если буфер пуст и данных много
        if (bufferPos == 0 && len >= buffer.length) {
            encryptAndWrite(b, off, len);
            return;
        }
        
        // Копируем данные в буфер порциями
        int bytesLeft = len;
        int srcPos = off;
        
        while (bytesLeft > 0) {
            // Если буфер заполнен, сбрасываем его
            if (bufferPos >= buffer.length) {
                flushBuffer();
            }
            
            // Копируем максимально возможное количество данных в буфер
            int bytesToCopy = Math.min(buffer.length - bufferPos, bytesLeft);
            System.arraycopy(b, srcPos, buffer, bufferPos, bytesToCopy);
            
            bufferPos += bytesToCopy;
            srcPos += bytesToCopy;
            bytesLeft -= bytesToCopy;
        }
    }
    
    /**
     * Шифрует и записывает данные напрямую, минуя буфер.
     *
     * @param b   буфер с данными
     * @param off смещение в буфере
     * @param len длина данных
     * @throws IOException если возникла ошибка ввода-вывода
     */
    private void encryptAndWrite(byte[] b, int off, int len) throws IOException {
        try {
            // Шифруем данные
            byte[] encryptedData = cipher.update(b, off, len);
            
            if (encryptedData != null && encryptedData.length > 0) {
                // Записываем зашифрованные данные
                out.write(encryptedData);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error encrypting data", e);
            throw new IOException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Шифрует данные из буфера и записывает их в выходной поток.
     *
     * @throws IOException если возникла ошибка ввода-вывода
     */
    private void flushBuffer() throws IOException {
        if (bufferPos == 0) {
            return;
        }
        
        try {
            // Шифруем данные из буфера
            byte[] encryptedData = cipher.update(buffer, 0, bufferPos);
            
            if (encryptedData != null && encryptedData.length > 0) {
                // Записываем зашифрованные данные
                out.write(encryptedData);
            }
            
            // Сбрасываем буфер
            bufferPos = 0;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error encrypting buffer", e);
            throw new IOException("Error encrypting buffer: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void flush() throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        
        // Не сбрасываем буфер при flush, так как AES требует блоков определенного размера
        out.flush();
    }
    
    @Override
    public void finish() throws IOException {
        if (closed) {
            return;
        }
        
        try {
            // Шифруем оставшиеся данные в буфере и добавляем padding
            byte[] encryptedData = cipher.doFinal(buffer, 0, bufferPos);
            
            if (encryptedData != null && encryptedData.length > 0) {
                // Записываем зашифрованные данные
                out.write(encryptedData);
            }
            
            out.flush();
            bufferPos = 0;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error finalizing encryption", e);
            throw new IOException("Error finalizing encryption: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        try {
            finish();
        } finally {
            closed = true;
            out.close();
        }
    }
}
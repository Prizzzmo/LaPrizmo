/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import com.laprizmo.crypto.CryptoException;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Реализация алгоритма шифрования для Lineage 2 версий 4.1.x.
 * Использует алгоритм RSA с кастомными ключами, характерными для клиента L2.
 */
public class L2Ver41x {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver41x.class.getName());
    
    // Движок RSA
    private final RSAEngine engine;
    
    /**
     * Создает новый экземпляр с ключами по умолчанию.
     */
    public L2Ver41x() {
        try {
            this.engine = new RSAEngine();
        } catch (CryptoException e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize RSA engine with default keys", e);
            throw new RuntimeException("Failed to initialize RSA engine", e);
        }
    }
    
    /**
     * Создает новый экземпляр с указанным движком RSA.
     *
     * @param engine движок RSA
     */
    public L2Ver41x(RSAEngine engine) {
        this.engine = engine;
    }
    
    /**
     * Шифрует данные.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        return engine.encrypt(data);
    }
    
    /**
     * Расшифровывает данные.
     *
     * @param data зашифрованные данные
     * @return расшифрованные данные
     * @throws CryptoException если возникла ошибка при расшифровке
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        return engine.decrypt(data);
    }
    
    /**
     * Создает поток ввода для чтения зашифрованных данных.
     *
     * @param in входной поток с зашифрованными данными
     * @return поток для чтения расшифрованных данных
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public InputStream getDecryptedInputStream(InputStream in) throws CryptoException {
        return new RSAInputStream(in, engine);
    }
    
    /**
     * Создает поток вывода для записи данных с шифрованием.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return поток для записи данных с автоматическим шифрованием
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public OutputStream getEncryptedOutputStream(OutputStream out) throws CryptoException {
        return new RSAOutputStream(out, engine);
    }
    
    /**
     * Возвращает используемый движок RSA.
     *
     * @return движок RSA
     */
    public RSAEngine getEngine() {
        return engine;
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Реализация алгоритма шифрования Lineage 2 версии 121.
 * Использует XOR шифрование с ключом, генерируемым на основе имени файла.
 */
public class L2Ver121 {
    
    // Размер буфера по умолчанию
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    
    // Имя файла, используемое для генерации ключа
    private final String fileName;
    
    /**
     * Создает новый объект шифрования с указанным путем к файлу.
     *
     * @param filePath путь к файлу (будет использовано только имя файла)
     */
    public L2Ver121(String filePath) {
        Path path = Paths.get(filePath);
        this.fileName = path.getFileName().toString();
    }
    
    /**
     * Создает новый объект шифрования с явно указанным именем файла.
     *
     * @param fileName имя файла для генерации ключа
     * @param useFileName флаг явного указания имени файла (для совместимости с перегрузкой)
     */
    public L2Ver121(String fileName, boolean useFileName) {
        this.fileName = fileName;
    }
    
    /**
     * Шифрует массив байт.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        try {
            byte[] result = new byte[data.length];
            
            for (int i = 0; i < data.length; i++) {
                int key = generateKey(i);
                result[i] = (byte) (data[i] ^ key);
            }
            
            return result;
        } catch (Exception e) {
            throw new CryptoException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Дешифрует массив байт.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        return encrypt(data); // XOR является симметричным шифром
    }
    
    /**
     * Создает входной поток для дешифрования.
     *
     * @param in входной поток с зашифрованными данными
     * @return входной поток с дешифрованными данными
     */
    public InputStream getDecryptionInputStream(InputStream in) {
        return new L2Ver121InputStream(in, this);
    }
    
    /**
     * Создает выходной поток для шифрования.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     */
    public OutputStream getEncryptionOutputStream(OutputStream out) {
        return new L2Ver121OutputStream(out, this);
    }
    
    /**
     * Генерирует ключ XOR на основе имени файла и позиции байта.
     *
     * @param position позиция байта в потоке
     * @return ключ XOR
     */
    protected int generateKey(int position) {
        if (fileName == null || fileName.isEmpty()) {
            return 0; // Если имя файла не задано, используем ключ 0
        }
        
        int nameLen = fileName.length();
        // Вычисляем индекс символа в имени файла, циклически
        int charIndex = position % nameLen;
        // Берем символ из имени файла как основу для ключа
        char c = fileName.charAt(charIndex);
        
        // Комбинируем позицию и символ для создания ключа
        return (c ^ position) & 0xFF;
    }
    
    /**
     * Входной поток для дешифрования данных, зашифрованных алгоритмом L2Ver121.
     */
    private static class L2Ver121InputStream extends InputStream {
        private final InputStream in;
        private final L2Ver121 cipher;
        private int position;
        
        /**
         * Создает новый входной поток для дешифрования.
         *
         * @param in     входной поток с зашифрованными данными
         * @param cipher объект шифрования
         */
        public L2Ver121InputStream(InputStream in, L2Ver121 cipher) {
            this.in = in;
            this.cipher = cipher;
            this.position = 0;
        }
        
        @Override
        public int read() throws IOException {
            int b = in.read();
            if (b == -1) {
                return -1;
            }
            
            int key = cipher.generateKey(position++);
            return (b ^ key) & 0xFF;
        }
        
        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int bytesRead = in.read(b, off, len);
            if (bytesRead == -1) {
                return -1;
            }
            
            for (int i = 0; i < bytesRead; i++) {
                int key = cipher.generateKey(position++);
                b[off + i] = (byte) (b[off + i] ^ key);
            }
            
            return bytesRead;
        }
        
        @Override
        public void close() throws IOException {
            in.close();
        }
    }
    
    /**
     * Выходной поток для шифрования данных алгоритмом L2Ver121.
     */
    private static class L2Ver121OutputStream extends FinishableOutputStream {
        private final OutputStream out;
        private final L2Ver121 cipher;
        private int position;
        
        /**
         * Создает новый выходной поток для шифрования.
         *
         * @param out    выходной поток для записи зашифрованных данных
         * @param cipher объект шифрования
         */
        public L2Ver121OutputStream(OutputStream out, L2Ver121 cipher) {
            this.out = out;
            this.cipher = cipher;
            this.position = 0;
        }
        
        @Override
        public void write(int b) throws IOException {
            int key = cipher.generateKey(position++);
            out.write(b ^ key);
        }
        
        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            byte[] buffer = new byte[len];
            
            for (int i = 0; i < len; i++) {
                int key = cipher.generateKey(position++);
                buffer[i] = (byte) (b[off + i] ^ key);
            }
            
            out.write(buffer, 0, len);
        }
        
        @Override
        public void finish() throws IOException {
            out.flush();
        }
        
        @Override
        public void close() throws IOException {
            finish();
            out.close();
        }
    }
}
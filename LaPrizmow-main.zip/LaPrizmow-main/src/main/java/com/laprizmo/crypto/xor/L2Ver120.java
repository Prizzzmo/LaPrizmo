/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.CryptoException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

/**
 * Реализация XOR-шифрования для Lineage 2 версии 1.2.0.
 * Отличается от версии 1.1.1 динамически меняющимся ключом.
 */
public class L2Ver120 {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver120.class.getName());
    
    /**
     * Начальное значение XOR ключа для версии 1.2.0
     */
    public static final byte INITIAL_KEY = (byte) 0xEA;
    
    /**
     * Значение, добавляемое к ключу после каждого байта
     */
    public static final byte KEY_INCREMENT = (byte) 0x3D;
    
    /**
     * Создает поток ввода для дешифрования данных.
     *
     * @param input исходный поток ввода
     * @return поток ввода для дешифрования
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public static InputStream getDecryptInputStream(InputStream input) throws CryptoException {
        if (input == null) {
            throw new CryptoException("Input stream cannot be null");
        }
        
        return new L2Ver120InputStream(input);
    }
    
    /**
     * Создает поток вывода для шифрования данных.
     *
     * @param output исходный поток вывода
     * @return поток вывода для шифрования
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public static OutputStream getEncryptOutputStream(OutputStream output) throws CryptoException {
        if (output == null) {
            throw new CryptoException("Output stream cannot be null");
        }
        
        return new L2Ver120OutputStream(output);
    }
    
    /**
     * Шифрует или дешифрует блок данных с использованием алгоритма XOR версии 1.2.0.
     * XOR-шифрование симметрично, поэтому одна и та же операция используется для шифрования и дешифрования.
     *
     * @param data данные для шифрования/дешифрования
     * @return обработанные данные
     */
    public static byte[] processData(byte[] data) {
        if (data == null || data.length == 0) {
            return data;
        }
        
        byte[] result = new byte[data.length];
        byte key = INITIAL_KEY;
        
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte)(data[i] ^ key);
            key = (byte)((key + KEY_INCREMENT) & 0xFF);
        }
        
        return result;
    }
}
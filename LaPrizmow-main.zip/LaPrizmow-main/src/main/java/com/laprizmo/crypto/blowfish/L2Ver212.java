/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.blowfish;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.FinishableOutputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Реализация алгоритма шифрования Lineage 2 версии 2.12.
 * Основан на алгоритме Blowfish с альтернативным ключом.
 */
public class L2Ver212 {
    
    // Ключ шифрования по умолчанию для версии 2.12
    private static final String DEFAULT_KEY = "[;'.]94-&@%!^+]-31==";
    
    // Размер блока данных
    private static final int BLOCK_SIZE = 8;
    
    // Движок Blowfish
    private final BlowfishEngine engine;
    
    /**
     * Создает новый объект шифрования с ключом по умолчанию.
     */
    public L2Ver212() {
        this(DEFAULT_KEY.getBytes());
    }
    
    /**
     * Создает новый объект шифрования с указанным ключом.
     *
     * @param key ключ шифрования
     */
    public L2Ver212(byte[] key) {
        this.engine = new BlowfishEngine(key);
    }
    
    /**
     * Создает новый объект шифрования с указанным строковым ключом.
     *
     * @param key строковый ключ шифрования
     */
    public L2Ver212(String key) {
        this(key.getBytes());
    }
    
    /**
     * Шифрует массив байт.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        try {
            return engine.encryptECB(data);
        } catch (Exception e) {
            throw new CryptoException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Дешифрует массив байт.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        try {
            return engine.decryptECB(data);
        } catch (Exception e) {
            throw new CryptoException("Error decrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Создает входной поток для дешифрования.
     *
     * @param in входной поток с зашифрованными данными
     * @return входной поток с дешифрованными данными
     */
    public InputStream getDecryptionInputStream(InputStream in) {
        return new L2Ver212InputStream(in, engine);
    }
    
    /**
     * Создает выходной поток для шифрования.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     */
    public OutputStream getEncryptionOutputStream(OutputStream out) {
        return new L2Ver212OutputStream(out, engine);
    }
    
    /**
     * Входной поток для дешифрования данных с использованием Blowfish.
     */
    private static class L2Ver212InputStream extends InputStream {
        private final InputStream in;
        private final BlowfishEngine engine;
        private byte[] buffer;
        private int bufferPos;
        private int bufferSize;
        private boolean endOfStream;
        
        /**
         * Создает новый входной поток для дешифрования.
         *
         * @param in входной поток с зашифрованными данными
         * @param engine движок Blowfish
         */
        public L2Ver212InputStream(InputStream in, BlowfishEngine engine) {
            this.in = in;
            this.engine = engine;
            this.buffer = new byte[0];
            this.bufferPos = 0;
            this.bufferSize = 0;
            this.endOfStream = false;
        }
        
        @Override
        public int read() throws IOException {
            if (bufferPos >= bufferSize) {
                if (endOfStream) {
                    return -1;
                }
                fillBuffer();
                if (bufferSize == 0) {
                    return -1;
                }
            }
            
            return buffer[bufferPos++] & 0xFF;
        }
        
        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (b == null) {
                throw new NullPointerException();
            }
            
            if (off < 0 || len < 0 || off + len > b.length) {
                throw new IndexOutOfBoundsException();
            }
            
            if (len == 0) {
                return 0;
            }
            
            // Проверяем, нужно ли заполнить буфер
            if (bufferPos >= bufferSize) {
                if (endOfStream) {
                    return -1;
                }
                fillBuffer();
                if (bufferSize == 0) {
                    return -1;
                }
            }
            
            // Определяем, сколько байт можно прочитать
            int bytesToRead = Math.min(len, bufferSize - bufferPos);
            System.arraycopy(buffer, bufferPos, b, off, bytesToRead);
            bufferPos += bytesToRead;
            
            return bytesToRead;
        }
        
        /**
         * Заполняет буфер дешифрованными данными.
         */
        private void fillBuffer() throws IOException {
            // Читаем блок зашифрованных данных
            byte[] encryptedBlock = new byte[BLOCK_SIZE];
            int bytesRead = in.read(encryptedBlock);
            
            if (bytesRead == -1) {
                // Конец входного потока
                endOfStream = true;
                bufferSize = 0;
                return;
            }
            
            if (bytesRead < BLOCK_SIZE) {
                // Неполный блок, дополняем нулями
                for (int i = bytesRead; i < BLOCK_SIZE; i++) {
                    encryptedBlock[i] = 0;
                }
            }
            
            try {
                // Дешифруем блок
                byte[] decryptedBlock = engine.decryptBlock(encryptedBlock);
                buffer = decryptedBlock;
                bufferPos = 0;
                bufferSize = decryptedBlock.length;
            } catch (Exception e) {
                throw new IOException("Error decrypting data: " + e.getMessage(), e);
            }
        }
        
        @Override
        public void close() throws IOException {
            in.close();
        }
    }
    
    /**
     * Выходной поток для шифрования данных с использованием Blowfish.
     */
    private static class L2Ver212OutputStream extends FinishableOutputStream {
        private final OutputStream out;
        private final BlowfishEngine engine;
        private byte[] buffer;
        private int bufferPos;
        
        /**
         * Создает новый выходной поток для шифрования.
         *
         * @param out выходной поток для записи зашифрованных данных
         * @param engine движок Blowfish
         */
        public L2Ver212OutputStream(OutputStream out, BlowfishEngine engine) {
            this.out = out;
            this.engine = engine;
            this.buffer = new byte[BLOCK_SIZE];
            this.bufferPos = 0;
        }
        
        @Override
        public void write(int b) throws IOException {
            buffer[bufferPos++] = (byte) b;
            
            if (bufferPos == BLOCK_SIZE) {
                flushBuffer();
            }
        }
        
        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            if (b == null) {
                throw new NullPointerException();
            }
            
            if (off < 0 || len < 0 || off + len > b.length) {
                throw new IndexOutOfBoundsException();
            }
            
            int bytesWritten = 0;
            while (bytesWritten < len) {
                // Определяем, сколько байт можно записать в буфер
                int bytesToWrite = Math.min(len - bytesWritten, BLOCK_SIZE - bufferPos);
                
                // Копируем данные в буфер
                System.arraycopy(b, off + bytesWritten, buffer, bufferPos, bytesToWrite);
                bufferPos += bytesToWrite;
                bytesWritten += bytesToWrite;
                
                // Если буфер заполнен, шифруем и записываем его
                if (bufferPos == BLOCK_SIZE) {
                    flushBuffer();
                }
            }
        }
        
        /**
         * Шифрует и записывает буфер в выходной поток.
         */
        private void flushBuffer() throws IOException {
            if (bufferPos > 0) {
                try {
                    // Если буфер не заполнен, дополняем его нулями
                    if (bufferPos < BLOCK_SIZE) {
                        for (int i = bufferPos; i < BLOCK_SIZE; i++) {
                            buffer[i] = 0;
                        }
                    }
                    
                    // Шифруем буфер
                    byte[] encryptedBlock = engine.encryptBlock(buffer);
                    
                    // Записываем зашифрованный блок
                    out.write(encryptedBlock);
                    
                    // Сбрасываем буфер
                    bufferPos = 0;
                } catch (Exception e) {
                    throw new IOException("Error encrypting data: " + e.getMessage(), e);
                }
            }
        }
        
        @Override
        public void finish() throws IOException {
            flushBuffer();
            out.flush();
        }
        
        @Override
        public void close() throws IOException {
            finish();
            out.close();
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import com.laprizmo.crypto.CryptoException;

import javax.crypto.Cipher;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Реализация движка RSA для шифрования/дешифрования данных.
 * Поддерживает работу с ключами, используемыми в клиенте Lineage 2.
 */
public class RSAEngine {
    
    private static final Logger LOGGER = Logger.getLogger(RSAEngine.class.getName());
    
    // Константные ключи RSA для Lineage 2 версий 4.x
    // Эти значения используются в клиенте L2 для различных подключений
    private static final BigInteger DEFAULT_MODULUS = new BigInteger(
            "75b4d6de5c016af9"
          + "b0f6e017d985d60"
          + "8b354023157b98f8"
          + "51a12a741ae4cd57"
          + "de1c5688defce5c"
          + "a0e20d4d911412b"
          + "74967b794549780"
          + "a5ab044650e7afe"
          + "6c213f76108a0e3"
          + "600883d439c1e78"
          + "1673c5dbe9f9728"
          + "e0b16435536b667"
          + "fd390ee605c6132"
          + "a01a581197e7410"
          + "c9d1d4df3f0878" + "e93465", 16);
    
    private static final BigInteger DEFAULT_PRIVATE_EXPONENT = new BigInteger(
            "5d206e5e10a0bbf0"
          + "4fd61f30dd2e1e5"
          + "b4ccc56f954b60f1"
          + "82beca159d35f766"
          + "ef4bb0b1ae7e8a1"
          + "0db1e477a171f2f"
          + "d3df49a656ad767"
          + "b79b14a02b59c8c"
          + "fc10fba64f9a30a"
          + "0a97c9f9d580d2a"
          + "9d72d7b1dc9ddcd"
          + "1a68e4ee092c475"
          + "562596218e98df5"
          + "3c177ec13a2e8c6"
          + "2da531b843b753" + "1b087", 16);
    
    private static final BigInteger DEFAULT_PUBLIC_EXPONENT = BigInteger.valueOf(65537);
    
    // Размер блока RSA в байтах (размер шифруемого блока должен быть меньше размера модуля в байтах)
    private final int blockSize;
    
    // Публичный ключ RSA
    private RSAPublicKey publicKey;
    
    // Приватный ключ RSA
    private RSAPrivateKey privateKey;
    
    /**
     * Создает движок RSA с ключами по умолчанию.
     *
     * @throws CryptoException если возникла ошибка при инициализации ключей
     */
    public RSAEngine() throws CryptoException {
        this(DEFAULT_MODULUS, DEFAULT_PUBLIC_EXPONENT, DEFAULT_PRIVATE_EXPONENT);
    }
    
    /**
     * Создает движок RSA с указанными параметрами ключей.
     *
     * @param modulus         модуль RSA
     * @param publicExponent  открытая экспонента
     * @param privateExponent закрытая экспонента
     * @throws CryptoException если возникла ошибка при инициализации ключей
     */
    public RSAEngine(BigInteger modulus, BigInteger publicExponent, BigInteger privateExponent) throws CryptoException {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            
            // Инициализируем публичный ключ
            RSAPublicKeySpec publicKeySpec = new RSAPublicKeySpec(modulus, publicExponent);
            publicKey = (RSAPublicKey) keyFactory.generatePublic(publicKeySpec);
            
            // Инициализируем приватный ключ
            RSAPrivateKeySpec privateKeySpec = new RSAPrivateKeySpec(modulus, privateExponent);
            privateKey = (RSAPrivateKey) keyFactory.generatePrivate(privateKeySpec);
            
            // Вычисляем размер блока (размер модуля минус padding)
            blockSize = (modulus.bitLength() + 7) / 8 - 11;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize RSA engine", e);
            throw new CryptoException("Failed to initialize RSA engine: " + e.getMessage(), e);
        }
    }
    
    /**
     * Шифрует данные с использованием публичного ключа.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            
            // Размер блока RSA в байтах
            int outputSize = cipher.getOutputSize(data.length);
            
            // Если данные меньше или равны размеру блока, шифруем одним блоком
            if (data.length <= blockSize) {
                return cipher.doFinal(data);
            }
            
            // Иначе шифруем блоками
            int blocks = (data.length + blockSize - 1) / blockSize;
            byte[] output = new byte[blocks * outputSize];
            int outputOffset = 0;
            
            for (int i = 0; i < blocks; i++) {
                int blockOffset = i * blockSize;
                int currentBlockSize = Math.min(blockSize, data.length - blockOffset);
                
                byte[] encryptedBlock = cipher.doFinal(data, blockOffset, currentBlockSize);
                System.arraycopy(encryptedBlock, 0, output, outputOffset, encryptedBlock.length);
                outputOffset += encryptedBlock.length;
            }
            
            // Если последний блок не заполнил выходной массив полностью
            if (outputOffset < output.length) {
                byte[] trimmedOutput = new byte[outputOffset];
                System.arraycopy(output, 0, trimmedOutput, 0, outputOffset);
                return trimmedOutput;
            }
            
            return output;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to encrypt data", e);
            throw new CryptoException("Encryption failed: " + e.getMessage(), e);
        }
    }
    
    /**
     * Расшифровывает данные с использованием приватного ключа.
     *
     * @param data зашифрованные данные
     * @return расшифрованные данные
     * @throws CryptoException если возникла ошибка при расшифровке
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            
            // Размер блока RSA в байтах
            int inputBlockSize = (privateKey.getModulus().bitLength() + 7) / 8;
            
            // Если данные меньше или равны размеру блока, расшифровываем одним блоком
            if (data.length <= inputBlockSize) {
                return cipher.doFinal(data);
            }
            
            // Иначе расшифровываем блоками
            int blocks = (data.length + inputBlockSize - 1) / inputBlockSize;
            int maxOutputBlockSize = cipher.getOutputSize(inputBlockSize);
            byte[] output = new byte[blocks * maxOutputBlockSize];
            int outputOffset = 0;
            
            for (int i = 0; i < blocks; i++) {
                int blockOffset = i * inputBlockSize;
                int currentBlockSize = Math.min(inputBlockSize, data.length - blockOffset);
                
                byte[] decryptedBlock = cipher.doFinal(data, blockOffset, currentBlockSize);
                System.arraycopy(decryptedBlock, 0, output, outputOffset, decryptedBlock.length);
                outputOffset += decryptedBlock.length;
            }
            
            // Если последний блок не заполнил выходной массив полностью
            if (outputOffset < output.length) {
                byte[] trimmedOutput = new byte[outputOffset];
                System.arraycopy(output, 0, trimmedOutput, 0, outputOffset);
                return trimmedOutput;
            }
            
            return output;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to decrypt data", e);
            throw new CryptoException("Decryption failed: " + e.getMessage(), e);
        }
    }
    
    /**
     * Возвращает размер блока RSA в байтах.
     *
     * @return размер блока
     */
    public int getBlockSize() {
        return blockSize;
    }
    
    /**
     * Возвращает публичный ключ RSA.
     *
     * @return публичный ключ
     */
    public RSAPublicKey getPublicKey() {
        return publicKey;
    }
    
    /**
     * Возвращает приватный ключ RSA.
     *
     * @return приватный ключ
     */
    public RSAPrivateKey getPrivateKey() {
        return privateKey;
    }
    
    /**
     * Генерирует новую пару ключей RSA указанной длины.
     *
     * @param keySize размер ключа в битах (рекомендуется 2048 или выше)
     * @return движок RSA с новыми ключами
     * @throws CryptoException если возникла ошибка при генерации ключей
     */
    public static RSAEngine generateKeys(int keySize) throws CryptoException {
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(keySize, new SecureRandom());
            KeyPair keyPair = keyGen.generateKeyPair();
            
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
            RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
            
            return new RSAEngine(publicKey.getModulus(), publicKey.getPublicExponent(), privateKey.getPrivateExponent());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to generate RSA keys", e);
            throw new CryptoException("Failed to generate RSA keys: " + e.getMessage(), e);
        }
    }
}
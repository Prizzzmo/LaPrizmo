/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.CryptoException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

/**
 * Реализация XOR-шифрования для Lineage 2 версии 1.1.1.
 * Использует статический ключ для шифрования/дешифрования данных.
 */
public class L2Ver111 {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver111.class.getName());
    
    /**
     * Ключ XOR для версии 1.1.1
     */
    public static final byte[] XOR_KEY_111 = {
            (byte) 0x24, (byte) 0x7D, (byte) 0x53, (byte) 0x19,
            (byte) 0xAA, (byte) 0x66, (byte) 0x3C, (byte) 0xE2,
            (byte) 0x71, (byte) 0x44, (byte) 0xF0, (byte) 0x0B,
            (byte) 0xD5, (byte) 0x8D, (byte) 0x3F, (byte) 0xC2
    };
    
    /**
     * Ключ XOR для версии 1.2.1
     */
    public static final byte[] XOR_KEY_121 = {
            (byte) 0xC1, (byte) 0xB2, (byte) 0x58, (byte) 0x3F,
            (byte) 0x68, (byte) 0x45, (byte) 0xA0, (byte) 0x13,
            (byte) 0xD5, (byte) 0x42, (byte) 0xEF, (byte) 0x36,
            (byte) 0x83, (byte) 0x89, (byte) 0x5A, (byte) 0xF1
    };
    
    /**
     * Алгоритм для получения ключа версии 1.2.x на основе входных данных.
     * Этот метод воссоздает ключ, используемый для шифрования некоторых файлов Lineage 2.
     *
     * @param input входные данные для генерации ключа
     * @return сгенерированный ключ XOR
     */
    public static byte[] generateKey121(byte[] input) {
        if (input == null || input.length == 0) {
            return XOR_KEY_121.clone();
        }
        
        byte[] key = new byte[16];
        int keyLength = Math.min(16, input.length);
        
        // Копируем часть входных данных
        System.arraycopy(input, 0, key, 0, keyLength);
        
        // Если входные данные меньше размера ключа, заполняем остаток
        if (keyLength < 16) {
            for (int i = keyLength; i < 16; i++) {
                key[i] = (byte)(key[i % keyLength] ^ XOR_KEY_121[i]);
            }
        }
        
        // Применяем алгоритм трансформации
        for (int i = 0; i < 16; i++) {
            key[i] = (byte)((key[i] ^ XOR_KEY_121[i]) & 0xFF);
        }
        
        return key;
    }
    
    /**
     * Создает поток ввода для дешифрования данных.
     *
     * @param input исходный поток ввода
     * @return поток ввода для дешифрования
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public static InputStream getDecryptInputStream(InputStream input) throws CryptoException {
        if (input == null) {
            throw new CryptoException("Input stream cannot be null");
        }
        
        return new L2Ver1x1InputStream(input, XOR_KEY_111);
    }
    
    /**
     * Создает поток вывода для шифрования данных.
     *
     * @param output исходный поток вывода
     * @return поток вывода для шифрования
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public static OutputStream getEncryptOutputStream(OutputStream output) throws CryptoException {
        if (output == null) {
            throw new CryptoException("Output stream cannot be null");
        }
        
        return new L2Ver1x1OutputStream(output, XOR_KEY_111);
    }
    
    /**
     * Шифрует или дешифрует блок данных с использованием XOR-ключа.
     * XOR-шифрование симметрично, поэтому одна и та же операция используется для шифрования и дешифрования.
     *
     * @param data данные для шифрования/дешифрования
     * @param key  ключ XOR
     * @return обработанные данные
     */
    public static byte[] processData(byte[] data, byte[] key) {
        if (data == null || data.length == 0 || key == null || key.length == 0) {
            return data;
        }
        
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte)(data[i] ^ key[i % key.length]);
        }
        
        return result;
    }
    
    /**
     * Шифрует или дешифрует данные с использованием стандартного ключа для версии 1.1.1.
     *
     * @param data данные для шифрования/дешифрования
     * @return обработанные данные
     */
    public static byte[] processData(byte[] data) {
        return processData(data, XOR_KEY_111);
    }
    
    /**
     * Интерфейс для классов, работающих с XOR версии 1.x.1
     */
    public interface L2Ver1x1 {
        /**
         * Применяет XOR к набору данных с заданным ключом
         */
        static byte[] applyXor(byte[] data, byte[] key) {
            return L2Ver111.processData(data, key);
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.aes;

import com.laprizmo.crypto.CryptoException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Входной поток для дешифрования данных Lineage 2 версии 5.1.x с использованием AES.
 */
public final class L2Ver51xInputStream extends FilterInputStream {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver51xInputStream.class.getName());
    
    // Размер буфера для чтения зашифрованных данных
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    
    // Шифровальщик AES
    private final Cipher cipher;
    
    // Буфер для расшифрованных данных
    private byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    // Количество доступных байт в буфере
    private int bufferAvailable;
    
    // Флаг конца потока
    private boolean endOfStream;

    /**
     * Создает новый дешифрующий поток AES.
     *
     * @param input входной поток с зашифрованными данными
     * @param key   ключ AES (должен быть 32 байта)
     * @param iv    вектор инициализации AES (должен быть 16 байт)
     * @throws CryptoException если возникла ошибка при инициализации
     */
    public L2Ver51xInputStream(InputStream input, byte[] key, byte[] iv) throws CryptoException {
        super(Objects.requireNonNull(input, "input stream cannot be null"));
        
        if (key == null || key.length != 32) {
            throw new IllegalArgumentException("AES key must be 32 bytes");
        }
        
        if (iv == null || iv.length != 16) {
            throw new IllegalArgumentException("AES IV must be 16 bytes");
        }
        
        try {
            // Инициализируем шифр
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            
            // Инициализируем буфер
            buffer = new byte[0];
            bufferPos = 0;
            bufferAvailable = 0;
            endOfStream = false;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize AES stream", e);
            throw new CryptoException("Failed to initialize AES stream: " + e.getMessage(), e);
        }
    }

    @Override
    public int read() throws IOException {
        if (bufferPos >= bufferAvailable) {
            if (endOfStream) {
                return -1;
            }
            fillBuffer();
            if (bufferAvailable == 0) {
                return -1;
            }
        }
        
        return buffer[bufferPos++] & 0xFF;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        if (len == 0) {
            return 0;
        }
        
        if (endOfStream && bufferPos >= bufferAvailable) {
            return -1;
        }
        
        int bytesRead = 0;
        
        while (bytesRead < len) {
            if (bufferPos >= bufferAvailable) {
                fillBuffer();
                if (bufferAvailable == 0) {
                    break;
                }
            }
            
            int available = Math.min(bufferAvailable - bufferPos, len - bytesRead);
            System.arraycopy(buffer, bufferPos, b, off + bytesRead, available);
            
            bufferPos += available;
            bytesRead += available;
        }
        
        return bytesRead > 0 ? bytesRead : -1;
    }
    
    /**
     * Заполняет буфер расшифрованными данными.
     *
     * @throws IOException если возникла ошибка ввода-вывода
     */
    private void fillBuffer() throws IOException {
        if (endOfStream) {
            bufferAvailable = 0;
            return;
        }
        
        try {
            // Создаем буфер для чтения зашифрованных данных
            byte[] encryptedData = new byte[DEFAULT_BUFFER_SIZE];
            int bytesRead = in.read(encryptedData);
            
            if (bytesRead == -1) {
                // Конец потока
                endOfStream = true;
                bufferAvailable = 0;
                return;
            }
            
            if (bytesRead == 0) {
                // Ничего не прочитано
                bufferAvailable = 0;
                return;
            }
            
            // Расшифровываем данные
            buffer = cipher.update(encryptedData, 0, bytesRead);
            
            if (buffer == null) {
                // Шифр не вернул никаких данных, возможно, нужно больше входных данных
                bufferAvailable = 0;
                return;
            }
            
            bufferPos = 0;
            bufferAvailable = buffer.length;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error decrypting data", e);
            throw new IOException("Error decrypting data: " + e.getMessage(), e);
        }
    }
    
    @Override
    public long skip(long n) throws IOException {
        if (n <= 0) {
            return 0;
        }
        
        long skipped = 0;
        while (skipped < n) {
            if (bufferPos >= bufferAvailable) {
                fillBuffer();
                if (bufferAvailable == 0) {
                    break;
                }
            }
            
            long available = Math.min(bufferAvailable - bufferPos, n - skipped);
            bufferPos += available;
            skipped += available;
        }
        
        return skipped;
    }
    
    @Override
    public int available() throws IOException {
        return bufferAvailable - bufferPos;
    }
    
    @Override
    public void close() throws IOException {
        in.close();
    }
    
    @Override
    public synchronized void mark(int readlimit) {
        throw new UnsupportedOperationException("Mark not supported");
    }
    
    @Override
    public synchronized void reset() throws IOException {
        throw new UnsupportedOperationException("Reset not supported");
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
}
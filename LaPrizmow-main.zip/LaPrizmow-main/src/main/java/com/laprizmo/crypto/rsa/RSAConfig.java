/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.rsa;

import java.util.HashMap;
import java.util.Map;

/**
 * Конфигурация RSA ключей для различных версий протокола Lineage 2.
 * Содержит предопределенные ключи и возможность настройки пользовательских ключей.
 */
public class RSAConfig {
    // Модуль RSA в шестнадцатеричном формате
    private final String modulusHex;
    
    // Приватная экспонента в шестнадцатеричном формате (для дешифрования)
    private final String privateExponentHex;
    
    // Публичная экспонента в шестнадцатеричном формате (для шифрования)
    private final String publicExponentHex;
    
    // Предопределенные конфигурации RSA для разных версий протокола
    private static final Map<Integer, RSAConfig> PROTOCOL_CONFIGS = new HashMap<>();
    
    // Современная конфигурация RSA
    private static final RSAConfig MODERN_CONFIG;
    
    static {
        // Инициализация предопределенных конфигураций
        PROTOCOL_CONFIGS.put(411, new RSAConfig(
            "8c9d5da87b30f5d7cd9dc88c746eaac5bb180267fa11737358c4c95d9adf59dd37689f9befb251508759555d6fe0eca87bebe0a10712cf0ec245af84cd22eb4cb675e98eaf5799fca62a20a2baa4801d5d70718dcd43283b8428f1387aec6600f937bfc7bb72404d187d3a9c438f1ffce9ce365dccf754232ff6def038a41385",
            "1d",
            null
        ));
        
        PROTOCOL_CONFIGS.put(412, new RSAConfig(
            "a465134799cf2c45087093e7d0f0f144e6d528110c08f674730d436e40827330eccea46e70acf10cdda7d8f710e3b44dcca931812d76cd7494289bca8b73823f57efc0515b97e4a2a02612ccfa719cf7885104b06f2e7e2cc967b62e3d3b1aadb925db94cbc8cd3070a4bb13f7e202c7733a67b1b94c1ebc0afcbe1a63b448cf",
            "25",
            null
        ));
        
        PROTOCOL_CONFIGS.put(413, new RSAConfig(
            "97df398472ddf737ef0a0cd17e8d172f0fef1661a38a8ae1d6e829bc1c6e4c3cfc19292dda9ef90175e46e7394a18850b6417d03be6eea274d3ed1dde5b5d7bde72cc0a0b71d03608655633881793a02c9a67d9ef2b45eb7c08d4be329083ce450e68f7867b6749314d40511d09bc5744551baa86a89dc38123dc1668fd72d83",
            "35",
            null
        ));
        
        PROTOCOL_CONFIGS.put(414, new RSAConfig(
            "ad70257b2316ce09dfaf2ebc3f63b3d673b0c98a403950e26bb87379b11e17aed0e45af23e7171e5ec1fbc8d1ae32ffb7801b31266eef9c334b53469d4b7cbe83284273d35a9aab49b453e7012f374496c65f8089f5d134b0eb3d1e3b22051ed5977a6dd68c4f85785dfcc9f4412c81681944fc4b8ce27caf0242deaa5762e8d",
            "25",
            null
        ));
        
        // Современная конфигурация
        MODERN_CONFIG = new RSAConfig(
            "75b4d6de5c016544068a1acf125869f43d2e09fc55b8b1e289556daf9b8757635593446288b3653da1ce91c87bb1a5c18f16323495c55d7d72c0890a83f69bfd1fd9434eb1c02f3e4679edfa43309319070129c267c85604d87bb65bae205de3707af1d2108881abb567c3b3d069ae67c3a4c6a3aa93d26413d4c66094ae2039",
            "1d",
            "30b4c2d798d47086145c75063c8e841e719776e400291d7838d3e6c4405b504c6a07f8fca27f32b86643d26448b69b679903c5818b4b8069d02e3f849be7a7336fd5b23a620a96d0da89f9dfe60543f3b54834c44b7a866539a9bbbe5338ebd"
        );
    }
    
    /**
     * Создает новую конфигурацию RSA.
     *
     * @param modulusHex модуль RSA в шестнадцатеричном формате
     * @param privateExponentHex приватная экспонента в шестнадцатеричном формате
     * @param publicExponentHex публичная экспонента в шестнадцатеричном формате (может быть null)
     */
    public RSAConfig(String modulusHex, String privateExponentHex, String publicExponentHex) {
        this.modulusHex = modulusHex;
        this.privateExponentHex = privateExponentHex;
        this.publicExponentHex = publicExponentHex;
    }
    
    /**
     * Создает новую конфигурацию RSA только с приватным ключом.
     *
     * @param modulusHex модуль RSA в шестнадцатеричном формате
     * @param privateExponentHex приватная экспонента в шестнадцатеричном формате
     */
    public RSAConfig(String modulusHex, String privateExponentHex) {
        this(modulusHex, privateExponentHex, null);
    }
    
    /**
     * Получает предопределенную конфигурацию RSA для указанной версии протокола.
     *
     * @param protocolVersion версия протокола (411, 412, 413, 414)
     * @param useLegacy использовать ли устаревшие ключи
     * @return конфигурация RSA
     */
    public static RSAConfig getForProtocol(int protocolVersion, boolean useLegacy) {
        if (protocolVersion >= 411 && protocolVersion <= 414) {
            if (useLegacy) {
                return PROTOCOL_CONFIGS.get(protocolVersion);
            } else {
                return MODERN_CONFIG;
            }
        }
        throw new IllegalArgumentException("Unsupported protocol version: " + protocolVersion);
    }
    
    /**
     * Получает современную конфигурацию RSA.
     *
     * @return современная конфигурация RSA
     */
    public static RSAConfig getModernConfig() {
        return MODERN_CONFIG;
    }
    
    /**
     * Получает модуль RSA в шестнадцатеричном формате.
     *
     * @return модуль RSA
     */
    public String getModulusHex() {
        return modulusHex;
    }
    
    /**
     * Получает приватную экспоненту в шестнадцатеричном формате.
     *
     * @return приватная экспонента
     */
    public String getPrivateExponentHex() {
        return privateExponentHex;
    }
    
    /**
     * Получает публичную экспоненту в шестнадцатеричном формате.
     *
     * @return публичная экспонента или null, если не задана
     */
    public String getPublicExponentHex() {
        return publicExponentHex;
    }
    
    /**
     * Проверяет, имеет ли конфигурация публичную экспоненту.
     *
     * @return true, если конфигурация имеет публичную экспоненту
     */
    public boolean hasPublicExponent() {
        return publicExponentHex != null && !publicExponentHex.isEmpty();
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.blowfish;

import com.laprizmo.crypto.FinishableOutputStream;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Выходной поток для шифрования данных алгоритмом Lineage 2 версии 2.1.x (Blowfish).
 * Поддерживает потоковое шифрование блоков данных.
 */
public class L2Ver21xOutputStream extends FinishableOutputStream {
    
    // Размер блока данных
    private static final int BLOCK_SIZE = 8;
    
    // Выходной поток для записи зашифрованных данных
    private final OutputStream out;
    
    // Движок Blowfish
    private final BlowfishEngine engine;
    
    // Буфер для накопления данных перед шифрованием
    private final byte[] buffer;
    
    // Текущая позиция в буфере
    private int bufferPos;
    
    /**
     * Создает новый выходной поток для шифрования.
     *
     * @param out    выходной поток для записи зашифрованных данных
     * @param engine движок Blowfish
     */
    public L2Ver21xOutputStream(OutputStream out, BlowfishEngine engine) {
        this.out = out;
        this.engine = engine;
        this.buffer = new byte[BLOCK_SIZE];
        this.bufferPos = 0;
    }
    
    @Override
    public void write(int b) throws IOException {
        buffer[bufferPos++] = (byte) b;
        
        if (bufferPos == BLOCK_SIZE) {
            flushBuffer();
        }
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException();
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException();
        }
        
        int bytesWritten = 0;
        while (bytesWritten < len) {
            // Определяем, сколько байт можно записать в буфер
            int bytesToWrite = Math.min(len - bytesWritten, BLOCK_SIZE - bufferPos);
            
            // Копируем данные в буфер
            System.arraycopy(b, off + bytesWritten, buffer, bufferPos, bytesToWrite);
            bufferPos += bytesToWrite;
            bytesWritten += bytesToWrite;
            
            // Если буфер заполнен, шифруем и записываем его
            if (bufferPos == BLOCK_SIZE) {
                flushBuffer();
            }
        }
    }
    
    /**
     * Шифрует и записывает буфер в выходной поток.
     */
    private void flushBuffer() throws IOException {
        if (bufferPos > 0) {
            try {
                // Если буфер не заполнен, дополняем его нулями
                if (bufferPos < BLOCK_SIZE) {
                    for (int i = bufferPos; i < BLOCK_SIZE; i++) {
                        buffer[i] = 0;
                    }
                }
                
                // Шифруем буфер
                byte[] encryptedBlock = engine.encryptBlock(buffer);
                
                // Записываем зашифрованный блок
                out.write(encryptedBlock);
                
                // Сбрасываем буфер
                bufferPos = 0;
            } catch (Exception e) {
                throw new IOException("Error encrypting data: " + e.getMessage(), e);
            }
        }
    }
    
    @Override
    public void flush() throws IOException {
        out.flush();
    }
    
    @Override
    public void finish() throws IOException {
        flushBuffer();
        out.flush();
    }
    
    @Override
    public void close() throws IOException {
        try {
            finish();
        } finally {
            out.close();
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.crypto.xor;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Входной поток для дешифрования данных Lineage 2 версии 1.2.0 с использованием XOR.
 * Отличается от стандартного XOR тем, что ключ динамически меняется в процессе дешифрования.
 */
public final class L2Ver120InputStream extends FilterInputStream {
    
    private static final Logger LOGGER = Logger.getLogger(L2Ver120InputStream.class.getName());
    
    private byte key;

    /**
     * Создает новый дешифрующий поток XOR для версии 1.2.0.
     *
     * @param input входной поток с зашифрованными данными
     */
    public L2Ver120InputStream(InputStream input) {
        super(Objects.requireNonNull(input, "input stream cannot be null"));
        this.key = L2Ver120.INITIAL_KEY;
    }

    @Override
    public int read() throws IOException {
        int value = in.read();
        if (value == -1) {
            return -1;
        }
        
        // Дешифруем байт с помощью текущего ключа
        byte decrypted = (byte) (value ^ key);
        
        // Обновляем ключ для следующего байта
        key = (byte) ((key + L2Ver120.KEY_INCREMENT) & 0xFF);
        
        return decrypted & 0xFF;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (b == null) {
            throw new NullPointerException("Buffer cannot be null");
        }
        
        if (off < 0 || len < 0 || off + len > b.length) {
            throw new IndexOutOfBoundsException("Invalid buffer parameters");
        }
        
        if (len == 0) {
            return 0;
        }
        
        int bytesRead = in.read(b, off, len);
        if (bytesRead == -1) {
            return -1;
        }
        
        // Дешифруем все прочитанные байты
        for (int i = 0; i < bytesRead; i++) {
            b[off + i] = (byte) (b[off + i] ^ key);
            key = (byte) ((key + L2Ver120.KEY_INCREMENT) & 0xFF);
        }
        
        return bytesRead;
    }
    
    @Override
    public long skip(long n) throws IOException {
        // При пропуске байтов нужно также обновить ключ
        // Читаем и отбрасываем по одному байту за раз, обновляя ключ
        long skipped = 0;
        for (long i = 0; i < n; i++) {
            int value = read();
            if (value == -1) {
                break;
            }
            skipped++;
        }
        return skipped;
    }
    
    @Override
    public void close() throws IOException {
        in.close();
    }
    
    @Override
    public synchronized void mark(int readlimit) {
        throw new UnsupportedOperationException("Mark not supported");
    }
    
    @Override
    public synchronized void reset() throws IOException {
        throw new UnsupportedOperationException("Reset not supported");
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
}
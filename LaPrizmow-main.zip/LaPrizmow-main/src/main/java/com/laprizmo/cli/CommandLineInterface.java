/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.cli;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolManager;
import com.laprizmo.crypto.rsa.RSAConfig;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Интерфейс командной строки для LaPrizmo.
 * Обеспечивает функциональность для запуска программы из командной строки с параметрами.
 */
public class CommandLineInterface {
    
    private static final Logger LOGGER = Logger.getLogger(CommandLineInterface.class.getName());
    
    // Параметры командной строки
    private String command = "decode";
    private Integer protocol = null;
    private String outputPath = null;
    private boolean verifyChecksum = false;
    private boolean noTail = false;
    private String forceFilename = null;
    private boolean useLegacyRSA = false;
    private String algorithm = null;
    private String modulusHex = null;
    private String exponentHex = null;
    private String blowfishKey = null;
    private String xorKey = null;
    private String startIndex = null;
    private String customHeader = null;
    private String customTail = null;
    private List<String> inputFiles = new ArrayList<>();
    
    // Экземпляр для работы с криптографией
    private final CryptoOperations cryptoOps;
    
    // Менеджер протоколов
    private final ProtocolManager protocolManager;
    
    /**
     * Создает новый интерфейс командной строки.
     */
    public CommandLineInterface() {
        this.cryptoOps = new CryptoOperations();
        this.protocolManager = ProtocolManager.getInstance();
    }
    
    /**
     * Парсит аргументы командной строки.
     *
     * @param args аргументы командной строки
     * @return true, если аргументы корректны и программа должна продолжить выполнение
     */
    public boolean parseArgs(String[] args) {
        if (args.length == 0) {
            return true; // Запуск GUI при отсутствии аргументов
        }
        
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            
            if ("-h".equals(arg)) {
                printHelp();
                return false;
            } else if ("-c".equals(arg) && i + 1 < args.length) {
                command = args[++i];
                if (!command.equals("encode") && !command.equals("decode")) {
                    System.err.println("Error: Command must be 'encode' or 'decode'");
                    return false;
                }
            } else if ("-p".equals(arg) && i + 1 < args.length) {
                try {
                    protocol = Integer.parseInt(args[++i]);
                } catch (NumberFormatException e) {
                    System.err.println("Error: Protocol must be a number");
                    return false;
                }
            } else if ("-o".equals(arg) && i + 1 < args.length) {
                outputPath = args[++i];
            } else if ("-v".equals(arg)) {
                verifyChecksum = true;
            } else if ("-t".equals(arg)) {
                noTail = true;
            } else if ("-f".equals(arg) && i + 1 < args.length) {
                forceFilename = args[++i];
            } else if ("-l".equals(arg)) {
                useLegacyRSA = true;
            } else if ("-a".equals(arg) && i + 1 < args.length) {
                algorithm = args[++i];
            } else if ("-m".equals(arg) && i + 1 < args.length) {
                modulusHex = args[++i];
            } else if ("-e".equals(arg) && i + 1 < args.length) {
                exponentHex = args[++i]; // Публичная экспонента
            } else if ("-d".equals(arg) && i + 1 < args.length) {
                exponentHex = args[++i]; // Приватная экспонента
            } else if ("-b".equals(arg) && i + 1 < args.length) {
                blowfishKey = args[++i];
            } else if ("-x".equals(arg) && i + 1 < args.length) {
                xorKey = args[++i];
            } else if ("-s".equals(arg) && i + 1 < args.length) {
                startIndex = args[++i];
            } else if ("-w".equals(arg) && i + 1 < args.length) {
                customHeader = args[++i];
            } else if ("-T".equals(arg) && i + 1 < args.length) {
                customTail = args[++i];
            } else {
                // Предполагаем, что это имя входного файла
                inputFiles.add(arg);
            }
        }
        
        // Проверяем, что указан хотя бы один входной файл
        if (inputFiles.isEmpty()) {
            System.err.println("Error: No input files specified");
            return false;
        }
        
        // Применяем параметры
        applyParameters();
        
        return true;
    }
    
    /**
     * Выполняет операции над файлами.
     */
    public void processFiles() {
        if (inputFiles.isEmpty()) {
            LOGGER.warning("No input files to process");
            return;
        }
        
        // Для каждого входного файла
        for (String inputFile : inputFiles) {
            try {
                String outPath = determineOutputPath(inputFile);
                
                // Создаем параметры операции
                CryptoOperations.CryptoParams params = createCryptoParams();
                
                // Выполняем операцию
                if ("encode".equals(command)) {
                    cryptoOps.encryptFile(inputFile, outPath, params);
                    LOGGER.info("Encrypted file: " + inputFile + " -> " + outPath);
                } else {
                    cryptoOps.decryptFile(inputFile, outPath, params);
                    LOGGER.info("Decrypted file: " + inputFile + " -> " + outPath);
                }
                
                System.out.println("Processed: " + inputFile + " -> " + outPath);
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error processing file: " + inputFile, e);
                System.err.println("Error processing file: " + inputFile + ": " + e.getMessage());
            }
        }
    }
    
    /**
     * Применяет параметры командной строки.
     */
    private void applyParameters() {
        // Устанавливаем режим использования устаревших RSA ключей
        protocolManager.setUseLegacyRSA(useLegacyRSA);
        
        // Устанавливаем пользовательский заголовок
        if (customHeader != null && protocol != null) {
            protocolManager.setCustomHeader(protocol, customHeader);
        }
        
        // Устанавливаем пользовательские ключи
        if (algorithm != null) {
            if ("blowfish".equals(algorithm) && blowfishKey != null && protocol != null) {
                protocolManager.setCustomBlowfishKey(protocol, blowfishKey);
            } else if ("xor".equals(algorithm) && xorKey != null && protocol != null) {
                try {
                    int key = Integer.parseInt(xorKey, 16);
                    protocolManager.setCustomXorKey(protocol, key);
                } catch (NumberFormatException e) {
                    LOGGER.warning("Invalid XOR key format: " + xorKey);
                }
            } else if ("xor_position".equals(algorithm) && startIndex != null && protocol != null) {
                try {
                    int index = Integer.parseInt(startIndex, 16);
                    protocolManager.setCustomXorKey(protocol, index);
                } catch (NumberFormatException e) {
                    LOGGER.warning("Invalid start index format: " + startIndex);
                }
            } else if ("rsa".equals(algorithm) && modulusHex != null && exponentHex != null && protocol != null) {
                RSAConfig config = new RSAConfig(modulusHex, exponentHex);
                protocolManager.setCustomRSAConfig(protocol, config);
            }
        }
    }
    
    /**
     * Создает параметры криптографической операции на основе аргументов командной строки.
     *
     * @return параметры операции
     */
    private CryptoOperations.CryptoParams createCryptoParams() {
        if (protocol == null) {
            // Используем протокол по умолчанию
            String defaultVersion = ConfigManager.getInstance().getProperty("DefaultCryptVersion");
            if (defaultVersion.contains("1.5")) {
                protocol = 111; // XOR для Classic 1.5
            } else if (defaultVersion.contains("2.1")) {
                protocol = 211; // Blowfish для 2.1
            } else if (defaultVersion.contains("4.1")) {
                protocol = 411; // RSA для 4.1
            } else {
                protocol = 510; // AES для 5.1+
            }
        }
        
        // Создаем параметры
        CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams(protocol);
        
        // Устанавливаем дополнительные параметры
        params.setVerifyChecksum(verifyChecksum);
        params.setHandleTail(!noTail);
        params.setForceFilename(forceFilename);
        params.setCustomHeader(customHeader);
        params.setCustomTail(customTail);
        
        return params;
    }
    
    /**
     * Определяет путь для выходного файла.
     *
     * @param inputFile путь к входному файлу
     * @return путь к выходному файлу
     */
    private String determineOutputPath(String inputFile) throws IOException {
        if (outputPath != null) {
            return outputPath;
        }
        
        // Генерируем имя выходного файла на основе входного
        File inFile = new File(inputFile);
        String baseName = inFile.getName();
        String extension = "";
        
        int dotIndex = baseName.lastIndexOf('.');
        if (dotIndex > 0) {
            extension = baseName.substring(dotIndex);
            baseName = baseName.substring(0, dotIndex);
        }
        
        String prefix = "encode".equals(command) ? "enc-" : "dec-";
        String outName = prefix + baseName + extension;
        
        return Paths.get(inFile.getParent(), outName).toString();
    }
    
    /**
     * Выводит справку по использованию программы.
     */
    private void printHelp() {
        System.out.println("LaPrizmo - Утилита для шифрования/дешифрования файлов Lineage 2");
        System.out.println();
        System.out.println("Использование: java -jar laprizmo.jar [options] input-file(s)");
        System.out.println();
        System.out.println("Опции:");
        System.out.println("  -h                    - вывод этой справки");
        System.out.println("  -c <command>          - команда: 'encode' или 'decode' (по умолчанию: 'decode')");
        System.out.println("  -p <protocol>         - версия протокола: 111, 120, 121, 211, 212, 411, 412, 413, 414, 510, etc.");
        System.out.println("  -o <path>             - путь для выходного файла");
        System.out.println("  -v                    - проверять контрольную сумму перед дешифрованием");
        System.out.println("  -t                    - не добавлять/не учитывать хвост файла");
        System.out.println("  -f <name>             - использовать указанное имя файла для протокола 121");
        System.out.println("  -l                    - использовать устаревшие RSA ключи для протоколов 411-414");
        System.out.println();
        System.out.println("Расширенные опции:");
        System.out.println("  -a <algorithm>        - алгоритм шифрования: 'blowfish', 'rsa', 'xor', 'xor_position', 'xor_filename'");
        System.out.println("  -m <hex>              - пользовательский модуль для RSA в hex-формате");
        System.out.println("  -e/-d <hex>           - пользовательская публичная или приватная экспонента для RSA в hex");
        System.out.println("  -b <string>           - пользовательский ключ для Blowfish");
        System.out.println("  -x <hex>              - пользовательский ключ для XOR в hex-формате");
        System.out.println("  -s <hex>              - пользовательский стартовый индекс для XOR_POSITION в hex");
        System.out.println("  -w <string>           - пользовательский заголовок (по умолчанию: Lineage2Ver + протокол)");
        System.out.println("  -T <hex>              - пользовательский хвост для шифрования, должен быть ровно 40 символов");
        System.out.println();
        System.out.println("Примеры:");
        System.out.println("  java -jar laprizmo.jar -c decode filename.ini");
        System.out.println("  java -jar laprizmo.jar -c encode -p 413 -o enc-filename.ini dec-filename.ini");
        System.out.println("  java -jar laprizmo.jar -c decode -a rsa -m 75b4d6...e2039 -d 1d -w Lineage2Ver413 -o dec-filename.ini filename.ini");
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.cli;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Обработчик командной строки для LaPrizmo.
 * Разбирает аргументы командной строки и осуществляет дальнейшую обработку.
 */
public class CommandLineProcessor {
    
    private static final Logger LOGGER = Logger.getLogger(CommandLineProcessor.class.getName());
    
    /**
     * Обрабатывает аргументы командной строки.
     *
     * @param args аргументы командной строки
     * @return true, если аргументы были обработаны и не требуется запуск GUI, false - в противном случае
     */
    public static boolean processArgs(String[] args) {
        if (args == null || args.length == 0) {
            return false; // Нет аргументов, запускаем GUI
        }
        
        try {
            CommandLineInterface cli = new CommandLineInterface();
            if (cli.parseArgs(args)) {
                cli.processFiles();
                return true; // Аргументы обработаны, GUI не запускается
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error processing command line arguments", e);
            System.err.println("Error: " + e.getMessage());
        }
        
        return false; // По умолчанию запускаем GUI
    }
}
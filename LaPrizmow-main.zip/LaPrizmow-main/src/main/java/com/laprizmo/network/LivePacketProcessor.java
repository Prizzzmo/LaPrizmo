/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.network;

import com.laprizmo.core.ProtocolManager;
import com.laprizmo.crypto.CryptoException;
import com.laprizmo.plugin.PluginContext;
import com.laprizmo.plugin.PluginManager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Обработчик сетевых пакетов Lineage 2 в реальном времени.
 * Позволяет перехватывать, дешифровать, анализировать и модифицировать сетевые пакеты.
 */
public class LivePacketProcessor {
    
    private static final Logger LOGGER = Logger.getLogger(LivePacketProcessor.class.getName());
    
    // Очередь необработанных пакетов
    private final BlockingQueue<L2Packet> packetQueue = new LinkedBlockingQueue<>();
    
    // Менеджер протоколов
    private final ProtocolManager protocolManager;
    
    // Менеджер плагинов
    private final PluginManager pluginManager;
    
    // Версия протокола для дешифрования
    private int protocol;
    
    // Флаг паузы обработки
    private volatile boolean paused = false;
    
    // Флаг продолжения работы
    private volatile boolean running = false;
    
    // Флаг модификации пакетов
    private boolean enableModification = false;
    
    // Потребитель для обработанных пакетов
    private Consumer<L2Packet> packetConsumer;
    
    // Потребитель для ошибок
    private Consumer<Exception> errorConsumer;
    
    // Поток обработки
    private Thread processingThread;
    
    /**
     * Создает новый обработчик пакетов.
     *
     * @param protocol версия протокола для дешифрования
     */
    public LivePacketProcessor(int protocol) {
        this.protocol = protocol;
        this.protocolManager = ProtocolManager.getInstance();
        this.pluginManager = PluginManager.getInstance();
    }
    
    /**
     * Создает новый обработчик пакетов с потребителем для обработанных пакетов.
     *
     * @param protocol версия протокола для дешифрования
     * @param packetConsumer потребитель для обработанных пакетов
     */
    public LivePacketProcessor(int protocol, Consumer<L2Packet> packetConsumer) {
        this(protocol);
        this.packetConsumer = packetConsumer;
    }
    
    /**
     * Создает новый обработчик пакетов с потребителями для пакетов и ошибок.
     *
     * @param protocol версия протокола для дешифрования
     * @param packetConsumer потребитель для обработанных пакетов
     * @param errorConsumer потребитель для ошибок
     */
    public LivePacketProcessor(int protocol, Consumer<L2Packet> packetConsumer, Consumer<Exception> errorConsumer) {
        this(protocol, packetConsumer);
        this.errorConsumer = errorConsumer;
    }
    
    /**
     * Запускает обработку пакетов.
     */
    public synchronized void start() {
        if (running) {
            return;
        }
        
        running = true;
        paused = false;
        
        processingThread = new Thread(this::processPackets);
        processingThread.setName("L2PacketProcessor");
        processingThread.setDaemon(true);
        processingThread.start();
        
        LOGGER.info("Packet processor started with protocol: " + protocol);
    }
    
    /**
     * Останавливает обработку пакетов.
     */
    public synchronized void stop() {
        if (!running) {
            return;
        }
        
        running = false;
        
        if (processingThread != null) {
            processingThread.interrupt();
            processingThread = null;
        }
        
        packetQueue.clear();
        LOGGER.info("Packet processor stopped");
    }
    
    /**
     * Приостанавливает обработку пакетов.
     */
    public void pause() {
        paused = true;
        LOGGER.info("Packet processor paused");
    }
    
    /**
     * Возобновляет обработку пакетов.
     */
    public void resume() {
        paused = false;
        LOGGER.info("Packet processor resumed");
    }
    
    /**
     * Проверяет, запущена ли обработка пакетов.
     *
     * @return true, если обработка запущена
     */
    public boolean isRunning() {
        return running;
    }
    
    /**
     * Проверяет, приостановлена ли обработка пакетов.
     *
     * @return true, если обработка приостановлена
     */
    public boolean isPaused() {
        return paused;
    }
    
    /**
     * Устанавливает протокол для дешифрования.
     *
     * @param protocol версия протокола
     */
    public void setProtocol(int protocol) {
        this.protocol = protocol;
        LOGGER.info("Packet processor protocol set to: " + protocol);
    }
    
    /**
     * Устанавливает потребителя для обработанных пакетов.
     *
     * @param packetConsumer потребитель для обработанных пакетов
     */
    public void setPacketConsumer(Consumer<L2Packet> packetConsumer) {
        this.packetConsumer = packetConsumer;
    }
    
    /**
     * Устанавливает потребителя для ошибок.
     *
     * @param errorConsumer потребитель для ошибок
     */
    public void setErrorConsumer(Consumer<Exception> errorConsumer) {
        this.errorConsumer = errorConsumer;
    }
    
    /**
     * Включает или отключает модификацию пакетов.
     *
     * @param enable true для включения модификации
     */
    public void setEnableModification(boolean enable) {
        this.enableModification = enable;
        LOGGER.info("Packet modification " + (enable ? "enabled" : "disabled"));
    }
    
    /**
     * Проверяет, включена ли модификация пакетов.
     *
     * @return true, если модификация включена
     */
    public boolean isModificationEnabled() {
        return enableModification;
    }
    
    /**
     * Добавляет пакет в очередь на обработку.
     *
     * @param packet пакет для обработки
     */
    public void addPacket(L2Packet packet) {
        if (running && !paused) {
            packetQueue.offer(packet);
        }
    }
    
    /**
     * Добавляет пакет в очередь на обработку из массива байтов.
     *
     * @param data массив байтов пакета
     * @param type тип пакета
     */
    public void addPacket(byte[] data, L2Packet.PacketType type) {
        if (running && !paused) {
            L2Packet packet = new L2Packet(data, type, L2Packet.PacketState.RAW, protocol);
            packetQueue.offer(packet);
        }
    }
    
    /**
     * Обрабатывает набор байтов из сетевого потока, выделяя из них пакеты.
     *
     * @param data массив байтов из сетевого потока
     * @param type тип пакетов
     * @return список выделенных пакетов
     */
    public List<L2Packet> processNetworkData(byte[] data, L2Packet.PacketType type) {
        List<L2Packet> packets = new ArrayList<>();
        
        if (data == null || data.length < 2) {
            return packets;
        }
        
        int offset = 0;
        while (offset < data.length) {
            // Проверяем, что осталось достаточно данных для заголовка
            if (data.length - offset < 2) {
                break;
            }
            
            // Читаем размер пакета из заголовка
            ByteBuffer buffer = ByteBuffer.wrap(data, offset, 2);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            int packetSize = buffer.getShort() & 0xFFFF;
            
            // Проверяем корректность размера
            if (packetSize <= 0 || packetSize > data.length - offset) {
                break;
            }
            
            // Выделяем данные пакета
            byte[] packetData = new byte[packetSize];
            System.arraycopy(data, offset, packetData, 0, packetSize);
            
            // Создаем пакет и добавляем его в список
            L2Packet packet = new L2Packet(packetData, type, L2Packet.PacketState.RAW, protocol);
            packets.add(packet);
            
            // Предлагаем пакет для обработки
            if (running && !paused) {
                packetQueue.offer(packet);
            }
            
            // Перемещаем смещение
            offset += packetSize;
        }
        
        return packets;
    }
    
    /**
     * Основной метод обработки пакетов из очереди.
     */
    private void processPackets() {
        while (running) {
            try {
                if (paused) {
                    Thread.sleep(100);
                    continue;
                }
                
                // Извлекаем пакет из очереди с ожиданием до 500 мс
                L2Packet packet = packetQueue.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS);
                if (packet == null) {
                    continue;
                }
                
                // Обрабатываем пакет
                L2Packet processedPacket = processPacket(packet);
                
                // Оповещаем потребителя об обработанном пакете
                if (processedPacket != null && packetConsumer != null) {
                    packetConsumer.accept(processedPacket);
                }
            } catch (InterruptedException e) {
                if (!running) {
                    break;
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error processing packet", e);
                if (errorConsumer != null) {
                    errorConsumer.accept(e);
                }
            }
        }
    }
    
    /**
     * Обрабатывает отдельный пакет.
     *
     * @param packet пакет для обработки
     * @return обработанный пакет
     */
    private L2Packet processPacket(L2Packet packet) {
        if (packet == null) {
            return null;
        }
        
        try {
            // Дешифруем пакет, если он в RAW состоянии
            L2Packet decryptedPacket = packet;
            if (packet.getState() == L2Packet.PacketState.RAW) {
                decryptedPacket = decryptPacket(packet);
                if (decryptedPacket == null) {
                    return packet; // Не удалось дешифровать
                }
            }
            
            // Применяем плагины для анализа пакета
            if (enableModification && pluginManager != null) {
                PluginContext context = new PluginContext(decryptedPacket);
                pluginManager.executePlugins(context);
                
                // Если пакет был модифицирован плагинами
                if (context.isPacketModified()) {
                    L2Packet modifiedPacket = context.getModifiedPacket();
                    
                    // Шифруем модифицированный пакет
                    return encryptPacket(modifiedPacket);
                }
            }
            
            return decryptedPacket;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error processing packet", e);
            if (errorConsumer != null) {
                errorConsumer.accept(e);
            }
            return packet;
        }
    }
    
    /**
     * Дешифрует пакет.
     *
     * @param packet пакет для дешифрования
     * @return дешифрованный пакет или null в случае ошибки
     */
    private L2Packet decryptPacket(L2Packet packet) {
        try {
            byte[] encryptedData = packet.getData();
            
            // Создаем поток для дешифрования
            try (ByteArrayInputStream inputStream = new ByteArrayInputStream(encryptedData);
                 InputStream decStream = protocolManager.getDecryptionInputStream(inputStream, protocol, null);
                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                
                // Копируем данные из дешифрующего потока
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = decStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                
                byte[] decryptedData = outputStream.toByteArray();
                
                // Создаем новый пакет с дешифрованными данными
                return new L2Packet(decryptedData, packet.getType(), L2Packet.PacketState.DECRYPTED, packet.getProtocol());
            }
        } catch (CryptoException | IOException e) {
            LOGGER.log(Level.WARNING, "Error decrypting packet", e);
            return null;
        }
    }
    
    /**
     * Шифрует пакет.
     *
     * @param packet пакет для шифрования
     * @return зашифрованный пакет или null в случае ошибки
     */
    private L2Packet encryptPacket(L2Packet packet) {
        try {
            byte[] decryptedData = packet.getData();
            
            // Создаем потоки для шифрования
            try (ByteArrayInputStream inputStream = new ByteArrayInputStream(decryptedData);
                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                
                // Получаем выходной поток для шифрования
                try (ByteArrayOutputStream encStream = 
                        (ByteArrayOutputStream) protocolManager.getEncryptionOutputStream(outputStream, protocol, null)) {
                    
                    // Копируем данные в шифрующий поток
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        encStream.write(buffer, 0, bytesRead);
                    }
                }
                
                byte[] encryptedData = outputStream.toByteArray();
                
                // Создаем новый пакет с зашифрованными данными
                return new L2Packet(encryptedData, packet.getType(), L2Packet.PacketState.ENCRYPTED, packet.getProtocol());
            }
        } catch (CryptoException | IOException e) {
            LOGGER.log(Level.WARNING, "Error encrypting packet", e);
            return null;
        }
    }
}
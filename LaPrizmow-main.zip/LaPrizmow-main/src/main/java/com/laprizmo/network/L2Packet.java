/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.network;

import com.laprizmo.util.DatFileUtils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/**
 * Представляет сетевой пакет Lineage 2.
 * Класс обеспечивает доступ к заголовку и содержимому пакета,
 * а также предоставляет методы для манипуляции его данными.
 */
public class L2Packet {
    
    // Типы пакетов
    public enum PacketType {
        CLIENT_TO_SERVER,
        SERVER_TO_CLIENT,
        UNKNOWN
    }
    
    // Флаги состояния пакета
    public enum PacketState {
        RAW,            // Необработанный пакет
        DECRYPTED,      // Расшифрованный пакет
        ENCRYPTED,      // Зашифрованный пакет
        MODIFIED        // Измененный пакет
    }
    
    // Размер заголовка пакета (2 байта для размера пакета, 1 байт для типа пакета)
    private static final int HEADER_SIZE = 3;
    
    // Данные пакета
    private byte[] data;
    
    // Направление пакета
    private PacketType type;
    
    // Состояние пакета
    private PacketState state;
    
    // Временная метка пакета
    private long timestamp;
    
    // Протокол шифрования
    private int protocol;
    
    // Флаг обфускации (для некоторых версий протокола)
    private boolean obfuscated;
    
    /**
     * Создает новый пакет из массива байтов.
     *
     * @param data  массив байтов пакета
     * @param type  тип пакета
     * @param state состояние пакета
     */
    public L2Packet(byte[] data, PacketType type, PacketState state) {
        this.data = data;
        this.type = type;
        this.state = state;
        this.timestamp = System.currentTimeMillis();
        this.protocol = 0;
        this.obfuscated = false;
    }
    
    /**
     * Создает новый пакет с указанием протокола.
     *
     * @param data     массив байтов пакета
     * @param type     тип пакета
     * @param state    состояние пакета
     * @param protocol протокол шифрования
     */
    public L2Packet(byte[] data, PacketType type, PacketState state, int protocol) {
        this(data, type, state);
        this.protocol = protocol;
    }
    
    /**
     * Создает новый пакет с указанием протокола и флага обфускации.
     *
     * @param data       массив байтов пакета
     * @param type       тип пакета
     * @param state      состояние пакета
     * @param protocol   протокол шифрования
     * @param obfuscated флаг обфускации
     */
    public L2Packet(byte[] data, PacketType type, PacketState state, int protocol, boolean obfuscated) {
        this(data, type, state, protocol);
        this.obfuscated = obfuscated;
    }
    
    /**
     * Создает новый пакет, копируя данные из существующего.
     *
     * @param packet     исходный пакет
     * @param newData    новые данные пакета
     * @param newState   новое состояние пакета
     */
    public L2Packet(L2Packet packet, byte[] newData, PacketState newState) {
        this.data = newData;
        this.type = packet.type;
        this.state = newState;
        this.timestamp = packet.timestamp;
        this.protocol = packet.protocol;
        this.obfuscated = packet.obfuscated;
    }
    
    /**
     * Получает размер пакета из его заголовка.
     *
     * @param rawPacket необработанный пакет с заголовком
     * @return размер пакета или -1, если невозможно определить размер
     */
    public static int getPacketSize(byte[] rawPacket) {
        if (rawPacket == null || rawPacket.length < 2) {
            return -1;
        }
        
        // Размер пакета в заголовке - первые 2 байта в Little Endian
        ByteBuffer buffer = ByteBuffer.wrap(rawPacket, 0, 2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getShort() & 0xFFFF;
    }
    
    /**
     * Получает тип пакета из его заголовка.
     *
     * @param rawPacket необработанный пакет с заголовком
     * @return код типа пакета или -1, если невозможно определить тип
     */
    public static int getPacketType(byte[] rawPacket) {
        if (rawPacket == null || rawPacket.length < 3) {
            return -1;
        }
        
        // Тип пакета - третий байт
        return rawPacket[2] & 0xFF;
    }
    
    /**
     * Создает новый пакет из существующего, изменяя его данные.
     *
     * @param newContent новое содержимое пакета (без заголовка)
     * @return новый пакет с измененным содержимым
     */
    public L2Packet createModified(byte[] newContent) {
        // Создаем новый массив для данных с заголовком
        byte[] newData = new byte[HEADER_SIZE + newContent.length];
        
        // Заполняем заголовок
        ByteBuffer buffer = ByteBuffer.wrap(newData, 0, 2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.putShort((short) (HEADER_SIZE + newContent.length));
        
        // Копируем тип пакета из исходного заголовка
        if (data != null && data.length >= 3) {
            newData[2] = data[2];
        }
        
        // Копируем новое содержимое
        System.arraycopy(newContent, 0, newData, HEADER_SIZE, newContent.length);
        
        // Возвращаем новый пакет с состоянием MODIFIED
        return new L2Packet(this, newData, PacketState.MODIFIED);
    }
    
    /**
     * Получает содержимое пакета без заголовка.
     *
     * @return содержимое пакета
     */
    public byte[] getContent() {
        if (data == null || data.length <= HEADER_SIZE) {
            return new byte[0];
        }
        
        byte[] content = new byte[data.length - HEADER_SIZE];
        System.arraycopy(data, HEADER_SIZE, content, 0, content.length);
        return content;
    }
    
    /**
     * Получает полные данные пакета включая заголовок.
     *
     * @return данные пакета
     */
    public byte[] getData() {
        return data != null ? data.clone() : new byte[0];
    }
    
    /**
     * Получает размер пакета.
     *
     * @return размер пакета в байтах
     */
    public int getSize() {
        return data != null ? data.length : 0;
    }
    
    /**
     * Получает тип пакета.
     *
     * @return тип пакета
     */
    public PacketType getType() {
        return type;
    }
    
    /**
     * Устанавливает тип пакета.
     *
     * @param type тип пакета
     */
    public void setType(PacketType type) {
        this.type = type;
    }
    
    /**
     * Получает состояние пакета.
     *
     * @return состояние пакета
     */
    public PacketState getState() {
        return state;
    }
    
    /**
     * Устанавливает состояние пакета.
     *
     * @param state состояние пакета
     */
    public void setState(PacketState state) {
        this.state = state;
    }
    
    /**
     * Получает временную метку пакета.
     *
     * @return временная метка пакета в миллисекундах
     */
    public long getTimestamp() {
        return timestamp;
    }
    
    /**
     * Получает протокол шифрования пакета.
     *
     * @return протокол шифрования
     */
    public int getProtocol() {
        return protocol;
    }
    
    /**
     * Устанавливает протокол шифрования пакета.
     *
     * @param protocol протокол шифрования
     */
    public void setProtocol(int protocol) {
        this.protocol = protocol;
    }
    
    /**
     * Проверяет, обфусцирован ли пакет.
     *
     * @return true, если пакет обфусцирован
     */
    public boolean isObfuscated() {
        return obfuscated;
    }
    
    /**
     * Устанавливает флаг обфускации пакета.
     *
     * @param obfuscated флаг обфускации
     */
    public void setObfuscated(boolean obfuscated) {
        this.obfuscated = obfuscated;
    }
    
    /**
     * Получает код опкода пакета (первый байт содержимого).
     *
     * @return код опкода или -1, если не удается определить
     */
    public int getOpcode() {
        byte[] content = getContent();
        return content.length > 0 ? content[0] & 0xFF : -1;
    }
    
    /**
     * Получает строковое представление пакета в HEX-формате.
     *
     * @return строковое представление пакета
     */
    public String toHexString() {
        return data != null ? DatFileUtils.byteArrayToHexString(data) : "";
    }
    
    /**
     * Получает строковое представление содержимого пакета в HEX-формате.
     *
     * @return строковое представление содержимого пакета
     */
    public String getContentHexString() {
        return DatFileUtils.byteArrayToHexString(getContent());
    }
    
    /**
     * Возвращает строковое представление пакета.
     *
     * @return строковое представление пакета
     */
    @Override
    public String toString() {
        return "L2Packet{" +
               "size=" + getSize() +
               ", type=" + type +
               ", state=" + state +
               ", protocol=" + protocol +
               ", opcode=0x" + Integer.toHexString(getOpcode()).toUpperCase() +
               "}";
    }
    
    /**
     * Проверяет, равен ли данный пакет другому объекту.
     *
     * @param obj объект для сравнения
     * @return true, если объекты равны
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        L2Packet packet = (L2Packet) obj;
        
        if (timestamp != packet.timestamp) return false;
        if (protocol != packet.protocol) return false;
        if (obfuscated != packet.obfuscated) return false;
        if (!Arrays.equals(data, packet.data)) return false;
        if (type != packet.type) return false;
        return state == packet.state;
    }
    
    /**
     * Возвращает хеш-код пакета.
     *
     * @return хеш-код пакета
     */
    @Override
    public int hashCode() {
        int result = Arrays.hashCode(data);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + (int) (timestamp ^ (timestamp >>> 32));
        result = 31 * result + protocol;
        result = 31 * result + (obfuscated ? 1 : 0);
        return result;
    }
}
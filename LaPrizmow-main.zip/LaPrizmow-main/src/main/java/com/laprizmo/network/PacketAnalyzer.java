/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.network;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Анализатор сетевых пакетов Lineage 2.
 * Предоставляет функциональность для анализа содержимого пакетов,
 * извлечения данных и идентификации типов пакетов.
 */
public class PacketAnalyzer {
    
    // Карта известных опкодов клиентских пакетов
    private static final Map<Integer, String> CLIENT_OPCODES = new HashMap<>();
    
    // Карта известных опкодов серверных пакетов
    private static final Map<Integer, String> SERVER_OPCODES = new HashMap<>();
    
    static {
        // Инициализация известных опкодов клиентских пакетов
        CLIENT_OPCODES.put(0x00, "ProtocolVersion");
        CLIENT_OPCODES.put(0x01, "MoveToLocation");
        CLIENT_OPCODES.put(0x03, "EnterWorld");
        CLIENT_OPCODES.put(0x04, "Action");
        CLIENT_OPCODES.put(0x09, "Logout");
        CLIENT_OPCODES.put(0x0A, "AttackRequest");
        CLIENT_OPCODES.put(0x0B, "CharacterSelect");
        CLIENT_OPCODES.put(0x0D, "RequestNewCharacter");
        CLIENT_OPCODES.put(0x0E, "NewCharacter");
        CLIENT_OPCODES.put(0x0F, "RequestItemList");
        CLIENT_OPCODES.put(0x11, "RequestUnEquipItem");
        CLIENT_OPCODES.put(0x12, "RequestDropItem");
        CLIENT_OPCODES.put(0x14, "RequestUseItem");
        CLIENT_OPCODES.put(0x15, "RequestTradeRequest");
        CLIENT_OPCODES.put(0x16, "RequestAddTradeItem");
        CLIENT_OPCODES.put(0x17, "RequestTradeDone");
        CLIENT_OPCODES.put(0x1A, "RequestSocialAction");
        CLIENT_OPCODES.put(0x1B, "ChangeMoveType");
        CLIENT_OPCODES.put(0x1C, "ChangeWaitType");
        CLIENT_OPCODES.put(0x21, "RequestLinkHtml");
        CLIENT_OPCODES.put(0x22, "RequestBypassToServer");
        CLIENT_OPCODES.put(0x23, "RequestBBSwrite");
        CLIENT_OPCODES.put(0x24, "RequestCreatePledge");
        CLIENT_OPCODES.put(0x25, "RequestJoinPledge");
        CLIENT_OPCODES.put(0x26, "RequestAnswerJoinPledge");
        CLIENT_OPCODES.put(0x29, "RequestActionUse");
        CLIENT_OPCODES.put(0x2C, "RequestRestartPoint");
        CLIENT_OPCODES.put(0x2E, "RequestSiegeAttackerList");
        CLIENT_OPCODES.put(0x2F, "RequestSiegeDefenderList");
        CLIENT_OPCODES.put(0x30, "RequestJoinSiege");
        CLIENT_OPCODES.put(0x31, "RequestConfirmSiegeWaitingList");
        CLIENT_OPCODES.put(0x32, "RequestSetCastleSiegeTime");
        CLIENT_OPCODES.put(0x33, "RequestMultiSellChoose");
        CLIENT_OPCODES.put(0x34, "RequestConfirmCancelItem");
        CLIENT_OPCODES.put(0x35, "RequestConfirmRefinerItem");
        CLIENT_OPCODES.put(0x36, "RequestConfirmGemStone");
        CLIENT_OPCODES.put(0x37, "RequestRefine");
        CLIENT_OPCODES.put(0x38, "RequestConfirmCancelCrystallize");
        CLIENT_OPCODES.put(0x39, "RequestConfirmCrystallize");
        CLIENT_OPCODES.put(0x3A, "RequestQuestList");
        CLIENT_OPCODES.put(0x3B, "RequestQuestAbort");
        
        // Инициализация известных опкодов серверных пакетов
        SERVER_OPCODES.put(0x00, "ProtocolVersion");
        SERVER_OPCODES.put(0x01, "LoginFail");
        SERVER_OPCODES.put(0x03, "CharacterCreateSuccess");
        SERVER_OPCODES.put(0x04, "CharacterCreateFail");
        SERVER_OPCODES.put(0x05, "CharacterList");
        SERVER_OPCODES.put(0x06, "CharacterSelected");
        SERVER_OPCODES.put(0x07, "CharacterDeleteSuccess");
        SERVER_OPCODES.put(0x08, "CharacterDeleteFail");
        SERVER_OPCODES.put(0x09, "LoggedIn");
        SERVER_OPCODES.put(0x0B, "CharacterSelectionInfo");
        SERVER_OPCODES.put(0x0D, "UserInfo");
        SERVER_OPCODES.put(0x0E, "ItemList");
        SERVER_OPCODES.put(0x0F, "StatusUpdate");
        SERVER_OPCODES.put(0x10, "NpcInfo");
        SERVER_OPCODES.put(0x11, "InventoryUpdate");
        SERVER_OPCODES.put(0x12, "AddItem");
        SERVER_OPCODES.put(0x14, "SystemMessage");
        SERVER_OPCODES.put(0x16, "DropItem");
        SERVER_OPCODES.put(0x17, "GetItem");
        SERVER_OPCODES.put(0x18, "StatusUpdate");
        SERVER_OPCODES.put(0x19, "TradeStart");
        SERVER_OPCODES.put(0x1A, "TradeStartOk");
        SERVER_OPCODES.put(0x1B, "TradeOwnAdd");
        SERVER_OPCODES.put(0x1C, "TradeOtherAdd");
        SERVER_OPCODES.put(0x1D, "TradeDone");
        SERVER_OPCODES.put(0x20, "MagicSkillUse");
        SERVER_OPCODES.put(0x22, "TeleportToLocation");
        SERVER_OPCODES.put(0x23, "TargetSelected");
        SERVER_OPCODES.put(0x24, "TargetUnselected");
        SERVER_OPCODES.put(0x25, "AutoAttackStart");
        SERVER_OPCODES.put(0x26, "AutoAttackStop");
        SERVER_OPCODES.put(0x27, "SocialAction");
        SERVER_OPCODES.put(0x28, "ChangeMoveType");
        SERVER_OPCODES.put(0x29, "ChangeWaitType");
        SERVER_OPCODES.put(0x2C, "SellList");
        SERVER_OPCODES.put(0x2D, "BuyList");
        SERVER_OPCODES.put(0x2E, "DeleteObject");
        SERVER_OPCODES.put(0x2F, "CharacterMoveToLocation");
    }
    
    /**
     * Получает имя пакета по его опкоду и типу.
     *
     * @param opcode код операции пакета
     * @param type тип пакета (клиентский или серверный)
     * @return имя пакета или null, если опкод неизвестен
     */
    public static String getPacketName(int opcode, L2Packet.PacketType type) {
        if (type == L2Packet.PacketType.CLIENT_TO_SERVER) {
            return CLIENT_OPCODES.getOrDefault(opcode, null);
        } else if (type == L2Packet.PacketType.SERVER_TO_CLIENT) {
            return SERVER_OPCODES.getOrDefault(opcode, null);
        }
        return null;
    }
    
    /**
     * Получает имя пакета.
     *
     * @param packet пакет для анализа
     * @return имя пакета или null, если опкод неизвестен
     */
    public static String getPacketName(L2Packet packet) {
        if (packet == null) {
            return null;
        }
        
        int opcode = packet.getOpcode();
        return getPacketName(opcode, packet.getType());
    }
    
    /**
     * Извлекает строку из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченная строка
     */
    public static String extractString(byte[] data, int offset) {
        if (data == null || offset >= data.length) {
            return "";
        }
        
        // Ищем нулевой байт, обозначающий конец строки
        int endOffset = offset;
        while (endOffset < data.length && data[endOffset] != 0) {
            endOffset++;
        }
        
        // Извлекаем строку как массив байтов и преобразуем в строку
        byte[] stringBytes = Arrays.copyOfRange(data, offset, endOffset);
        return new String(stringBytes);
    }
    
    /**
     * Извлекает целое число (int) из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченное число
     */
    public static int extractInt(byte[] data, int offset) {
        if (data == null || offset + 3 >= data.length) {
            return 0;
        }
        
        ByteBuffer buffer = ByteBuffer.wrap(data, offset, 4);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getInt();
    }
    
    /**
     * Извлекает короткое целое число (short) из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченное число
     */
    public static short extractShort(byte[] data, int offset) {
        if (data == null || offset + 1 >= data.length) {
            return 0;
        }
        
        ByteBuffer buffer = ByteBuffer.wrap(data, offset, 2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getShort();
    }
    
    /**
     * Извлекает длинное целое число (long) из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченное число
     */
    public static long extractLong(byte[] data, int offset) {
        if (data == null || offset + 7 >= data.length) {
            return 0;
        }
        
        ByteBuffer buffer = ByteBuffer.wrap(data, offset, 8);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getLong();
    }
    
    /**
     * Извлекает байт из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченный байт
     */
    public static byte extractByte(byte[] data, int offset) {
        if (data == null || offset >= data.length) {
            return 0;
        }
        
        return data[offset];
    }
    
    /**
     * Извлекает двойную точность с плавающей запятой (double) из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченное число
     */
    public static double extractDouble(byte[] data, int offset) {
        if (data == null || offset + 7 >= data.length) {
            return 0.0;
        }
        
        ByteBuffer buffer = ByteBuffer.wrap(data, offset, 8);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getDouble();
    }
    
    /**
     * Извлекает точность с плавающей запятой (float) из данных пакета.
     *
     * @param data массив байтов данных
     * @param offset смещение в массиве
     * @return извлеченное число
     */
    public static float extractFloat(byte[] data, int offset) {
        if (data == null || offset + 3 >= data.length) {
            return 0.0f;
        }
        
        ByteBuffer buffer = ByteBuffer.wrap(data, offset, 4);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getFloat();
    }
    
    /**
     * Создает строковое представление данных пакета с разбивкой и аннотациями.
     *
     * @param packet пакет для анализа
     * @return строковое представление данных пакета
     */
    public static String formatPacketData(L2Packet packet) {
        if (packet == null) {
            return "Null packet";
        }
        
        byte[] data = packet.getData();
        if (data == null || data.length == 0) {
            return "Empty packet data";
        }
        
        StringBuilder sb = new StringBuilder();
        String packetName = getPacketName(packet);
        
        sb.append("Packet: ").append(packet.getType()).append(" - ");
        if (packetName != null) {
            sb.append(packetName).append(" (0x").append(String.format("%02X", packet.getOpcode())).append(")");
        } else {
            sb.append("Unknown (0x").append(String.format("%02X", packet.getOpcode())).append(")");
        }
        sb.append("\n");
        
        sb.append("Size: ").append(data.length).append(" bytes\n");
        sb.append("State: ").append(packet.getState()).append("\n");
        
        sb.append("Data:\n");
        
        // Форматирование шестнадцатеричных данных с разбивкой по строкам
        final int BYTES_PER_LINE = 16;
        final int BYTES_PER_GROUP = 4;
        
        for (int i = 0; i < data.length; i += BYTES_PER_LINE) {
            // Адрес смещения
            sb.append(String.format("%04X: ", i));
            
            // Шестнадцатеричные значения
            for (int j = 0; j < BYTES_PER_LINE; j++) {
                if (j > 0 && j % BYTES_PER_GROUP == 0) {
                    sb.append(" ");
                }
                
                if (i + j < data.length) {
                    sb.append(String.format("%02X ", data[i + j] & 0xFF));
                } else {
                    sb.append("   ");
                }
            }
            
            sb.append(" ");
            
            // ASCII представление
            for (int j = 0; j < BYTES_PER_LINE; j++) {
                if (i + j < data.length) {
                    byte b = data[i + j];
                    if (b >= 32 && b < 127) {
                        sb.append((char) b);
                    } else {
                        sb.append(".");
                    }
                }
            }
            
            sb.append("\n");
        }
        
        return sb.toString();
    }
    
    /**
     * Анализирует известные типы пакетов и извлекает структурированную информацию.
     *
     * @param packet пакет для анализа
     * @return строковое представление структурированной информации о пакете
     */
    public static String analyzePacketStructure(L2Packet packet) {
        if (packet == null) {
            return "Null packet";
        }
        
        String packetName = getPacketName(packet);
        if (packetName == null) {
            return "Unknown packet structure";
        }
        
        byte[] content = packet.getContent();
        StringBuilder sb = new StringBuilder();
        
        sb.append("Packet Structure: ").append(packetName).append("\n");
        
        // В зависимости от типа пакета извлекаем информацию
        switch (packetName) {
            case "ProtocolVersion":
                if (content.length >= 4) {
                    int version = extractInt(content, 1);
                    sb.append("Protocol Version: ").append(version);
                }
                break;
                
            case "MoveToLocation":
                if (content.length >= 15) {
                    int targetId = extractInt(content, 1);
                    int x = extractInt(content, 5);
                    int y = extractInt(content, 9);
                    int z = extractInt(content, 13);
                    sb.append("Target ID: ").append(targetId).append("\n");
                    sb.append("Target Location: (").append(x).append(", ").append(y).append(", ").append(z).append(")");
                }
                break;
                
            case "UserInfo":
                if (content.length >= 20) {
                    int objectId = extractInt(content, 1);
                    String name = extractString(content, 5);
                    sb.append("Object ID: ").append(objectId).append("\n");
                    sb.append("Character Name: ").append(name);
                }
                break;
                
            case "SystemMessage":
                if (content.length >= 5) {
                    int messageId = extractInt(content, 1);
                    sb.append("Message ID: ").append(messageId);
                }
                break;
                
            default:
                sb.append("No detailed structure information available for this packet type.");
                break;
        }
        
        return sb.toString();
    }
}
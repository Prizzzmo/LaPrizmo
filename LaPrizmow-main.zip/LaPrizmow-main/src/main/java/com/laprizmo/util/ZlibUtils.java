/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.util;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.*;

/**
 * Утилиты для работы с алгоритмом сжатия ZLib.
 * Предоставляет методы для сжатия и распаковки данных с помощью ZLib.
 */
public class ZlibUtils {
    
    private static final Logger LOGGER = Logger.getLogger(ZlibUtils.class.getName());
    
    // Размер буфера для чтения/записи
    private static final int BUFFER_SIZE = 8192;
    
    // Максимальный размер данных для автоматического определения
    private static final int MAX_AUTO_SIZE = 10 * 1024 * 1024; // 10 МБ
    
    // Заголовок ZLib
    private static final byte[] ZLIB_HEADER = new byte[] {0x78, 0x01};
    
    /**
     * Сжимает массив байтов с использованием ZLib.
     *
     * @param data данные для сжатия
     * @return сжатые данные
     * @throws IOException если произошла ошибка при сжатии
     */
    public static byte[] compress(byte[] data) throws IOException {
        return compress(data, Deflater.DEFAULT_COMPRESSION);
    }
    
    /**
     * Сжимает массив байтов с использованием ZLib с указанным уровнем сжатия.
     *
     * @param data данные для сжатия
     * @param level уровень сжатия (0-9, где 9 - максимальное сжатие)
     * @return сжатые данные
     * @throws IOException если произошла ошибка при сжатии
     */
    public static byte[] compress(byte[] data, int level) throws IOException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        Deflater deflater = new Deflater(level);
        deflater.setInput(data);
        deflater.finish();
        
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(data.length)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            
            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                baos.write(buffer, 0, count);
            }
            
            return baos.toByteArray();
        } finally {
            deflater.end();
        }
    }
    
    /**
     * Распаковывает массив байтов с использованием ZLib.
     *
     * @param data сжатые данные
     * @return распакованные данные
     * @throws IOException если произошла ошибка при распаковке
     */
    public static byte[] decompress(byte[] data) throws IOException {
        return decompress(data, -1);
    }
    
    /**
     * Распаковывает массив байтов с использованием ZLib с указанием ожидаемого размера.
     *
     * @param data сжатые данные
     * @param expectedSize ожидаемый размер распакованных данных или -1, если размер неизвестен
     * @return распакованные данные
     * @throws IOException если произошла ошибка при распаковке
     */
    public static byte[] decompress(byte[] data, int expectedSize) throws IOException {
        if (data == null || data.length == 0) {
            return new byte[0];
        }
        
        // Проверяем, начинаются ли данные с заголовка ZLib
        boolean hasZlibHeader = data.length >= 2 && data[0] == ZLIB_HEADER[0] && (data[1] & 0xF0) == (ZLIB_HEADER[1] & 0xF0);
        
        Inflater inflater = new Inflater(true);
        
        if (hasZlibHeader) {
            inflater = new Inflater(false);
        }
        
        inflater.setInput(data);
        
        // Если известен ожидаемый размер, используем его
        if (expectedSize > 0 && expectedSize < MAX_AUTO_SIZE) {
            try {
                byte[] result = new byte[expectedSize];
                int resultLength = inflater.inflate(result);
                
                if (!inflater.finished()) {
                    throw new IOException("Decompression failed: buffer too small, expected size was " + expectedSize);
                }
                
                // Если реальный размер меньше ожидаемого, обрезаем массив
                if (resultLength < expectedSize) {
                    return Arrays.copyOf(result, resultLength);
                }
                
                return result;
            } catch (DataFormatException e) {
                throw new IOException("Decompression failed: " + e.getMessage(), e);
            } finally {
                inflater.end();
            }
        }
        
        // Если размер неизвестен, используем динамический буфер
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(data.length * 2)) {
            byte[] buffer = new byte[BUFFER_SIZE];
            
            try {
                while (!inflater.finished()) {
                    int count = inflater.inflate(buffer);
                    
                    if (count == 0 && inflater.needsInput()) {
                        break;
                    }
                    
                    baos.write(buffer, 0, count);
                    
                    // Предотвращаем слишком большие распакованные данные
                    if (baos.size() > MAX_AUTO_SIZE) {
                        throw new IOException("Decompression failed: output too large, exceeds " + MAX_AUTO_SIZE + " bytes");
                    }
                }
                
                return baos.toByteArray();
            } catch (DataFormatException e) {
                throw new IOException("Decompression failed: " + e.getMessage(), e);
            } finally {
                inflater.end();
            }
        }
    }
    
    /**
     * Сжимает данные из входного потока в выходной поток.
     *
     * @param in входной поток с несжатыми данными
     * @param out выходной поток для сжатых данных
     * @param level уровень сжатия (0-9, где 9 - максимальное сжатие)
     * @throws IOException если произошла ошибка при сжатии
     */
    public static void compress(InputStream in, OutputStream out, int level) throws IOException {
        try (DeflaterOutputStream dos = new DeflaterOutputStream(out, new Deflater(level))) {
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            
            while ((bytesRead = in.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
            
            dos.finish();
        }
    }
    
    /**
     * Распаковывает данные из входного потока в выходной поток.
     *
     * @param in входной поток со сжатыми данными
     * @param out выходной поток для распакованных данных
     * @throws IOException если произошла ошибка при распаковке
     */
    public static void decompress(InputStream in, OutputStream out) throws IOException {
        // Проверяем наличие заголовка ZLib
        in.mark(2);
        int header1 = in.read();
        int header2 = in.read();
        in.reset();
        
        boolean hasZlibHeader = header1 == ZLIB_HEADER[0] && (header2 & 0xF0) == (ZLIB_HEADER[1] & 0xF0);
        
        try (InflaterInputStream iis = new InflaterInputStream(in, new Inflater(!hasZlibHeader))) {
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            
            while ((bytesRead = iis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }
    
    /**
     * Сжимает файл с использованием ZLib.
     *
     * @param inputFile входной файл с несжатыми данными
     * @param outputFile выходной файл для сжатых данных
     * @param level уровень сжатия (0-9, где 9 - максимальное сжатие)
     * @throws IOException если произошла ошибка при сжатии
     */
    public static void compressFile(String inputFile, String outputFile, int level) throws IOException {
        try (FileInputStream fis = new FileInputStream(inputFile);
             FileOutputStream fos = new FileOutputStream(outputFile)) {
            
            compress(fis, fos, level);
        }
    }
    
    /**
     * Распаковывает файл с использованием ZLib.
     *
     * @param inputFile входной файл со сжатыми данными
     * @param outputFile выходной файл для распакованных данных
     * @throws IOException если произошла ошибка при распаковке
     */
    public static void decompressFile(String inputFile, String outputFile) throws IOException {
        try (FileInputStream fis = new FileInputStream(inputFile);
             FileOutputStream fos = new FileOutputStream(outputFile)) {
            
            decompress(fis, fos);
        }
    }
    
    /**
     * Проверяет, является ли массив байтов сжатым с помощью ZLib.
     *
     * @param data массив байтов для проверки
     * @return true, если данные сжаты с помощью ZLib
     */
    public static boolean isCompressed(byte[] data) {
        if (data == null || data.length < 2) {
            return false;
        }
        
        // Проверяем наличие заголовка ZLib
        return (data[0] == ZLIB_HEADER[0] && (data[1] & 0xF0) == (ZLIB_HEADER[1] & 0xF0)) ||
               (data[0] == 0x78 && data[1] == 0x9C) || // ZLib со сжатием по умолчанию
               (data[0] == 0x78 && data[1] == 0xDA);   // ZLib с максимальным сжатием
    }
    
    /**
     * Проверяет, является ли файл сжатым с помощью ZLib.
     *
     * @param filename имя файла для проверки
     * @return true, если файл сжат с помощью ZLib
     */
    public static boolean isCompressedFile(String filename) {
        try (FileInputStream fis = new FileInputStream(filename)) {
            byte[] header = new byte[2];
            if (fis.read(header) < 2) {
                return false;
            }
            
            return isCompressed(header);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Error checking if file is compressed: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Получает размер несжатых данных из сжатого массива байтов с помощью ZLib.
     * Возвращает -1, если размер не может быть определен.
     *
     * @param data сжатые данные
     * @return размер несжатых данных или -1, если размер не может быть определен
     */
    public static int getUncompressedSize(byte[] data) {
        if (data == null || data.length < 4) {
            return -1;
        }
        
        // Пытаемся извлечь размер из хвоста файла (формат Lineage 2)
        if (data.length >= 8) {
            ByteBuffer buffer = ByteBuffer.wrap(data, data.length - 8, 8);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            int tailSize = buffer.getInt();
            
            if (tailSize > 0 && tailSize < data.length) {
                return tailSize;
            }
        }
        
        // Если в файле нет хвоста, пробуем оценить размер
        try {
            Inflater inflater = new Inflater(!isCompressed(data));
            inflater.setInput(data);
            byte[] buffer = new byte[BUFFER_SIZE];
            int totalSize = 0;
            
            while (!inflater.finished() && totalSize < MAX_AUTO_SIZE) {
                int count = inflater.inflate(buffer);
                totalSize += count;
                
                if (inflater.needsInput()) {
                    break;
                }
            }
            
            inflater.end();
            
            return totalSize;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error getting uncompressed size: " + e.getMessage(), e);
            return -1;
        }
    }
    
    /**
     * Получает уровень сжатия из заголовка ZLib.
     * Возвращает -1, если уровень не может быть определен.
     *
     * @param data сжатые данные
     * @return уровень сжатия (0-9) или -1, если уровень не может быть определен
     */
    public static int getCompressionLevel(byte[] data) {
        if (data == null || data.length < 2 || !isCompressed(data)) {
            return -1;
        }
        
        int cmf = data[0] & 0xFF;
        int flg = data[1] & 0xFF;
        
        // Получаем метод сжатия (cmf & 0xF)
        int cm = cmf & 0x0F;
        
        // Получаем уровень сжатия на основе флагов
        if (cm == 8) { // DEFLATE
            int compInfo = (cmf >> 4) & 0x0F;
            
            if (compInfo == 7) {
                // Уровень по умолчанию
                return Deflater.DEFAULT_COMPRESSION;
            } else if (compInfo > 7) {
                // Более высокий уровень сжатия
                return Deflater.BEST_COMPRESSION;
            } else {
                // Низкий уровень сжатия
                return Deflater.BEST_SPEED;
            }
        }
        
        return -1;
    }
}
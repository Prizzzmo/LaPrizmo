/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.util;

import com.laprizmo.core.ProtocolDetector;
import com.laprizmo.crypto.CryptoException;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/**
 * Утилиты для работы с DAT-файлами Lineage 2.
 * Предоставляет методы для анализа и извлечения данных из файлов данных игры.
 */
public class DatFileUtils {
    
    private static final Logger LOGGER = Logger.getLogger(DatFileUtils.class.getName());
    
    // Сигнатура файла системы (FORM)
    private static final byte[] FORM_SIGNATURE = "FORM".getBytes(StandardCharsets.US_ASCII);
    
    // Максимальный размер буфера для чтения
    private static final int MAX_BUFFER_SIZE = 16 * 1024 * 1024; // 16 МБ
    
    // Шаблон для поиска путей к файлам
    private static final Pattern FILE_PATH_PATTERN = Pattern.compile("([A-Za-z0-9_/\\\\.-]+\\.(txt|htm|xml|tga|bmp|dds|wav|mp3|ogg|dat))");
    
    /**
     * Информация о разделе DAT-файла.
     */
    public static class DatChunk {
        // Идентификатор раздела
        private String id;
        
        // Размер данных раздела
        private int size;
        
        // Смещение данных раздела
        private long offset;
        
        // Тип данных раздела (опционально)
        private String type;
        
        // Дочерние разделы (опционально)
        private List<DatChunk> children;
        
        /**
         * Создает информацию о разделе.
         *
         * @param id идентификатор раздела
         * @param size размер данных раздела
         * @param offset смещение данных раздела
         */
        public DatChunk(String id, int size, long offset) {
            this.id = id;
            this.size = size;
            this.offset = offset;
            this.children = new ArrayList<>();
        }
        
        /**
         * Возвращает идентификатор раздела.
         *
         * @return идентификатор раздела
         */
        public String getId() {
            return id;
        }
        
        /**
         * Возвращает размер данных раздела.
         *
         * @return размер данных раздела
         */
        public int getSize() {
            return size;
        }
        
        /**
         * Возвращает смещение данных раздела.
         *
         * @return смещение данных раздела
         */
        public long getOffset() {
            return offset;
        }
        
        /**
         * Возвращает тип данных раздела.
         *
         * @return тип данных раздела или null, если тип не определен
         */
        public String getType() {
            return type;
        }
        
        /**
         * Устанавливает тип данных раздела.
         *
         * @param type тип данных раздела
         */
        public void setType(String type) {
            this.type = type;
        }
        
        /**
         * Возвращает дочерние разделы.
         *
         * @return список дочерних разделов
         */
        public List<DatChunk> getChildren() {
            return children;
        }
        
        /**
         * Добавляет дочерний раздел.
         *
         * @param child дочерний раздел
         */
        public void addChild(DatChunk child) {
            children.add(child);
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Chunk{id='").append(id).append("'");
            sb.append(", size=").append(size);
            sb.append(", offset=").append(offset);
            
            if (type != null) {
                sb.append(", type='").append(type).append("'");
            }
            
            if (!children.isEmpty()) {
                sb.append(", children=").append(children.size());
            }
            
            sb.append("}");
            return sb.toString();
        }
    }
    
    /**
     * Анализирует DAT-файл и возвращает информацию о его структуре.
     *
     * @param filename имя файла
     * @return корневой раздел файла
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static DatChunk analyzeDatFile(String filename) throws IOException {
        File file = new File(filename);
        if (!file.exists() || !file.isFile()) {
            throw new IOException("File not found: " + filename);
        }
        
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            // Проверяем сигнатуру
            byte[] signature = new byte[4];
            raf.read(signature);
            
            if (!compareByteArrays(signature, FORM_SIGNATURE)) {
                throw new IOException("Invalid DAT file format (expected FORM signature)");
            }
            
            // Читаем размер файла
            int fileSize = Integer.reverseBytes(raf.readInt());
            
            // Читаем идентификатор типа
            byte[] typeId = new byte[4];
            raf.read(typeId);
            String type = new String(typeId, StandardCharsets.US_ASCII);
            
            // Создаем корневой раздел
            DatChunk root = new DatChunk("FORM", fileSize, 0);
            root.setType(type);
            
            // Читаем дочерние разделы
            readChunks(raf, 12, fileSize - 4, root);
            
            return root;
        }
    }
    
    /**
     * Рекурсивно читает разделы из файла.
     *
     * @param raf случайный доступ к файлу
     * @param offset смещение начала чтения
     * @param size размер данных для чтения
     * @param parent родительский раздел
     * @throws IOException если произошла ошибка при чтении файла
     */
    private static void readChunks(RandomAccessFile raf, long offset, int size, DatChunk parent) throws IOException {
        long endOffset = offset + size;
        long currentOffset = offset;
        
        while (currentOffset < endOffset) {
            raf.seek(currentOffset);
            
            // Читаем идентификатор раздела
            byte[] chunkId = new byte[4];
            if (raf.read(chunkId) < 4) {
                break;
            }
            
            // Читаем размер раздела
            int chunkSize = Integer.reverseBytes(raf.readInt());
            
            // Создаем информацию о разделе
            String id = new String(chunkId, StandardCharsets.US_ASCII);
            DatChunk chunk = new DatChunk(id, chunkSize, currentOffset + 8);
            parent.addChild(chunk);
            
            // Если это составной раздел, рекурсивно читаем его содержимое
            if (id.equals("FORM") || id.equals("LIST")) {
                // Читаем тип раздела
                byte[] typeId = new byte[4];
                raf.read(typeId);
                String type = new String(typeId, StandardCharsets.US_ASCII);
                chunk.setType(type);
                
                // Рекурсивно читаем дочерние разделы
                readChunks(raf, currentOffset + 12, chunkSize - 4, chunk);
            }
            
            // Переходим к следующему разделу
            currentOffset += 8 + chunkSize;
            
            // Выравнивание по 2 байта
            if (chunkSize % 2 != 0) {
                currentOffset++;
            }
        }
    }
    
    /**
     * Извлекает данные раздела из файла.
     *
     * @param filename имя файла
     * @param chunk информация о разделе
     * @return данные раздела
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static byte[] extractChunkData(String filename, DatChunk chunk) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(filename, "r")) {
            raf.seek(chunk.getOffset());
            
            byte[] data = new byte[chunk.getSize()];
            raf.read(data);
            
            return data;
        }
    }
    
    /**
     * Извлекает все текстовые данные из файла.
     *
     * @param filename имя файла
     * @return карта с найденными текстовыми данными (путь -> содержимое)
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static Map<String, String> extractTextData(String filename) throws IOException {
        Map<String, String> textData = new HashMap<>();
        
        try {
            // Определяем протокол файла
            ProtocolDetector.ProtocolInfo protocolInfo = ProtocolDetector.detectProtocol(filename);
            
            // Читаем весь файл
            byte[] fileData = Files.readAllBytes(Paths.get(filename));
            
            // Извлекаем текстовые данные
            String fileContent = new String(fileData, StandardCharsets.UTF_8);
            
            // Ищем пути к файлам
            Matcher matcher = FILE_PATH_PATTERN.matcher(fileContent);
            while (matcher.find()) {
                String path = matcher.group(1);
                // Игнорируем пути к ресурсам
                if (!path.toLowerCase().endsWith(".tga") && 
                    !path.toLowerCase().endsWith(".bmp") && 
                    !path.toLowerCase().endsWith(".dds") && 
                    !path.toLowerCase().endsWith(".wav") && 
                    !path.toLowerCase().endsWith(".mp3") && 
                    !path.toLowerCase().endsWith(".ogg")) {
                    
                    // Пытаемся найти содержимое файла
                    String content = extractTextContentByPath(fileData, path);
                    if (content != null) {
                        textData.put(path, content);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error extracting text data", e);
        }
        
        return textData;
    }
    
    /**
     * Извлекает текстовое содержимое файла по его пути.
     *
     * @param data данные
     * @param path путь к файлу
     * @return содержимое файла или null, если не удалось извлечь
     */
    private static String extractTextContentByPath(byte[] data, String path) {
        // Ищем путь в данных
        byte[] pathBytes = path.getBytes(StandardCharsets.UTF_8);
        
        for (int i = 0; i < data.length - pathBytes.length; i++) {
            boolean found = true;
            
            for (int j = 0; j < pathBytes.length; j++) {
                if (data[i + j] != pathBytes[j]) {
                    found = false;
                    break;
                }
            }
            
            if (found) {
                // Пытаемся найти содержимое после пути
                int contentStart = i + pathBytes.length;
                
                // Пропускаем нулевые байты и другие символы-разделители
                while (contentStart < data.length && (data[contentStart] == 0 || data[contentStart] == '\r' || data[contentStart] == '\n' || data[contentStart] == '\t')) {
                    contentStart++;
                }
                
                // Ищем конец содержимого
                int contentEnd = contentStart;
                while (contentEnd < data.length && contentEnd - contentStart < 4096) {
                    // Ищем конец строки или нулевой байт
                    if (data[contentEnd] == 0 || (data[contentEnd] == '\r' && contentEnd + 1 < data.length && data[contentEnd + 1] == '\n')) {
                        break;
                    }
                    contentEnd++;
                }
                
                // Если нашли содержимое
                if (contentEnd > contentStart) {
                    return new String(data, contentStart, contentEnd - contentStart, StandardCharsets.UTF_8);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Добавляет контрольную сумму в конец файла.
     *
     * @param filename имя файла
     * @param tailSize размер данных для расчета контрольной суммы
     * @throws IOException если произошла ошибка при записи в файл
     */
    public static void addChecksum(String filename, int tailSize) throws IOException {
        File file = new File(filename);
        long fileSize = file.length();
        
        if (tailSize <= 0 || tailSize >= fileSize) {
            throw new IllegalArgumentException("Invalid tail size: " + tailSize);
        }
        
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            // Читаем данные для контрольной суммы
            raf.seek(fileSize - tailSize);
            byte[] tailData = new byte[tailSize];
            raf.read(tailData);
            
            // Рассчитываем контрольную сумму
            CRC32 crc = new CRC32();
            crc.update(tailData);
            int checksum = (int) crc.getValue();
            
            // Записываем размер и контрольную сумму
            raf.seek(fileSize);
            ByteBuffer buffer = ByteBuffer.allocate(8);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            buffer.putInt(tailSize);
            buffer.putInt(checksum);
            raf.write(buffer.array());
        }
    }
    
    /**
     * Проверяет контрольную сумму в конце файла.
     *
     * @param filename имя файла
     * @return true, если контрольная сумма верна
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static boolean verifyChecksum(String filename) throws IOException {
        File file = new File(filename);
        long fileSize = file.length();
        
        if (fileSize < 12) {
            return false;
        }
        
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            // Читаем размер и контрольную сумму из конца файла
            raf.seek(fileSize - 8);
            ByteBuffer buffer = ByteBuffer.allocate(8);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            raf.read(buffer.array());
            buffer.position(0);
            
            int tailSize = buffer.getInt();
            int storedChecksum = buffer.getInt();
            
            // Проверяем размер
            if (tailSize <= 0 || tailSize >= fileSize - 8) {
                return false;
            }
            
            // Читаем данные для проверки контрольной суммы
            raf.seek(fileSize - tailSize - 8);
            byte[] tailData = new byte[tailSize];
            raf.read(tailData);
            
            // Рассчитываем контрольную сумму
            CRC32 crc = new CRC32();
            crc.update(tailData);
            int calculatedChecksum = (int) crc.getValue();
            
            return calculatedChecksum == storedChecksum;
        }
    }
    
    /**
     * Удаляет контрольную сумму из конца файла.
     *
     * @param filename имя файла
     * @throws IOException если произошла ошибка при записи в файл
     */
    public static void removeChecksum(String filename) throws IOException {
        File file = new File(filename);
        long fileSize = file.length();
        
        if (fileSize < 12) {
            return;
        }
        
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            // Читаем размер из конца файла
            raf.seek(fileSize - 8);
            ByteBuffer buffer = ByteBuffer.allocate(4);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            raf.read(buffer.array());
            buffer.position(0);
            
            int tailSize = buffer.getInt();
            
            // Проверяем размер
            if (tailSize <= 0 || tailSize >= fileSize - 8) {
                return;
            }
            
            // Обрезаем файл
            raf.setLength(fileSize - 8);
        }
    }
    
    /**
     * Извлекает вложенные файлы из DAT-файла.
     *
     * @param filename имя файла
     * @param outputDir выходная директория
     * @return список извлеченных файлов
     * @throws IOException если произошла ошибка при чтении или записи файлов
     */
    public static List<String> extractNestedFiles(String filename, String outputDir) throws IOException {
        List<String> extractedFiles = new ArrayList<>();
        
        DatChunk root = analyzeDatFile(filename);
        Map<String, byte[]> fileMap = new HashMap<>();
        
        // Ищем разделы с файлами
        for (DatChunk chunk : root.getChildren()) {
            if (chunk.getId().equals("NAME") || chunk.getId().equals("DTXT")) {
                // Извлекаем имена файлов
                byte[] nameData = extractChunkData(filename, chunk);
                List<String> names = extractFileNames(nameData);
                
                // Ищем соответствующие данные
                for (DatChunk dataChunk : root.getChildren()) {
                    if (dataChunk.getId().equals("DATA") || dataChunk.getId().equals("DTDA")) {
                        byte[] fileData = extractChunkData(filename, dataChunk);
                        
                        // Разбиваем данные на отдельные файлы
                        List<byte[]> fileDataList = splitFileData(fileData, names.size());
                        
                        // Сопоставляем имена и данные
                        for (int i = 0; i < Math.min(names.size(), fileDataList.size()); i++) {
                            fileMap.put(names.get(i), fileDataList.get(i));
                        }
                    }
                }
            }
        }
        
        // Создаем выходную директорию
        Path outputPath = Paths.get(outputDir);
        Files.createDirectories(outputPath);
        
        // Записываем файлы
        for (Map.Entry<String, byte[]> entry : fileMap.entrySet()) {
            String filePath = entry.getKey();
            byte[] data = entry.getValue();
            
            Path outFile = outputPath.resolve(filePath);
            Files.createDirectories(outFile.getParent());
            Files.write(outFile, data);
            
            extractedFiles.add(outFile.toString());
        }
        
        return extractedFiles;
    }
    
    /**
     * Извлекает имена файлов из данных раздела.
     *
     * @param data данные раздела
     * @return список имен файлов
     */
    private static List<String> extractFileNames(byte[] data) {
        List<String> names = new ArrayList<>();
        
        ByteBuffer buffer = ByteBuffer.wrap(data);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // Читаем количество файлов
        int fileCount = buffer.getInt();
        
        // Читаем смещения имен
        int[] offsets = new int[fileCount];
        for (int i = 0; i < fileCount; i++) {
            offsets[i] = buffer.getInt();
        }
        
        // Читаем имена файлов
        for (int i = 0; i < fileCount; i++) {
            buffer.position(offsets[i]);
            
            StringBuilder sb = new StringBuilder();
            char c;
            while ((c = (char) buffer.get()) != 0) {
                sb.append(c);
            }
            
            names.add(sb.toString());
        }
        
        return names;
    }
    
    /**
     * Разбивает данные на отдельные файлы.
     *
     * @param data данные
     * @param fileCount количество файлов
     * @return список данных файлов
     */
    private static List<byte[]> splitFileData(byte[] data, int fileCount) {
        List<byte[]> fileDataList = new ArrayList<>();
        
        ByteBuffer buffer = ByteBuffer.wrap(data);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // Читаем размеры файлов
        int[] sizes = new int[fileCount];
        for (int i = 0; i < fileCount; i++) {
            sizes[i] = buffer.getInt();
        }
        
        // Читаем данные файлов
        for (int i = 0; i < fileCount; i++) {
            byte[] fileData = new byte[sizes[i]];
            buffer.get(fileData);
            fileDataList.add(fileData);
        }
        
        return fileDataList;
    }
    
    /**
     * Сравнивает два массива байтов.
     *
     * @param array1 первый массив
     * @param array2 второй массив
     * @return true, если массивы совпадают
     */
    private static boolean compareByteArrays(byte[] array1, byte[] array2) {
        if (array1.length != array2.length) {
            return false;
        }
        
        for (int i = 0; i < array1.length; i++) {
            if (array1[i] != array2[i]) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Генерирует отчет о структуре DAT-файла.
     *
     * @param filename имя файла
     * @return отчет о структуре файла
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static String generateDatReport(String filename) throws IOException {
        DatChunk root = analyzeDatFile(filename);
        StringBuilder report = new StringBuilder();
        
        report.append("DAT File Analysis Report: ").append(filename).append("\n");
        report.append("---------------------------------------------------\n");
        
        // Добавляем информацию о структуре файла
        report.append("Structure:\n");
        appendChunkInfo(report, root, 0);
        
        // Добавляем информацию о содержимом
        report.append("\nContent Summary:\n");
        
        Map<String, Integer> chunkTypes = new HashMap<>();
        countChunkTypes(root, chunkTypes);
        
        for (Map.Entry<String, Integer> entry : chunkTypes.entrySet()) {
            report.append("  ").append(entry.getKey()).append(": ").append(entry.getValue()).append(" chunks\n");
        }
        
        // Добавляем информацию о протоколе
        try {
            ProtocolDetector.ProtocolInfo protocolInfo = ProtocolDetector.detectProtocol(filename);
            if (protocolInfo != null) {
                report.append("\nProtocol Information:\n");
                report.append("  Version: ").append(protocolInfo.getProtocolVersion()).append("\n");
                report.append("  Crypto Type: ").append(protocolInfo.getCryptoType()).append("\n");
                report.append("  Compressed: ").append(protocolInfo.isCompressed()).append("\n");
            }
        } catch (Exception e) {
            report.append("\nCould not determine protocol information: ").append(e.getMessage()).append("\n");
        }
        
        return report.toString();
    }
    
    /**
     * Рекурсивно добавляет информацию о разделе в отчет.
     *
     * @param report отчет
     * @param chunk раздел
     * @param level уровень вложенности
     */
    private static void appendChunkInfo(StringBuilder report, DatChunk chunk, int level) {
        // Добавляем отступ
        for (int i = 0; i < level; i++) {
            report.append("  ");
        }
        
        // Добавляем информацию о разделе
        report.append("- ").append(chunk.getId());
        
        if (chunk.getType() != null) {
            report.append(" (").append(chunk.getType()).append(")");
        }
        
        report.append(", Size: ").append(chunk.getSize()).append(" bytes");
        report.append(", Offset: 0x").append(Long.toHexString(chunk.getOffset()).toUpperCase());
        report.append("\n");
        
        // Добавляем информацию о дочерних разделах
        for (DatChunk child : chunk.getChildren()) {
            appendChunkInfo(report, child, level + 1);
        }
    }
    
    /**
     * Подсчитывает количество разделов каждого типа.
     *
     * @param chunk раздел
     * @param chunkTypes карта с количеством разделов каждого типа
     */
    private static void countChunkTypes(DatChunk chunk, Map<String, Integer> chunkTypes) {
        String type = chunk.getId();
        
        chunkTypes.put(type, chunkTypes.getOrDefault(type, 0) + 1);
        
        for (DatChunk child : chunk.getChildren()) {
            countChunkTypes(child, chunkTypes);
        }
    }
}
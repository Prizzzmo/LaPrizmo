/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.util;

import com.laprizmo.core.CryptoOperations;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * Процессор для пакетной обработки файлов.
 * Предоставляет функциональность для рекурсивной обработки директорий
 * и параллельной обработки файлов с поддержкой прогресса и фильтрации.
 */
public class BatchProcessor {
    
    private static final Logger LOGGER = Logger.getLogger(BatchProcessor.class.getName());
    
    // Максимальное количество потоков для параллельной обработки
    private static final int DEFAULT_MAX_THREADS = Runtime.getRuntime().availableProcessors();
    
    // Криптографические операции
    private final CryptoOperations cryptoOperations;
    
    // Параметры операции
    private final CryptoOperations.CryptoParams params;
    
    // Выходная директория
    private String outputDirectory;
    
    // Поддерживать ли структуру директорий при выводе
    private boolean preserveDirectoryStructure = true;
    
    // Перезаписывать ли существующие файлы
    private boolean overwriteExisting = false;
    
    // Максимальное количество потоков
    private int maxThreads = DEFAULT_MAX_THREADS;
    
    // Шаблон фильтрации файлов
    private Pattern fileFilter;
    
    // Обработчик прогресса
    private Consumer<ProgressInfo> progressHandler;
    
    // Флаг отмены операции
    private volatile boolean cancelled = false;
    
    /**
     * Информация о прогрессе обработки.
     */
    public static class ProgressInfo {
        private final int totalFiles;
        private final int processedFiles;
        private final int successfulFiles;
        private final int failedFiles;
        private final long totalBytes;
        private final long processedBytes;
        private final String currentFile;
        private final boolean completed;
        
        public ProgressInfo(int totalFiles, int processedFiles, int successfulFiles, int failedFiles,
                           long totalBytes, long processedBytes, String currentFile, boolean completed) {
            this.totalFiles = totalFiles;
            this.processedFiles = processedFiles;
            this.successfulFiles = successfulFiles;
            this.failedFiles = failedFiles;
            this.totalBytes = totalBytes;
            this.processedBytes = processedBytes;
            this.currentFile = currentFile;
            this.completed = completed;
        }
        
        public int getTotalFiles() {
            return totalFiles;
        }
        
        public int getProcessedFiles() {
            return processedFiles;
        }
        
        public int getSuccessfulFiles() {
            return successfulFiles;
        }
        
        public int getFailedFiles() {
            return failedFiles;
        }
        
        public long getTotalBytes() {
            return totalBytes;
        }
        
        public long getProcessedBytes() {
            return processedBytes;
        }
        
        public String getCurrentFile() {
            return currentFile;
        }
        
        public boolean isCompleted() {
            return completed;
        }
        
        public int getPercentComplete() {
            if (totalFiles == 0) return 0;
            return (int) ((double) processedFiles / totalFiles * 100);
        }
    }
    
    /**
     * Создает новый процессор для пакетной обработки.
     *
     * @param cryptoOperations операции криптографии
     * @param params параметры криптографической операции
     */
    public BatchProcessor(CryptoOperations cryptoOperations, CryptoOperations.CryptoParams params) {
        this.cryptoOperations = cryptoOperations;
        this.params = params;
    }
    
    /**
     * Устанавливает выходную директорию.
     *
     * @param outputDirectory путь к выходной директории
     * @return текущий процессор
     */
    public BatchProcessor setOutputDirectory(String outputDirectory) {
        this.outputDirectory = outputDirectory;
        return this;
    }
    
    /**
     * Устанавливает флаг сохранения структуры директорий.
     *
     * @param preserve сохранять ли структуру директорий
     * @return текущий процессор
     */
    public BatchProcessor setPreserveDirectoryStructure(boolean preserve) {
        this.preserveDirectoryStructure = preserve;
        return this;
    }
    
    /**
     * Устанавливает флаг перезаписи существующих файлов.
     *
     * @param overwrite перезаписывать ли существующие файлы
     * @return текущий процессор
     */
    public BatchProcessor setOverwriteExisting(boolean overwrite) {
        this.overwriteExisting = overwrite;
        return this;
    }
    
    /**
     * Устанавливает максимальное количество потоков для параллельной обработки.
     *
     * @param maxThreads максимальное количество потоков
     * @return текущий процессор
     */
    public BatchProcessor setMaxThreads(int maxThreads) {
        this.maxThreads = maxThreads > 0 ? maxThreads : DEFAULT_MAX_THREADS;
        return this;
    }
    
    /**
     * Устанавливает регулярное выражение для фильтрации файлов.
     *
     * @param regex регулярное выражение
     * @return текущий процессор
     */
    public BatchProcessor setFileFilter(String regex) {
        if (regex != null && !regex.isEmpty()) {
            this.fileFilter = Pattern.compile(regex);
        } else {
            this.fileFilter = null;
        }
        return this;
    }
    
    /**
     * Устанавливает обработчик прогресса.
     *
     * @param progressHandler обработчик прогресса
     * @return текущий процессор
     */
    public BatchProcessor setProgressHandler(Consumer<ProgressInfo> progressHandler) {
        this.progressHandler = progressHandler;
        return this;
    }
    
    /**
     * Отменяет текущую операцию.
     */
    public void cancel() {
        this.cancelled = true;
    }
    
    /**
     * Проверяет, была ли отменена операция.
     *
     * @return true, если операция была отменена
     */
    public boolean isCancelled() {
        return cancelled;
    }
    
    /**
     * Сбрасывает флаг отмены операции.
     */
    public void resetCancel() {
        this.cancelled = false;
    }
    
    /**
     * Выполняет обработку файлов.
     *
     * @param inputPath путь к входному файлу или директории
     * @param isEncrypt true для шифрования, false для дешифрования
     * @return результат обработки (количество успешно обработанных файлов)
     * @throws IOException если произошла ошибка ввода/вывода
     */
    public int process(String inputPath, boolean isEncrypt) throws IOException {
        resetCancel();
        
        // Создаем выходную директорию, если она не существует
        if (outputDirectory != null) {
            Files.createDirectories(Paths.get(outputDirectory));
        }
        
        // Получаем список файлов для обработки
        List<Path> filesToProcess = collectFiles(Paths.get(inputPath));
        
        if (filesToProcess.isEmpty()) {
            LOGGER.warning("No files to process in path: " + inputPath);
            return 0;
        }
        
        // Рассчитываем общий размер файлов
        long totalBytes = calculateTotalSize(filesToProcess);
        
        // Статистика обработки
        int[] processed = new int[1];
        int[] successful = new int[1];
        int[] failed = new int[1];
        long[] processedBytes = new long[1];
        
        // Создаем пул потоков для параллельной обработки
        ExecutorService executor = Executors.newFixedThreadPool(maxThreads);
        List<Future<?>> futures = new ArrayList<>();
        
        // Запускаем задачи на обработку файлов
        for (Path file : filesToProcess) {
            if (cancelled) {
                break;
            }
            
            String relativePath = getRelativePath(inputPath, file.toString());
            String outputPath = determineOutputPath(relativePath);
            
            futures.add(executor.submit(() -> {
                processFile(file.toString(), outputPath, isEncrypt, processed, successful, failed, processedBytes, totalBytes);
                return null;
            }));
        }
        
        // Ждем завершения всех задач
        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                LOGGER.log(Level.SEVERE, "Error waiting for task completion", e);
            }
        }
        
        // Завершаем пул потоков
        executor.shutdown();
        try {
            executor.awaitTermination(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            LOGGER.log(Level.WARNING, "Executor termination interrupted", e);
            Thread.currentThread().interrupt();
        }
        
        // Оповещаем о завершении обработки
        if (progressHandler != null) {
            ProgressInfo info = new ProgressInfo(
                    filesToProcess.size(), processed[0], successful[0], failed[0],
                    totalBytes, processedBytes[0], null, true);
            progressHandler.accept(info);
        }
        
        return successful[0];
    }
    
    /**
     * Обрабатывает один файл.
     *
     * @param inputPath путь к входному файлу
     * @param outputPath путь к выходному файлу
     * @param isEncrypt true для шифрования, false для дешифрования
     * @param processed счетчик обработанных файлов
     * @param successful счетчик успешно обработанных файлов
     * @param failed счетчик файлов с ошибками
     * @param processedBytes счетчик обработанных байтов
     * @param totalBytes общий размер всех файлов
     */
    private void processFile(String inputPath, String outputPath, boolean isEncrypt,
                             int[] processed, int[] successful, int[] failed,
                             long[] processedBytes, long totalBytes) {
        if (cancelled) {
            return;
        }
        
        try {
            // Создаем выходную директорию, если она не существует
            Path outPath = Paths.get(outputPath);
            Files.createDirectories(outPath.getParent());
            
            // Проверяем, существует ли выходной файл
            if (Files.exists(outPath) && !overwriteExisting) {
                LOGGER.warning("Output file already exists, skipping: " + outputPath);
                synchronized (processed) {
                    processed[0]++;
                    failed[0]++;
                    processedBytes[0] += Files.size(Paths.get(inputPath));
                }
                return;
            }
            
            // Выполняем операцию шифрования/дешифрования
            if (isEncrypt) {
                cryptoOperations.encryptFile(inputPath, outputPath, params);
            } else {
                cryptoOperations.decryptFile(inputPath, outputPath, params);
            }
            
            // Обновляем статистику
            synchronized (processed) {
                processed[0]++;
                successful[0]++;
                processedBytes[0] += Files.size(Paths.get(inputPath));
            }
            
            // Оповещаем о прогрессе
            if (progressHandler != null) {
                ProgressInfo info;
                synchronized (processed) {
                    info = new ProgressInfo(
                            0, processed[0], successful[0], failed[0],
                            totalBytes, processedBytes[0], inputPath, false);
                }
                progressHandler.accept(info);
            }
            
            LOGGER.info((isEncrypt ? "Encrypted: " : "Decrypted: ") + inputPath + " -> " + outputPath);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error processing file: " + inputPath, e);
            
            // Обновляем статистику при ошибке
            synchronized (processed) {
                processed[0]++;
                failed[0]++;
                try {
                    processedBytes[0] += Files.size(Paths.get(inputPath));
                } catch (IOException ex) {
                    // Игнорируем ошибку получения размера файла
                }
            }
            
            // Оповещаем о прогрессе
            if (progressHandler != null) {
                ProgressInfo info;
                synchronized (processed) {
                    info = new ProgressInfo(
                            0, processed[0], successful[0], failed[0],
                            totalBytes, processedBytes[0], inputPath, false);
                }
                progressHandler.accept(info);
            }
        }
    }
    
    /**
     * Собирает список файлов для обработки.
     *
     * @param path путь к файлу или директории
     * @return список путей к файлам
     * @throws IOException если произошла ошибка ввода/вывода
     */
    private List<Path> collectFiles(Path path) throws IOException {
        if (cancelled) {
            return Collections.emptyList();
        }
        
        // Проверяем, существует ли путь
        if (!Files.exists(path)) {
            LOGGER.warning("Path does not exist: " + path);
            return Collections.emptyList();
        }
        
        // Если это файл, возвращаем его
        if (Files.isRegularFile(path)) {
            if (fileFilter != null && !fileFilter.matcher(path.getFileName().toString()).matches()) {
                return Collections.emptyList();
            }
            return Collections.singletonList(path);
        }
        
        // Если это директория, рекурсивно собираем файлы
        final List<Path> files = new ArrayList<>();
        
        Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (cancelled) {
                    return FileVisitResult.TERMINATE;
                }
                
                if (fileFilter == null || fileFilter.matcher(file.getFileName().toString()).matches()) {
                    files.add(file);
                }
                
                return FileVisitResult.CONTINUE;
            }
            
            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                LOGGER.warning("Failed to visit file: " + file + ", " + exc.getMessage());
                return FileVisitResult.CONTINUE;
            }
        });
        
        return files;
    }
    
    /**
     * Рассчитывает общий размер всех файлов.
     *
     * @param files список файлов
     * @return общий размер в байтах
     */
    private long calculateTotalSize(List<Path> files) {
        long total = 0;
        for (Path file : files) {
            try {
                total += Files.size(file);
            } catch (IOException e) {
                // Игнорируем ошибку получения размера файла
            }
        }
        return total;
    }
    
    /**
     * Получает относительный путь файла.
     *
     * @param basePath базовый путь
     * @param filePath полный путь к файлу
     * @return относительный путь
     */
    private String getRelativePath(String basePath, String filePath) {
        Path base = Paths.get(basePath);
        Path file = Paths.get(filePath);
        
        // Если базовый путь - это файл, берем его директорию
        if (Files.isRegularFile(base)) {
            base = base.getParent();
        }
        
        // Если базовый путь существует и является родительским для файла,
        // возвращаем относительный путь
        if (base != null && filePath.startsWith(base.toString())) {
            return base.relativize(file).toString();
        }
        
        // В противном случае возвращаем только имя файла
        return file.getFileName().toString();
    }
    
    /**
     * Определяет путь к выходному файлу.
     *
     * @param relativePath относительный путь к входному файлу
     * @return путь к выходному файлу
     */
    private String determineOutputPath(String relativePath) {
        // Если выходная директория не указана, используем текущую
        if (outputDirectory == null || outputDirectory.isEmpty()) {
            Path path = Paths.get(relativePath);
            String fileName = path.getFileName().toString();
            String prefix = fileName.toLowerCase().startsWith("enc-") || fileName.toLowerCase().startsWith("dec-") ?
                    "" : (params.getProtocolVersion() >= 500 ? "enc-" : "dec-");
            return Paths.get(path.getParent().toString(), prefix + fileName).toString();
        }
        
        // Если нужно сохранять структуру директорий
        if (preserveDirectoryStructure) {
            return Paths.get(outputDirectory, relativePath).toString();
        }
        
        // В противном случае сохраняем только в выходную директорию
        Path path = Paths.get(relativePath);
        return Paths.get(outputDirectory, path.getFileName().toString()).toString();
    }
}
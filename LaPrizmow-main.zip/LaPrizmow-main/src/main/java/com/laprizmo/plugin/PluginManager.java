/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.plugin;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolManager;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Менеджер плагинов для LaPrizmo.
 * Управляет загрузкой, выгрузкой и выполнением плагинов.
 */
public class PluginManager {
    
    private static final Logger LOGGER = Logger.getLogger(PluginManager.class.getName());
    
    // Экземпляр синглтона
    private static PluginManager instance;
    
    // Карта загруженных плагинов
    private final Map<String, Plugin> plugins = new ConcurrentHashMap<>();
    
    // Карта классов плагинов
    private final Map<String, Class<?>> pluginClasses = new ConcurrentHashMap<>();
    
    // Загрузчики классов плагинов
    private final List<ClassLoader> pluginClassLoaders = new ArrayList<>();
    
    // Директория с плагинами
    private String pluginDirectory;
    
    // Флаг включения плагинов
    private boolean pluginsEnabled;
    
    // Основные компоненты приложения для передачи плагинам
    private CryptoEngine cryptoEngine;
    private CryptoOperations cryptoOperations;
    private ProtocolManager protocolManager;
    
    /**
     * Приватный конструктор для реализации синглтона.
     */
    private PluginManager() {
        ConfigManager configManager = ConfigManager.getInstance();
        this.pluginDirectory = configManager.getProperty("PluginDirectory", "plugins");
        this.pluginsEnabled = Boolean.parseBoolean(configManager.getProperty("EnablePlugins", "true"));
        
        // Создаем директорию для плагинов, если она не существует
        Path pluginDirPath = Paths.get(pluginDirectory);
        if (!Files.exists(pluginDirPath)) {
            try {
                Files.createDirectories(pluginDirPath);
                LOGGER.info("Created plugin directory: " + pluginDirPath.toAbsolutePath());
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Failed to create plugin directory", e);
            }
        }
    }
    
    /**
     * Получает экземпляр менеджера плагинов.
     *
     * @return экземпляр менеджера плагинов
     */
    public static synchronized PluginManager getInstance() {
        if (instance == null) {
            instance = new PluginManager();
        }
        return instance;
    }
    
    /**
     * Инициализирует менеджер плагинов с компонентами приложения.
     *
     * @param cryptoEngine      движок криптографии
     * @param cryptoOperations  операции криптографии
     * @param protocolManager   менеджер протоколов
     */
    public void initialize(CryptoEngine cryptoEngine, CryptoOperations cryptoOperations, ProtocolManager protocolManager) {
        this.cryptoEngine = cryptoEngine;
        this.cryptoOperations = cryptoOperations;
        this.protocolManager = protocolManager;
        
        if (pluginsEnabled) {
            loadPlugins();
        }
    }
    
    /**
     * Загружает все плагины из директории плагинов.
     */
    public void loadPlugins() {
        if (!pluginsEnabled) {
            LOGGER.info("Plugins are disabled");
            return;
        }
        
        File pluginDir = new File(pluginDirectory);
        if (!pluginDir.exists() || !pluginDir.isDirectory()) {
            LOGGER.warning("Plugin directory does not exist or is not a directory: " + pluginDirectory);
            return;
        }
        
        // Получаем список JAR-файлов в директории плагинов
        File[] jarFiles = pluginDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".jar"));
        
        if (jarFiles == null || jarFiles.length == 0) {
            LOGGER.info("No plugins found in directory: " + pluginDirectory);
            return;
        }
        
        for (File jarFile : jarFiles) {
            try {
                loadPlugin(jarFile);
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Failed to load plugin: " + jarFile.getName(), e);
            }
        }
        
        LOGGER.info("Loaded " + plugins.size() + " plugins");
    }
    
    /**
     * Загружает плагин из JAR-файла.
     *
     * @param jarFile JAR-файл с плагином
     * @throws IOException если произошла ошибка при чтении файла
     */
    public void loadPlugin(File jarFile) throws IOException {
        LOGGER.info("Loading plugin from: " + jarFile.getPath());
        
        // Создаем URL для JAR-файла
        URL[] urls = new URL[]{jarFile.toURI().toURL()};
        
        // Создаем загрузчик классов для плагина
        URLClassLoader classLoader = new URLClassLoader(urls, getClass().getClassLoader());
        pluginClassLoaders.add(classLoader);
        
        // Ищем классы, реализующие интерфейс Plugin
        List<Class<?>> foundPluginClasses = findPluginClasses(jarFile, classLoader);
        
        for (Class<?> pluginClass : foundPluginClasses) {
            try {
                // Создаем экземпляр плагина
                Plugin plugin = (Plugin) pluginClass.getDeclaredConstructor().newInstance();
                
                // Создаем контекст для инициализации плагина
                PluginContext context = new PluginContext(cryptoEngine, cryptoOperations, protocolManager);
                
                // Инициализируем плагин
                plugin.initialize(context);
                
                // Добавляем плагин в карту плагинов
                plugins.put(plugin.getId(), plugin);
                pluginClasses.put(plugin.getId(), pluginClass);
                
                LOGGER.info("Loaded plugin: " + plugin.getName() + " (ID: " + plugin.getId() + ", Version: " + plugin.getVersion() + ")");
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Failed to instantiate plugin class: " + pluginClass.getName(), e);
            }
        }
    }
    
    /**
     * Ищет классы плагинов в JAR-файле.
     *
     * @param jarFile     JAR-файл для поиска
     * @param classLoader загрузчик классов для загрузки найденных классов
     * @return список найденных классов плагинов
     * @throws IOException если произошла ошибка при чтении файла
     */
    private List<Class<?>> findPluginClasses(File jarFile, ClassLoader classLoader) throws IOException {
        List<Class<?>> pluginClasses = new ArrayList<>();
        
        try (JarFile jar = new JarFile(jarFile)) {
            // Перебираем все записи в JAR-файле
            Enumeration<JarEntry> entries = jar.entries();
            
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                
                // Ищем только файлы .class
                if (!entry.isDirectory() && entry.getName().endsWith(".class")) {
                    // Преобразуем имя файла в имя класса
                    String className = entry.getName()
                            .replace('/', '.')
                            .substring(0, entry.getName().length() - 6); // Удаляем расширение .class
                    
                    try {
                        // Загружаем класс
                        Class<?> loadedClass = classLoader.loadClass(className);
                        
                        // Проверяем, реализует ли класс интерфейс Plugin
                        if (Plugin.class.isAssignableFrom(loadedClass) && 
                                !loadedClass.isInterface() && 
                                !java.lang.reflect.Modifier.isAbstract(loadedClass.getModifiers())) {
                            pluginClasses.add(loadedClass);
                        }
                    } catch (Throwable e) {
                        LOGGER.log(Level.WARNING, "Failed to load class: " + className, e);
                    }
                }
            }
        }
        
        return pluginClasses;
    }
    
    /**
     * Выгружает все плагины.
     */
    public void unloadAllPlugins() {
        for (Plugin plugin : plugins.values()) {
            try {
                plugin.cleanup();
                LOGGER.info("Unloaded plugin: " + plugin.getName() + " (ID: " + plugin.getId() + ")");
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error during plugin cleanup: " + plugin.getId(), e);
            }
        }
        
        plugins.clear();
        pluginClasses.clear();
        
        // Закрываем загрузчики классов
        for (ClassLoader loader : pluginClassLoaders) {
            if (loader instanceof URLClassLoader) {
                try {
                    ((URLClassLoader) loader).close();
                } catch (IOException e) {
                    LOGGER.log(Level.WARNING, "Failed to close plugin class loader", e);
                }
            }
        }
        
        pluginClassLoaders.clear();
    }
    
    /**
     * Выгружает плагин по идентификатору.
     *
     * @param pluginId идентификатор плагина
     * @return true, если плагин был выгружен успешно
     */
    public boolean unloadPlugin(String pluginId) {
        Plugin plugin = plugins.get(pluginId);
        if (plugin == null) {
            LOGGER.warning("Plugin not found: " + pluginId);
            return false;
        }
        
        try {
            plugin.cleanup();
            plugins.remove(pluginId);
            pluginClasses.remove(pluginId);
            LOGGER.info("Unloaded plugin: " + plugin.getName() + " (ID: " + plugin.getId() + ")");
            return true;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error during plugin cleanup: " + pluginId, e);
            return false;
        }
    }
    
    /**
     * Возвращает плагин по идентификатору.
     *
     * @param pluginId идентификатор плагина
     * @return экземпляр плагина или null, если плагин не найден
     */
    public Plugin getPlugin(String pluginId) {
        return plugins.get(pluginId);
    }
    
    /**
     * Возвращает список всех загруженных плагинов.
     *
     * @return список плагинов
     */
    public List<Plugin> getAllPlugins() {
        return new ArrayList<>(plugins.values());
    }
    
    /**
     * Возвращает список всех включенных плагинов.
     *
     * @return список включенных плагинов
     */
    public List<Plugin> getEnabledPlugins() {
        return plugins.values().stream()
                .filter(Plugin::isEnabled)
                .collect(Collectors.toList());
    }
    
    /**
     * Включает или отключает плагин.
     *
     * @param pluginId идентификатор плагина
     * @param enabled  новое состояние плагина
     * @return true, если состояние плагина было изменено успешно
     */
    public boolean setPluginEnabled(String pluginId, boolean enabled) {
        Plugin plugin = plugins.get(pluginId);
        if (plugin == null) {
            LOGGER.warning("Plugin not found: " + pluginId);
            return false;
        }
        
        plugin.setEnabled(enabled);
        LOGGER.info("Plugin " + pluginId + " is now " + (enabled ? "enabled" : "disabled"));
        return true;
    }
    
    /**
     * Включает или отключает все плагины.
     *
     * @param enabled новое состояние плагинов
     */
    public void setAllPluginsEnabled(boolean enabled) {
        for (Plugin plugin : plugins.values()) {
            plugin.setEnabled(enabled);
        }
        LOGGER.info("All plugins are now " + (enabled ? "enabled" : "disabled"));
    }
    
    /**
     * Проверяет, включены ли плагины.
     *
     * @return true, если плагины включены
     */
    public boolean arePluginsEnabled() {
        return pluginsEnabled;
    }
    
    /**
     * Включает или отключает систему плагинов.
     *
     * @param enabled новое состояние системы плагинов
     */
    public void setPluginsEnabled(boolean enabled) {
        this.pluginsEnabled = enabled;
        if (!enabled) {
            unloadAllPlugins();
        } else if (plugins.isEmpty()) {
            loadPlugins();
        }
    }
    
    /**
     * Выполняет все включенные плагины для указанного контекста.
     *
     * @param context контекст с данными для обработки
     * @return список плагинов, которые были выполнены успешно
     */
    public List<Plugin> executePlugins(PluginContext context) {
        if (!pluginsEnabled) {
            return Collections.emptyList();
        }
        
        List<Plugin> executedPlugins = new ArrayList<>();
        
        for (Plugin plugin : getEnabledPlugins()) {
            try {
                boolean success = plugin.execute(context);
                if (success) {
                    executedPlugins.add(plugin);
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error executing plugin: " + plugin.getId(), e);
            }
        }
        
        return executedPlugins;
    }
    
    /**
     * Выполняет конкретный плагин для указанного контекста.
     *
     * @param pluginId идентификатор плагина
     * @param context  контекст с данными для обработки
     * @return true, если плагин был выполнен успешно
     */
    public boolean executePlugin(String pluginId, PluginContext context) {
        if (!pluginsEnabled) {
            return false;
        }
        
        Plugin plugin = plugins.get(pluginId);
        if (plugin == null || !plugin.isEnabled()) {
            return false;
        }
        
        try {
            return plugin.execute(context);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error executing plugin: " + pluginId, e);
            return false;
        }
    }
    
    /**
     * Ищет плагины в директории плагинов.
     *
     * @return список найденных JAR-файлов с плагинами
     */
    public List<File> findPluginFiles() {
        File pluginDir = new File(pluginDirectory);
        if (!pluginDir.exists() || !pluginDir.isDirectory()) {
            return Collections.emptyList();
        }
        
        // Получаем список JAR-файлов в директории плагинов
        File[] jarFiles = pluginDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".jar"));
        
        if (jarFiles == null || jarFiles.length == 0) {
            return Collections.emptyList();
        }
        
        return Arrays.asList(jarFiles);
    }
    
    /**
     * Сканирует директорию плагинов на наличие новых плагинов.
     *
     * @return список идентификаторов новых плагинов
     */
    public List<String> scanForNewPlugins() {
        List<String> newPluginIds = new ArrayList<>();
        List<File> pluginFiles = findPluginFiles();
        
        // Загружаем каждый новый плагин
        for (File file : pluginFiles) {
            // Пропускаем уже загруженные плагины
            boolean alreadyLoaded = false;
            for (Plugin plugin : plugins.values()) {
                if (file.getName().contains(plugin.getId())) {
                    alreadyLoaded = true;
                    break;
                }
            }
            
            if (!alreadyLoaded) {
                try {
                    int oldSize = plugins.size();
                    loadPlugin(file);
                    int newSize = plugins.size();
                    
                    // Если были загружены новые плагины, находим их идентификаторы
                    if (newSize > oldSize) {
                        for (String id : plugins.keySet()) {
                            if (!newPluginIds.contains(id)) {
                                newPluginIds.add(id);
                            }
                        }
                    }
                } catch (Exception e) {
                    LOGGER.log(Level.SEVERE, "Failed to load new plugin: " + file.getName(), e);
                }
            }
        }
        
        return newPluginIds;
    }
    
    /**
     * Устанавливает директорию плагинов.
     *
     * @param directory путь к директории плагинов
     */
    public void setPluginDirectory(String directory) {
        this.pluginDirectory = directory;
    }
    
    /**
     * Получает директорию плагинов.
     *
     * @return путь к директории плагинов
     */
    public String getPluginDirectory() {
        return pluginDirectory;
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.plugin;

/**
 * Интерфейс для плагинов LaPrizmo.
 * Плагины могут расширять функциональность приложения, обрабатывать данные
 * и взаимодействовать с пользовательским интерфейсом.
 */
public interface Plugin {
    
    /**
     * Инициализирует плагин.
     * Вызывается один раз при загрузке плагина.
     *
     * @param context контекст плагина, содержащий доступ к ресурсам приложения
     */
    void initialize(PluginContext context);
    
    /**
     * Выполняет основную функцию плагина.
     * Вызывается для обработки данных в контексте.
     *
     * @param context контекст с данными для обработки
     * @return результат выполнения плагина (true - успешно, false - с ошибками)
     */
    boolean execute(PluginContext context);
    
    /**
     * Освобождает ресурсы, занятые плагином.
     * Вызывается при выгрузке плагина или закрытии приложения.
     */
    void cleanup();
    
    /**
     * Возвращает уникальный идентификатор плагина.
     *
     * @return идентификатор плагина
     */
    String getId();
    
    /**
     * Возвращает название плагина.
     *
     * @return название плагина
     */
    String getName();
    
    /**
     * Возвращает версию плагина.
     *
     * @return версия плагина
     */
    String getVersion();
    
    /**
     * Возвращает описание плагина.
     *
     * @return описание плагина
     */
    String getDescription();
    
    /**
     * Возвращает информацию об авторе плагина.
     *
     * @return информация об авторе
     */
    String getAuthor();
    
    /**
     * Проверяет, включен ли плагин.
     *
     * @return true, если плагин включен
     */
    boolean isEnabled();
    
    /**
     * Включает или отключает плагин.
     *
     * @param enabled новое состояние плагина
     */
    void setEnabled(boolean enabled);
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.plugin;

import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolManager;
import com.laprizmo.network.L2Packet;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Контекст плагина, предоставляющий доступ к ресурсам приложения и данным для обработки.
 * Используется для передачи информации между плагинами и основным приложением.
 */
public class PluginContext {
    
    // Доступ к основным компонентам приложения
    private CryptoEngine cryptoEngine;
    private CryptoOperations cryptoOperations;
    private ProtocolManager protocolManager;
    
    // Динамические данные для обработки
    private byte[] data;
    private L2Packet packet;
    private L2Packet modifiedPacket;
    private boolean packetModified = false;
    
    // Объект файла для плагинов, работающих с файлами
    private File file;
    
    // Настройки плагина
    private Properties settings;
    
    // Пользовательские данные для обмена между плагинами
    private Map<String, Object> sharedData;
    
    /**
     * Создает новый контекст плагина с минимальными данными.
     */
    public PluginContext() {
        this.sharedData = new HashMap<>();
        this.settings = new Properties();
    }
    
    /**
     * Создает новый контекст плагина для обработки массива байтов.
     *
     * @param data массив байтов для обработки
     */
    public PluginContext(byte[] data) {
        this();
        this.data = data;
    }
    
    /**
     * Создает новый контекст плагина для обработки пакета.
     *
     * @param packet пакет для обработки
     */
    public PluginContext(L2Packet packet) {
        this();
        this.packet = packet;
    }
    
    /**
     * Создает новый контекст плагина для обработки файла.
     *
     * @param file файл для обработки
     */
    public PluginContext(File file) {
        this();
        this.file = file;
    }
    
    /**
     * Создает новый контекст плагина с полным набором компонентов.
     *
     * @param cryptoEngine движок криптографии
     * @param cryptoOperations операции криптографии
     * @param protocolManager менеджер протоколов
     */
    public PluginContext(CryptoEngine cryptoEngine, CryptoOperations cryptoOperations, ProtocolManager protocolManager) {
        this();
        this.cryptoEngine = cryptoEngine;
        this.cryptoOperations = cryptoOperations;
        this.protocolManager = protocolManager;
    }
    
    /**
     * Получает данные для обработки.
     *
     * @return массив байтов или null, если данные не установлены
     */
    public byte[] getData() {
        return data;
    }
    
    /**
     * Устанавливает данные для обработки.
     *
     * @param data массив байтов
     */
    public void setData(byte[] data) {
        this.data = data;
    }
    
    /**
     * Получает пакет для обработки.
     *
     * @return пакет или null, если пакет не установлен
     */
    public L2Packet getPacket() {
        return packet;
    }
    
    /**
     * Устанавливает пакет для обработки.
     *
     * @param packet пакет
     */
    public void setPacket(L2Packet packet) {
        this.packet = packet;
    }
    
    /**
     * Получает модифицированный пакет.
     *
     * @return модифицированный пакет или null, если пакет не был модифицирован
     */
    public L2Packet getModifiedPacket() {
        return modifiedPacket;
    }
    
    /**
     * Устанавливает модифицированный пакет.
     *
     * @param modifiedPacket модифицированный пакет
     */
    public void setModifiedPacket(L2Packet modifiedPacket) {
        this.modifiedPacket = modifiedPacket;
        this.packetModified = (modifiedPacket != null);
    }
    
    /**
     * Проверяет, был ли пакет модифицирован.
     *
     * @return true, если пакет был модифицирован
     */
    public boolean isPacketModified() {
        return packetModified;
    }
    
    /**
     * Получает файл для обработки.
     *
     * @return файл или null, если файл не установлен
     */
    public File getFile() {
        return file;
    }
    
    /**
     * Устанавливает файл для обработки.
     *
     * @param file файл
     */
    public void setFile(File file) {
        this.file = file;
    }
    
    /**
     * Получает движок криптографии.
     *
     * @return движок криптографии или null, если он не установлен
     */
    public CryptoEngine getCryptoEngine() {
        return cryptoEngine;
    }
    
    /**
     * Устанавливает движок криптографии.
     *
     * @param cryptoEngine движок криптографии
     */
    public void setCryptoEngine(CryptoEngine cryptoEngine) {
        this.cryptoEngine = cryptoEngine;
    }
    
    /**
     * Получает операции криптографии.
     *
     * @return операции криптографии или null, если они не установлены
     */
    public CryptoOperations getCryptoOperations() {
        return cryptoOperations;
    }
    
    /**
     * Устанавливает операции криптографии.
     *
     * @param cryptoOperations операции криптографии
     */
    public void setCryptoOperations(CryptoOperations cryptoOperations) {
        this.cryptoOperations = cryptoOperations;
    }
    
    /**
     * Получает менеджер протоколов.
     *
     * @return менеджер протоколов или null, если он не установлен
     */
    public ProtocolManager getProtocolManager() {
        return protocolManager;
    }
    
    /**
     * Устанавливает менеджер протоколов.
     *
     * @param protocolManager менеджер протоколов
     */
    public void setProtocolManager(ProtocolManager protocolManager) {
        this.protocolManager = protocolManager;
    }
    
    /**
     * Получает настройки плагина.
     *
     * @return настройки плагина
     */
    public Properties getSettings() {
        return settings;
    }
    
    /**
     * Устанавливает настройки плагина.
     *
     * @param settings настройки плагина
     */
    public void setSettings(Properties settings) {
        this.settings = settings;
    }
    
    /**
     * Получает значение настройки.
     *
     * @param key ключ настройки
     * @return значение настройки или null, если настройка не найдена
     */
    public String getSetting(String key) {
        return settings.getProperty(key);
    }
    
    /**
     * Устанавливает значение настройки.
     *
     * @param key ключ настройки
     * @param value значение настройки
     */
    public void setSetting(String key, String value) {
        settings.setProperty(key, value);
    }
    
    /**
     * Получает карту разделяемых данных.
     *
     * @return карта разделяемых данных
     */
    public Map<String, Object> getSharedData() {
        return sharedData;
    }
    
    /**
     * Устанавливает карту разделяемых данных.
     *
     * @param sharedData карта разделяемых данных
     */
    public void setSharedData(Map<String, Object> sharedData) {
        this.sharedData = sharedData;
    }
    
    /**
     * Получает разделяемый объект по ключу.
     *
     * @param key ключ объекта
     * @return объект или null, если объект не найден
     */
    public Object getSharedObject(String key) {
        return sharedData.get(key);
    }
    
    /**
     * Устанавливает разделяемый объект.
     *
     * @param key ключ объекта
     * @param value объект
     */
    public void setSharedObject(String key, Object value) {
        sharedData.put(key, value);
    }
}
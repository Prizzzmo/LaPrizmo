/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.util.DatFileUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Класс для выполнения криптографических операций над файлами Lineage 2.
 * Обеспечивает шифрование и дешифрование файлов с различными параметрами.
 */
public class CryptoOperations {
    
    private static final Logger LOGGER = Logger.getLogger(CryptoOperations.class.getName());
    
    // Стандартный размер буфера
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    
    // Менеджер протоколов
    private final ProtocolManager protocolManager;
    
    /**
     * Параметры операции шифрования/дешифрования.
     */
    public static class CryptoParams {
        // Версия протокола
        private int protocolVersion;
        
        // Проверять ли контрольную сумму при дешифровании
        private boolean verifyChecksum = false;
        
        // Добавлять/удалять ли хвост файла
        private boolean handleTail = true;
        
        // Пользовательское имя файла для протокола 121
        private String forceFilename = null;
        
        // Пользовательский заголовок файла
        private String customHeader = null;
        
        // Пользовательский хвост файла
        private String customTail = null;
        
        /**
         * Создает параметры с указанной версией протокола.
         *
         * @param protocolVersion версия протокола
         */
        public CryptoParams(int protocolVersion) {
            this.protocolVersion = protocolVersion;
        }
        
        // Геттеры и сеттеры
        
        public int getProtocolVersion() {
            return protocolVersion;
        }
        
        public void setProtocolVersion(int protocolVersion) {
            this.protocolVersion = protocolVersion;
        }
        
        public boolean isVerifyChecksum() {
            return verifyChecksum;
        }
        
        public void setVerifyChecksum(boolean verifyChecksum) {
            this.verifyChecksum = verifyChecksum;
        }
        
        public boolean isHandleTail() {
            return handleTail;
        }
        
        public void setHandleTail(boolean handleTail) {
            this.handleTail = handleTail;
        }
        
        public String getForceFilename() {
            return forceFilename;
        }
        
        public void setForceFilename(String forceFilename) {
            this.forceFilename = forceFilename;
        }
        
        public String getCustomHeader() {
            return customHeader;
        }
        
        public void setCustomHeader(String customHeader) {
            this.customHeader = customHeader;
        }
        
        public String getCustomTail() {
            return customTail;
        }
        
        public void setCustomTail(String customTail) {
            this.customTail = customTail;
        }
    }
    
    /**
     * Создает новый объект для криптографических операций.
     */
    public CryptoOperations() {
        this.protocolManager = ProtocolManager.getInstance();
    }
    
    /**
     * Дешифрует файл.
     *
     * @param inputPath путь к зашифрованному файлу
     * @param outputPath путь для сохранения дешифрованного файла
     * @param params параметры дешифрования
     * @throws CryptoException если произошла ошибка при дешифровании
     * @throws IOException если произошла ошибка ввода/вывода
     */
    public void decryptFile(String inputPath, String outputPath, CryptoParams params) throws CryptoException, IOException {
        Path input = Paths.get(inputPath);
        Path output = Paths.get(outputPath);
        
        // Получаем имя файла для протокола 121
        String fileName = (params.getForceFilename() != null) ? params.getForceFilename() : input.getFileName().toString();
        
        // Создаем родительскую директорию, если она не существует
        Files.createDirectories(output.getParent());
        
        try (InputStream fileIn = Files.newInputStream(input)) {
            // Читаем файл полностью
            byte[] fileData = readAllBytes(fileIn);
            
            // Проверяем контрольную сумму, если требуется
            if (params.isVerifyChecksum() && !DatFileUtils.validateChecksum(fileData)) {
                throw new CryptoException("Checksum verification failed for file: " + inputPath);
            }
            
            // Отделяем заголовок и хвост
            byte[] content = extractContent(fileData, params);
            
            // Создаем поток для дешифрования
            try (InputStream contentIn = new ByteArrayInputStream(content);
                 InputStream decIn = protocolManager.getDecryptionInputStream(contentIn, params.getProtocolVersion(), fileName);
                 OutputStream fileOut = Files.newOutputStream(output)) {
                
                // Копируем дешифрованные данные
                copy(decIn, fileOut);
            }
        }
    }
    
    /**
     * Шифрует файл.
     *
     * @param inputPath путь к исходному файлу
     * @param outputPath путь для сохранения зашифрованного файла
     * @param params параметры шифрования
     * @throws CryptoException если произошла ошибка при шифровании
     * @throws IOException если произошла ошибка ввода/вывода
     */
    public void encryptFile(String inputPath, String outputPath, CryptoParams params) throws CryptoException, IOException {
        Path input = Paths.get(inputPath);
        Path output = Paths.get(outputPath);
        
        // Получаем имя файла для протокола 121
        String fileName = (params.getForceFilename() != null) ? params.getForceFilename() : input.getFileName().toString();
        
        // Создаем родительскую директорию, если она не существует
        Files.createDirectories(output.getParent());
        
        // Получаем заголовок
        String header = (params.getCustomHeader() != null) 
                        ? params.getCustomHeader() 
                        : protocolManager.getProtocolHeader(params.getProtocolVersion());
        
        try (InputStream fileIn = Files.newInputStream(input);
             ByteArrayOutputStream encOut = new ByteArrayOutputStream()) {
            
            // Записываем заголовок
            writeHeader(encOut, header);
            
            // Создаем поток для шифрования
            try (OutputStream cryptOut = protocolManager.getEncryptionOutputStream(encOut, params.getProtocolVersion(), fileName)) {
                // Копируем данные через шифрующий поток
                copy(fileIn, cryptOut);
            }
            
            // Получаем зашифрованные данные
            byte[] encryptedData = encOut.toByteArray();
            
            // Создаем выходной файл
            try (OutputStream fileOut = Files.newOutputStream(output)) {
                // Если нужно добавить хвост
                if (params.isHandleTail()) {
                    if (params.getCustomTail() != null) {
                        // Добавляем пользовательский хвост
                        byte[] footer = DatFileUtils.createCustomFooter(encryptedData, params.getCustomTail());
                        fileOut.write(encryptedData);
                        fileOut.write(footer);
                    } else {
                        // Добавляем стандартный хвост с контрольной суммой
                        DatFileUtils.writeWithTail(fileOut, encryptedData);
                    }
                } else {
                    // Записываем без хвоста
                    fileOut.write(encryptedData);
                }
            }
        }
    }
    
    /**
     * Извлекает содержимое файла, отделяя заголовок и хвост.
     *
     * @param fileData полные данные файла
     * @param params параметры операции
     * @return содержимое файла без заголовка и хвоста
     * @throws CryptoException если файл имеет неверный формат
     */
    private byte[] extractContent(byte[] fileData, CryptoParams params) throws CryptoException {
        // Ищем начало содержимого (после заголовка)
        String expectedHeader = protocolManager.getProtocolHeader(params.getProtocolVersion());
        int headerLength = expectedHeader.length() * 2; // 2 байта на символ (UTF-16)
        
        if (fileData.length < headerLength) {
            throw new CryptoException("File is too small to contain a header");
        }
        
        // Получаем содержимое без заголовка
        int contentStart = headerLength;
        int contentLength = fileData.length - contentStart;
        
        // Удаляем хвост, если требуется
        if (params.isHandleTail()) {
            contentLength -= DatFileUtils.FOOTER_SIZE;
            if (contentLength < 0) {
                throw new CryptoException("File is too small to contain a tail");
            }
        }
        
        // Извлекаем содержимое
        byte[] content = new byte[contentLength];
        System.arraycopy(fileData, contentStart, content, 0, contentLength);
        
        return content;
    }
    
    /**
     * Записывает заголовок в выходной поток.
     *
     * @param out выходной поток
     * @param header заголовок
     * @throws IOException если произошла ошибка записи
     */
    private void writeHeader(OutputStream out, String header) throws IOException {
        // Преобразуем заголовок в UTF-16LE
        byte[] headerBytes = header.getBytes(StandardCharsets.UTF_16LE);
        out.write(headerBytes);
    }
    
    /**
     * Копирует данные из входного потока в выходной.
     *
     * @param in входной поток
     * @param out выходной поток
     * @throws IOException если произошла ошибка ввода/вывода
     */
    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        int bytesRead;
        
        while ((bytesRead = in.read(buffer)) != -1) {
            out.write(buffer, 0, bytesRead);
        }
    }
    
    /**
     * Читает все байты из входного потока.
     *
     * @param in входной поток
     * @return прочитанные данные
     * @throws IOException если произошла ошибка чтения
     */
    private byte[] readAllBytes(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        int bytesRead;
        
        while ((bytesRead = in.read(buffer)) != -1) {
            out.write(buffer, 0, bytesRead);
        }
        
        return out.toByteArray();
    }
}
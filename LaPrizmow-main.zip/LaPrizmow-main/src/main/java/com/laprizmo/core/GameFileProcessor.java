/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Интерфейс процессора игровых файлов Lineage 2.
 * Определяет операции для работы с игровыми файлами (*.dat и *.txt).
 */
public interface GameFileProcessor {
    
    /**
     * Типы игровых файлов Lineage 2
     */
    enum FileType {
        /** DAT-файл */
        DAT,
        /** TXT-файл */
        TXT,
        /** Неизвестный тип файла */
        UNKNOWN
    }
    
    /**
     * Результат обработки файла
     */
    class ProcessingResult {
        private final boolean success;
        private final String message;
        private final File outputFile;
        private final long processingTime;
        
        public ProcessingResult(boolean success, String message, File outputFile, long processingTime) {
            this.success = success;
            this.message = message;
            this.outputFile = outputFile;
            this.processingTime = processingTime;
        }
        
        public boolean isSuccess() {
            return success;
        }
        
        public String getMessage() {
            return message;
        }
        
        public File getOutputFile() {
            return outputFile;
        }
        
        public long getProcessingTime() {
            return processingTime;
        }
        
        @Override
        public String toString() {
            return String.format("%s: %s (in %dms)",
                    success ? "Success" : "Failure",
                    message,
                    processingTime);
        }
    }
    
    /**
     * Определяет тип файла на основе его расширения и содержимого.
     *
     * @param file файл для анализа
     * @return тип файла
     * @throws IOException если возникла ошибка при чтении файла
     */
    FileType detectFileType(File file) throws IOException;
    
    /**
     * Открывает DAT-файл и возвращает список имен содержащихся в нем игровых ресурсов.
     *
     * @param datFile DAT-файл
     * @return список имен ресурсов
     * @throws IOException     если возникла ошибка при чтении файла
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    List<String> listDatContents(File datFile) throws IOException, CryptoException;
    
    /**
     * Распаковывает DAT-файл в указанный каталог.
     *
     * @param datFile      DAT-файл
     * @param outputDir    каталог для извлеченных файлов
     * @param cryptoVersion версия шифрования
     * @return результат обработки
     */
    ProcessingResult unpackDat(File datFile, File outputDir, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Извлекает конкретный ресурс из DAT-файла.
     *
     * @param datFile      DAT-файл
     * @param resourceName имя ресурса
     * @param outputFile   файл для сохранения ресурса
     * @param cryptoVersion версия шифрования
     * @return результат обработки
     */
    ProcessingResult extractResource(File datFile, String resourceName, File outputFile, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Создает новый DAT-файл из указанного каталога.
     *
     * @param sourceDir    каталог с исходными файлами
     * @param outputDat    выходной DAT-файл
     * @param cryptoVersion версия шифрования
     * @return результат обработки
     */
    ProcessingResult createDat(File sourceDir, File outputDat, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Перешифровывает DAT-файл с использованием другой версии шифрования.
     *
     * @param inputDat     входной DAT-файл
     * @param outputDat    выходной DAT-файл
     * @param sourceVersion исходная версия шифрования
     * @param targetVersion целевая версия шифрования
     * @return результат обработки
     */
    ProcessingResult reencryptDat(File inputDat, File outputDat, 
                                CryptoEngine.CryptoVersion sourceVersion, 
                                CryptoEngine.CryptoVersion targetVersion);
    
    /**
     * Преобразует TXT-файл в DAT-файл.
     *
     * @param txtFile      TXT-файл
     * @param outputDat    выходной DAT-файл
     * @param cryptoVersion версия шифрования
     * @return результат обработки
     */
    ProcessingResult txtToDat(File txtFile, File outputDat, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Преобразует DAT-файл в TXT-файл.
     *
     * @param datFile      DAT-файл
     * @param outputTxt    выходной TXT-файл
     * @param cryptoVersion версия шифрования
     * @return результат обработки
     */
    ProcessingResult datToTxt(File datFile, File outputTxt, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Преобразует все TXT-файлы в указанном каталоге в DAT-файлы.
     *
     * @param sourceDir    каталог с исходными TXT-файлами
     * @param outputDir    каталог для выходных DAT-файлов
     * @param cryptoVersion версия шифрования
     * @return количество обработанных файлов
     */
    int batchTxtToDat(File sourceDir, File outputDir, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Преобразует все DAT-файлы в указанном каталоге в TXT-файлы.
     *
     * @param sourceDir    каталог с исходными DAT-файлами
     * @param outputDir    каталог для выходных TXT-файлов
     * @param cryptoVersion версия шифрования
     * @return количество обработанных файлов
     */
    int batchDatToTxt(File sourceDir, File outputDir, CryptoEngine.CryptoVersion cryptoVersion);
    
    /**
     * Перешифровывает все DAT-файлы в указанном каталоге.
     *
     * @param sourceDir    каталог с исходными DAT-файлами
     * @param outputDir    каталог для выходных DAT-файлов
     * @param sourceVersion исходная версия шифрования
     * @param targetVersion целевая версия шифрования
     * @return количество обработанных файлов
     */
    int batchReencrypt(File sourceDir, File outputDir, 
                    CryptoEngine.CryptoVersion sourceVersion, 
                    CryptoEngine.CryptoVersion targetVersion);
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Сбор метрик производительности шифрования.
 * Этот класс собирает статистику о времени выполнения операций шифрования и дешифрования,
 * размере обработанных данных и количестве вызовов для каждой версии криптографического алгоритма.
 */
public class CryptoMetrics {
    
    /**
     * Метрики для конкретной версии шифрования.
     */
    public static class VersionMetrics {
        // Общее количество операций шифрования
        private final AtomicLong encryptionCount = new AtomicLong(0);
        // Общее количество операций дешифрования
        private final AtomicLong decryptionCount = new AtomicLong(0);
        // Общее время шифрования в наносекундах
        private final AtomicLong encryptionTime = new AtomicLong(0);
        // Общее время дешифрования в наносекундах
        private final AtomicLong decryptionTime = new AtomicLong(0);
        // Общий размер зашифрованных данных в байтах
        private final AtomicLong encryptedBytes = new AtomicLong(0);
        // Общий размер дешифрованных данных в байтах
        private final AtomicLong decryptedBytes = new AtomicLong(0);
        
        /**
         * Записывает операцию шифрования.
         *
         * @param bytes размер данных в байтах
         * @param time  время выполнения в наносекундах
         */
        public void recordEncryption(long bytes, long time) {
            encryptionCount.incrementAndGet();
            encryptionTime.addAndGet(time);
            encryptedBytes.addAndGet(bytes);
        }
        
        /**
         * Записывает операцию дешифрования.
         *
         * @param bytes размер данных в байтах
         * @param time  время выполнения в наносекундах
         */
        public void recordDecryption(long bytes, long time) {
            decryptionCount.incrementAndGet();
            decryptionTime.addAndGet(time);
            decryptedBytes.addAndGet(bytes);
        }
        
        /**
         * Возвращает общее количество операций шифрования.
         *
         * @return количество операций
         */
        public long getEncryptionCount() {
            return encryptionCount.get();
        }
        
        /**
         * Возвращает общее количество операций дешифрования.
         *
         * @return количество операций
         */
        public long getDecryptionCount() {
            return decryptionCount.get();
        }
        
        /**
         * Возвращает общее время шифрования в наносекундах.
         *
         * @return время в наносекундах
         */
        public long getEncryptionTime() {
            return encryptionTime.get();
        }
        
        /**
         * Возвращает общее время дешифрования в наносекундах.
         *
         * @return время в наносекундах
         */
        public long getDecryptionTime() {
            return decryptionTime.get();
        }
        
        /**
         * Возвращает общий размер зашифрованных данных в байтах.
         *
         * @return размер в байтах
         */
        public long getEncryptedBytes() {
            return encryptedBytes.get();
        }
        
        /**
         * Возвращает общий размер дешифрованных данных в байтах.
         *
         * @return размер в байтах
         */
        public long getDecryptedBytes() {
            return decryptedBytes.get();
        }
        
        /**
         * Возвращает среднее время шифрования в наносекундах.
         *
         * @return среднее время в наносекундах или 0, если операций не было
         */
        public double getAverageEncryptionTime() {
            long count = encryptionCount.get();
            return count > 0 ? (double) encryptionTime.get() / count : 0;
        }
        
        /**
         * Возвращает среднее время дешифрования в наносекундах.
         *
         * @return среднее время в наносекундах или 0, если операций не было
         */
        public double getAverageDecryptionTime() {
            long count = decryptionCount.get();
            return count > 0 ? (double) decryptionTime.get() / count : 0;
        }
        
        /**
         * Возвращает пропускную способность шифрования в байтах в секунду.
         *
         * @return пропускная способность в байтах в секунду или 0, если операций не было
         */
        public double getEncryptionThroughput() {
            long time = encryptionTime.get();
            return time > 0 ? (encryptedBytes.get() * 1_000_000_000.0) / time : 0;
        }
        
        /**
         * Возвращает пропускную способность дешифрования в байтах в секунду.
         *
         * @return пропускная способность в байтах в секунду или 0, если операций не было
         */
        public double getDecryptionThroughput() {
            long time = decryptionTime.get();
            return time > 0 ? (decryptedBytes.get() * 1_000_000_000.0) / time : 0;
        }
        
        /**
         * Сбрасывает все метрики.
         */
        public void reset() {
            encryptionCount.set(0);
            decryptionCount.set(0);
            encryptionTime.set(0);
            decryptionTime.set(0);
            encryptedBytes.set(0);
            decryptedBytes.set(0);
        }
        
        @Override
        public String toString() {
            return String.format(
                    "EncCount: %d, DecCount: %d, EncTime: %.2f ms, DecTime: %.2f ms, " +
                            "EncBytes: %d B, DecBytes: %d B, EncThroughput: %.2f MB/s, DecThroughput: %.2f MB/s",
                    encryptionCount.get(), decryptionCount.get(),
                    encryptionTime.get() / 1_000_000.0, decryptionTime.get() / 1_000_000.0,
                    encryptedBytes.get(), decryptedBytes.get(),
                    getEncryptionThroughput() / (1024 * 1024), getDecryptionThroughput() / (1024 * 1024)
            );
        }
    }
    
    // Метрики для каждой версии шифрования
    private final Map<CryptoEngine.CryptoVersion, VersionMetrics> versionMetrics = 
            new EnumMap<>(CryptoEngine.CryptoVersion.class);
    
    // Блокировка для обеспечения потокобезопасности
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    
    /**
     * Создает новый объект метрик шифрования.
     */
    public CryptoMetrics() {
        // Инициализируем метрики для всех версий
        for (CryptoEngine.CryptoVersion version : CryptoEngine.CryptoVersion.values()) {
            versionMetrics.put(version, new VersionMetrics());
        }
    }
    
    /**
     * Записывает операцию шифрования.
     *
     * @param version версия шифрования
     * @param bytes   размер данных в байтах
     * @param time    время выполнения в наносекундах
     */
    public void recordEncryption(CryptoEngine.CryptoVersion version, long bytes, long time) {
        lock.readLock().lock();
        try {
            VersionMetrics metrics = versionMetrics.get(version);
            if (metrics != null) {
                metrics.recordEncryption(bytes, time);
            }
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Записывает операцию дешифрования.
     *
     * @param version версия шифрования
     * @param bytes   размер данных в байтах
     * @param time    время выполнения в наносекундах
     */
    public void recordDecryption(CryptoEngine.CryptoVersion version, long bytes, long time) {
        lock.readLock().lock();
        try {
            VersionMetrics metrics = versionMetrics.get(version);
            if (metrics != null) {
                metrics.recordDecryption(bytes, time);
            }
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Возвращает метрики для указанной версии шифрования.
     *
     * @param version версия шифрования
     * @return метрики или null, если версия не найдена
     */
    public VersionMetrics getMetrics(CryptoEngine.CryptoVersion version) {
        lock.readLock().lock();
        try {
            return versionMetrics.get(version);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Возвращает карту метрик для всех версий шифрования.
     *
     * @return карта метрик
     */
    public Map<CryptoEngine.CryptoVersion, VersionMetrics> getAllMetrics() {
        lock.readLock().lock();
        try {
            return new EnumMap<>(versionMetrics);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Сбрасывает все метрики.
     */
    public void resetAll() {
        lock.writeLock().lock();
        try {
            for (VersionMetrics metrics : versionMetrics.values()) {
                metrics.reset();
            }
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Сбрасывает метрики для указанной версии шифрования.
     *
     * @param version версия шифрования
     */
    public void reset(CryptoEngine.CryptoVersion version) {
        lock.readLock().lock();
        try {
            VersionMetrics metrics = versionMetrics.get(version);
            if (metrics != null) {
                metrics.reset();
            }
        } finally {
            lock.readLock().unlock();
        }
    }
    
    @Override
    public String toString() {
        lock.readLock().lock();
        try {
            StringBuilder sb = new StringBuilder("Crypto Metrics:\n");
            
            for (Map.Entry<CryptoEngine.CryptoVersion, VersionMetrics> entry : versionMetrics.entrySet()) {
                VersionMetrics metrics = entry.getValue();
                
                // Выводим только метрики с ненулевыми значениями
                if (metrics.getEncryptionCount() > 0 || metrics.getDecryptionCount() > 0) {
                    sb.append(entry.getKey()).append(": ").append(metrics).append('\n');
                }
            }
            
            return sb.toString();
        } finally {
            lock.readLock().unlock();
        }
    }
}
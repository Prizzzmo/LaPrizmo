/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Стандартная реализация процессора игровых файлов Lineage 2.
 * Обеспечивает операции для работы с игровыми файлами (*.dat и *.txt).
 */
public class DefaultGameFileProcessor implements GameFileProcessor {
    
    private static final Logger LOGGER = Logger.getLogger(DefaultGameFileProcessor.class.getName());
    
    // Константы для формата DAT-файлов
    private static final int DAT_HEADER_SIZE = 28;
    private static final byte[] DAT_SIGNATURE = {0x18, 0x21, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00};
    
    // Константы для формата TXT-файлов
    private static final String TXT_HEADER_PATTERN = "^[\\w\\s]+\\s+file\\s+format.*";
    private static final Pattern RESOURCE_PATTERN = Pattern.compile("^\\s*([\\w\\./\\\\-]+)\\s*=\\s*(.*)$");
    
    // Движок шифрования
    private final CryptoEngine cryptoEngine;
    
    /**
     * Создает новый процессор игровых файлов.
     *
     * @param cryptoEngine движок шифрования
     */
    public DefaultGameFileProcessor(CryptoEngine cryptoEngine) {
        this.cryptoEngine = cryptoEngine;
    }
    
    @Override
    public FileType detectFileType(File file) throws IOException {
        if (!file.exists() || !file.isFile()) {
            throw new IOException("File does not exist or is not a regular file: " + file.getPath());
        }
        
        // Проверяем по расширению файла
        String fileName = file.getName().toLowerCase();
        if (fileName.endsWith(".dat")) {
            // Дополнительно проверяем сигнатуру DAT-файла
            if (checkDatSignature(file)) {
                return FileType.DAT;
            }
        } else if (fileName.endsWith(".txt")) {
            // Дополнительно проверяем формат TXT-файла
            if (checkTxtFormat(file)) {
                return FileType.TXT;
            }
        }
        
        // Не удалось определить тип файла
        return FileType.UNKNOWN;
    }
    
    /**
     * Проверяет сигнатуру DAT-файла.
     *
     * @param file файл для проверки
     * @return true, если файл имеет сигнатуру DAT-файла
     */
    private boolean checkDatSignature(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] header = new byte[8];
            int bytesRead = fis.read(header);
            
            if (bytesRead != 8) {
                return false;
            }
            
            return Arrays.equals(header, DAT_SIGNATURE);
        }
    }
    
    /**
     * Проверяет формат TXT-файла.
     *
     * @param file файл для проверки
     * @return true, если файл соответствует формату TXT-файла
     */
    private boolean checkTxtFormat(File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String firstLine = reader.readLine();
            if (firstLine == null) {
                return false;
            }
            
            // Проверяем, соответствует ли первая строка заголовку TXT-файла
            return firstLine.matches(TXT_HEADER_PATTERN);
        }
    }
    
    @Override
    public List<String> listDatContents(File datFile) throws IOException, CryptoException {
        // Проверяем, что файл существует и является DAT-файлом
        if (detectFileType(datFile) != FileType.DAT) {
            throw new IOException("File is not a valid DAT file: " + datFile.getPath());
        }
        
        List<String> resourceNames = new ArrayList<>();
        
        try (FileInputStream fis = new FileInputStream(datFile)) {
            // Читаем заголовок DAT-файла
            byte[] header = new byte[DAT_HEADER_SIZE];
            if (fis.read(header) != DAT_HEADER_SIZE) {
                throw new IOException("Invalid DAT file header: " + datFile.getPath());
            }
            
            // Разбираем заголовок
            ByteBuffer buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
            buffer.position(8); // Пропускаем сигнатуру
            
            int resourceCount = buffer.getInt();
            /* Пропускаем неиспользуемые поля
            int tableOffset = buffer.getInt();
            int tableSize = buffer.getInt();
            int dataOffset = buffer.getInt();
            */
            
            // Читаем таблицу ресурсов
            for (int i = 0; i < resourceCount; i++) {
                byte[] entryHeader = new byte[8];
                if (fis.read(entryHeader) != 8) {
                    throw new IOException("Invalid resource entry header: " + datFile.getPath());
                }
                
                ByteBuffer entryBuffer = ByteBuffer.wrap(entryHeader).order(ByteOrder.LITTLE_ENDIAN);
                int nameLength = entryBuffer.getInt();
                /* Пропускаем размер ресурса
                int resourceSize = entryBuffer.getInt();
                */
                
                // Читаем имя ресурса
                byte[] nameBytes = new byte[nameLength];
                if (fis.read(nameBytes) != nameLength) {
                    throw new IOException("Invalid resource name: " + datFile.getPath());
                }
                
                String resourceName = new String(nameBytes, StandardCharsets.UTF_8);
                resourceNames.add(resourceName);
                
                // Пропускаем данные ресурса
                // Чтение размера ресурса
                byte[] sizeBytes = new byte[4];
                if (fis.read(sizeBytes) != 4) {
                    throw new IOException("Invalid resource size: " + datFile.getPath());
                }
                
                int resourceSize = ByteBuffer.wrap(sizeBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
                fis.skip(resourceSize);
            }
        }
        
        return resourceNames;
    }
    
    @Override
    public ProcessingResult unpackDat(File datFile, File outputDir, CryptoEngine.CryptoVersion cryptoVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что файл существует и является DAT-файлом
            if (detectFileType(datFile) != FileType.DAT) {
                return new ProcessingResult(false, "File is not a valid DAT file: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем выходной каталог, если он не существует
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }
            
            AtomicInteger extractedCount = new AtomicInteger(0);
            
            // Получаем список ресурсов в DAT-файле
            List<String> resources = listDatContents(datFile);
            
            // Извлекаем каждый ресурс
            for (String resourceName : resources) {
                File outputFile = new File(outputDir, resourceName);
                
                // Создаем родительский каталог, если он не существует
                File parentDir = outputFile.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                
                // Извлекаем ресурс
                ProcessingResult result = extractResource(datFile, resourceName, outputFile, cryptoVersion);
                if (result.isSuccess()) {
                    extractedCount.incrementAndGet();
                } else {
                    LOGGER.warning("Failed to extract resource: " + resourceName + " - " + result.getMessage());
                }
            }
            
            long endTime = System.currentTimeMillis();
            return new ProcessingResult(true, 
                    "Extracted " + extractedCount.get() + " of " + resources.size() + " resources", 
                    outputDir, endTime - startTime);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error unpacking DAT file: " + datFile.getPath(), e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    @Override
    public ProcessingResult extractResource(File datFile, String resourceName, File outputFile, CryptoEngine.CryptoVersion cryptoVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что файл существует и является DAT-файлом
            if (detectFileType(datFile) != FileType.DAT) {
                return new ProcessingResult(false, "File is not a valid DAT file: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            try (FileInputStream fis = new FileInputStream(datFile)) {
                // Читаем заголовок DAT-файла
                byte[] header = new byte[DAT_HEADER_SIZE];
                if (fis.read(header) != DAT_HEADER_SIZE) {
                    return new ProcessingResult(false, "Invalid DAT file header: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
                }
                
                // Разбираем заголовок
                ByteBuffer buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
                buffer.position(8); // Пропускаем сигнатуру
                
                int resourceCount = buffer.getInt();
                
                // Ищем ресурс в таблице
                for (int i = 0; i < resourceCount; i++) {
                    byte[] entryHeader = new byte[8];
                    if (fis.read(entryHeader) != 8) {
                        return new ProcessingResult(false, "Invalid resource entry header: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
                    }
                    
                    ByteBuffer entryBuffer = ByteBuffer.wrap(entryHeader).order(ByteOrder.LITTLE_ENDIAN);
                    int nameLength = entryBuffer.getInt();
                    
                    // Читаем имя ресурса
                    byte[] nameBytes = new byte[nameLength];
                    if (fis.read(nameBytes) != nameLength) {
                        return new ProcessingResult(false, "Invalid resource name: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
                    }
                    
                    String currentResourceName = new String(nameBytes, StandardCharsets.UTF_8);
                    
                    // Читаем размер ресурса
                    byte[] sizeBytes = new byte[4];
                    if (fis.read(sizeBytes) != 4) {
                        return new ProcessingResult(false, "Invalid resource size: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
                    }
                    
                    int resourceSize = ByteBuffer.wrap(sizeBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    
                    // Если нашли нужный ресурс, извлекаем его
                    if (currentResourceName.equals(resourceName)) {
                        // Читаем данные ресурса
                        byte[] resourceData = new byte[resourceSize];
                        if (fis.read(resourceData) != resourceSize) {
                            return new ProcessingResult(false, "Invalid resource data: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
                        }
                        
                        // Дешифруем данные, если нужно
                        byte[] decryptedData = cryptoEngine.decrypt(resourceData, cryptoVersion);
                        
                        // Создаем родительский каталог, если он не существует
                        File parentDir = outputFile.getParentFile();
                        if (parentDir != null && !parentDir.exists()) {
                            parentDir.mkdirs();
                        }
                        
                        // Записываем данные в выходной файл
                        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                            fos.write(decryptedData);
                        }
                        
                        long endTime = System.currentTimeMillis();
                        return new ProcessingResult(true, "Resource extracted successfully", outputFile, endTime - startTime);
                    }
                    
                    // Пропускаем данные ресурса
                    fis.skip(resourceSize);
                }
                
                // Ресурс не найден
                return new ProcessingResult(false, "Resource not found: " + resourceName, null, System.currentTimeMillis() - startTime);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error extracting resource: " + resourceName, e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    @Override
    public ProcessingResult createDat(File sourceDir, File outputDat, CryptoEngine.CryptoVersion cryptoVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что исходный каталог существует и является каталогом
            if (!sourceDir.exists() || !sourceDir.isDirectory()) {
                return new ProcessingResult(false, "Source directory does not exist or is not a directory: " + sourceDir.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем родительский каталог для выходного файла, если он не существует
            File parentDir = outputDat.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }
            
            // Собираем список файлов в исходном каталоге
            List<File> files = collectFiles(sourceDir);
            if (files.isEmpty()) {
                return new ProcessingResult(false, "No files found in source directory", null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем DAT-файл
            try (FileOutputStream fos = new FileOutputStream(outputDat)) {
                // Запишем заголовок DAT-файла
                ByteBuffer headerBuffer = ByteBuffer.allocate(DAT_HEADER_SIZE).order(ByteOrder.LITTLE_ENDIAN);
                headerBuffer.put(DAT_SIGNATURE); // Сигнатура
                headerBuffer.putInt(files.size()); // Количество ресурсов
                headerBuffer.putInt(0); // Смещение таблицы ресурсов (заполним позже)
                headerBuffer.putInt(0); // Размер таблицы ресурсов (заполним позже)
                headerBuffer.putInt(0); // Смещение данных (заполним позже)
                fos.write(headerBuffer.array());
                
                // Записываем таблицу ресурсов и данные
                int tableOffset = DAT_HEADER_SIZE;
                int tableSize = 0;
                int dataOffset = 0;
                
                // Сначала запишем заголовки ресурсов
                for (File file : files) {
                    // Формируем относительный путь к файлу
                    String relativePath = getRelativePath(sourceDir, file);
                    byte[] nameBytes = relativePath.getBytes(StandardCharsets.UTF_8);
                    
                    // Читаем данные файла
                    byte[] fileData = Files.readAllBytes(file.toPath());
                    
                    // Шифруем данные, если нужно
                    byte[] encryptedData = cryptoEngine.encrypt(fileData, cryptoVersion);
                    
                    // Записываем заголовок ресурса
                    ByteBuffer entryHeaderBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
                    entryHeaderBuffer.putInt(nameBytes.length); // Длина имени ресурса
                    entryHeaderBuffer.putInt(encryptedData.length); // Размер ресурса
                    fos.write(entryHeaderBuffer.array());
                    
                    // Записываем имя ресурса
                    fos.write(nameBytes);
                    
                    tableSize += 8 + nameBytes.length;
                }
                
                dataOffset = tableOffset + tableSize;
                
                // Теперь запишем данные ресурсов
                for (File file : files) {
                    // Читаем данные файла
                    byte[] fileData = Files.readAllBytes(file.toPath());
                    
                    // Шифруем данные, если нужно
                    byte[] encryptedData = cryptoEngine.encrypt(fileData, cryptoVersion);
                    
                    // Записываем размер ресурса и данные
                    ByteBuffer sizeBuffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
                    sizeBuffer.putInt(encryptedData.length);
                    fos.write(sizeBuffer.array());
                    
                    // Записываем данные ресурса
                    fos.write(encryptedData);
                }
                
                // Обновляем заголовок DAT-файла
                fos.getChannel().position(8 + 4); // Пропускаем сигнатуру и количество ресурсов
                ByteBuffer offsetsBuffer = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN);
                offsetsBuffer.putInt(tableOffset); // Смещение таблицы ресурсов
                offsetsBuffer.putInt(tableSize); // Размер таблицы ресурсов
                offsetsBuffer.putInt(dataOffset); // Смещение данных
                fos.write(offsetsBuffer.array());
            }
            
            long endTime = System.currentTimeMillis();
            return new ProcessingResult(true, "Created DAT file with " + files.size() + " resources", outputDat, endTime - startTime);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error creating DAT file: " + outputDat.getPath(), e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    /**
     * Собирает список файлов в указанном каталоге и его подкаталогах.
     *
     * @param directory исходный каталог
     * @return список файлов
     */
    private List<File> collectFiles(File directory) {
        List<File> result = new ArrayList<>();
        collectFilesRecursive(directory, result);
        return result;
    }
    
    /**
     * Рекурсивно собирает список файлов в указанном каталоге и его подкаталогах.
     *
     * @param directory исходный каталог
     * @param result    список файлов
     */
    private void collectFilesRecursive(File directory, List<File> result) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    result.add(file);
                } else if (file.isDirectory()) {
                    collectFilesRecursive(file, result);
                }
            }
        }
    }
    
    /**
     * Возвращает относительный путь к файлу относительно указанного каталога.
     *
     * @param baseDir базовый каталог
     * @param file    файл
     * @return относительный путь
     */
    private String getRelativePath(File baseDir, File file) {
        String basePath = baseDir.getAbsolutePath();
        String filePath = file.getAbsolutePath();
        
        if (filePath.startsWith(basePath)) {
            return filePath.substring(basePath.length() + 1).replace(File.separatorChar, '/');
        } else {
            return file.getName();
        }
    }
    
    @Override
    public ProcessingResult reencryptDat(File inputDat, File outputDat, CryptoEngine.CryptoVersion sourceVersion, CryptoEngine.CryptoVersion targetVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что исходный файл существует и является DAT-файлом
            if (detectFileType(inputDat) != FileType.DAT) {
                return new ProcessingResult(false, "Input file is not a valid DAT file: " + inputDat.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем временный каталог для распаковки и перепаковки DAT-файла
            File tempDir = Files.createTempDirectory("laprizmo_reencrypt_").toFile();
            
            try {
                // Распаковываем DAT-файл во временный каталог
                ProcessingResult unpackResult = unpackDat(inputDat, tempDir, sourceVersion);
                if (!unpackResult.isSuccess()) {
                    return new ProcessingResult(false, "Failed to unpack input DAT file: " + unpackResult.getMessage(), null, System.currentTimeMillis() - startTime);
                }
                
                // Запаковываем файлы из временного каталога в новый DAT-файл
                ProcessingResult createResult = createDat(tempDir, outputDat, targetVersion);
                if (!createResult.isSuccess()) {
                    return new ProcessingResult(false, "Failed to create output DAT file: " + createResult.getMessage(), null, System.currentTimeMillis() - startTime);
                }
                
                long endTime = System.currentTimeMillis();
                return new ProcessingResult(true, "DAT file reencrypted successfully from " + sourceVersion + " to " + targetVersion, outputDat, endTime - startTime);
            } finally {
                // Удаляем временный каталог
                deleteDirectory(tempDir);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error reencrypting DAT file: " + inputDat.getPath(), e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    /**
     * Удаляет каталог и все его содержимое.
     *
     * @param directory каталог для удаления
     */
    private void deleteDirectory(File directory) {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
            directory.delete();
        }
    }
    
    @Override
    public ProcessingResult txtToDat(File txtFile, File outputDat, CryptoEngine.CryptoVersion cryptoVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что исходный файл существует и является TXT-файлом
            if (detectFileType(txtFile) != FileType.TXT) {
                return new ProcessingResult(false, "Input file is not a valid TXT file: " + txtFile.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем временный каталог для сохранения ресурсов
            File tempDir = Files.createTempDirectory("laprizmo_txt_to_dat_").toFile();
            
            try {
                // Читаем исходный TXT-файл и извлекаем ресурсы
                Map<String, String> resources = new HashMap<>();
                String fileFormat = null;
                
                try (BufferedReader reader = new BufferedReader(new FileReader(txtFile))) {
                    String line;
                    
                    // Читаем заголовок файла
                    if ((line = reader.readLine()) != null && line.matches(TXT_HEADER_PATTERN)) {
                        fileFormat = line;
                    } else {
                        return new ProcessingResult(false, "Invalid TXT file format: " + txtFile.getPath(), null, System.currentTimeMillis() - startTime);
                    }
                    
                    // Читаем ресурсы
                    while ((line = reader.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty() || line.startsWith("#")) {
                            continue; // Пропускаем пустые строки и комментарии
                        }
                        
                        Matcher matcher = RESOURCE_PATTERN.matcher(line);
                        if (matcher.matches()) {
                            String name = matcher.group(1);
                            String value = matcher.group(2);
                            resources.put(name, value);
                        } else {
                            LOGGER.warning("Invalid resource line: " + line);
                        }
                    }
                }
                
                if (resources.isEmpty()) {
                    return new ProcessingResult(false, "No resources found in TXT file: " + txtFile.getPath(), null, System.currentTimeMillis() - startTime);
                }
                
                // Создаем файлы для каждого ресурса
                for (Map.Entry<String, String> entry : resources.entrySet()) {
                    String name = entry.getKey();
                    String value = entry.getValue();
                    
                    File resourceFile = new File(tempDir, name);
                    
                    // Создаем родительский каталог, если он не существует
                    File parentDir = resourceFile.getParentFile();
                    if (parentDir != null && !parentDir.exists()) {
                        parentDir.mkdirs();
                    }
                    
                    // Записываем данные ресурса
                    try (FileWriter writer = new FileWriter(resourceFile)) {
                        writer.write(value);
                    }
                }
                
                // Создаем DAT-файл из ресурсов
                ProcessingResult createResult = createDat(tempDir, outputDat, cryptoVersion);
                if (!createResult.isSuccess()) {
                    return new ProcessingResult(false, "Failed to create DAT file: " + createResult.getMessage(), null, System.currentTimeMillis() - startTime);
                }
                
                long endTime = System.currentTimeMillis();
                return new ProcessingResult(true, "Created DAT file with " + resources.size() + " resources", outputDat, endTime - startTime);
            } finally {
                // Удаляем временный каталог
                deleteDirectory(tempDir);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error converting TXT to DAT: " + txtFile.getPath(), e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    @Override
    public ProcessingResult datToTxt(File datFile, File outputTxt, CryptoEngine.CryptoVersion cryptoVersion) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Проверяем, что исходный файл существует и является DAT-файлом
            if (detectFileType(datFile) != FileType.DAT) {
                return new ProcessingResult(false, "Input file is not a valid DAT file: " + datFile.getPath(), null, System.currentTimeMillis() - startTime);
            }
            
            // Создаем временный каталог для распаковки DAT-файла
            File tempDir = Files.createTempDirectory("laprizmo_dat_to_txt_").toFile();
            
            try {
                // Распаковываем DAT-файл во временный каталог
                ProcessingResult unpackResult = unpackDat(datFile, tempDir, cryptoVersion);
                if (!unpackResult.isSuccess()) {
                    return new ProcessingResult(false, "Failed to unpack DAT file: " + unpackResult.getMessage(), null, System.currentTimeMillis() - startTime);
                }
                
                // Создаем TXT-файл
                try (FileWriter writer = new FileWriter(outputTxt)) {
                    // Записываем заголовок TXT-файла
                    writer.write("Lineage 2 file format 1.0\n");
                    
                    // Добавляем комментарий
                    writer.write("# Converted from " + datFile.getName() + " by LaPrizmo\n");
                    writer.write("# Date: " + new Date() + "\n\n");
                    
                    // Собираем список ресурсов
                    List<File> files = collectFiles(tempDir);
                    
                    // Записываем ресурсы
                    for (File file : files) {
                        String relativePath = getRelativePath(tempDir, file);
                        String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                        
                        writer.write(relativePath + " = " + content + "\n");
                    }
                }
                
                long endTime = System.currentTimeMillis();
                return new ProcessingResult(true, "DAT file converted to TXT successfully", outputTxt, endTime - startTime);
            } finally {
                // Удаляем временный каталог
                deleteDirectory(tempDir);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error converting DAT to TXT: " + datFile.getPath(), e);
            return new ProcessingResult(false, "Error: " + e.getMessage(), null, System.currentTimeMillis() - startTime);
        }
    }
    
    @Override
    public int batchTxtToDat(File sourceDir, File outputDir, CryptoEngine.CryptoVersion cryptoVersion) {
        // Проверяем, что исходный каталог существует и является каталогом
        if (!sourceDir.exists() || !sourceDir.isDirectory()) {
            LOGGER.severe("Source directory does not exist or is not a directory: " + sourceDir.getPath());
            return 0;
        }
        
        // Создаем выходной каталог, если он не существует
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        
        // Собираем список TXT-файлов в исходном каталоге
        File[] txtFiles = sourceDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
        if (txtFiles == null || txtFiles.length == 0) {
            LOGGER.warning("No TXT files found in source directory: " + sourceDir.getPath());
            return 0;
        }
        
        int successCount = 0;
        
        // Обрабатываем каждый TXT-файл
        for (File txtFile : txtFiles) {
            try {
                // Определяем имя выходного DAT-файла
                String datFileName = txtFile.getName().substring(0, txtFile.getName().length() - 4) + ".dat";
                File outputDat = new File(outputDir, datFileName);
                
                // Конвертируем TXT-файл в DAT-файл
                ProcessingResult result = txtToDat(txtFile, outputDat, cryptoVersion);
                if (result.isSuccess()) {
                    successCount++;
                    LOGGER.info("Converted " + txtFile.getName() + " to " + datFileName);
                } else {
                    LOGGER.warning("Failed to convert " + txtFile.getName() + ": " + result.getMessage());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error processing TXT file: " + txtFile.getName(), e);
            }
        }
        
        return successCount;
    }
    
    @Override
    public int batchDatToTxt(File sourceDir, File outputDir, CryptoEngine.CryptoVersion cryptoVersion) {
        // Проверяем, что исходный каталог существует и является каталогом
        if (!sourceDir.exists() || !sourceDir.isDirectory()) {
            LOGGER.severe("Source directory does not exist or is not a directory: " + sourceDir.getPath());
            return 0;
        }
        
        // Создаем выходной каталог, если он не существует
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        
        // Собираем список DAT-файлов в исходном каталоге
        File[] datFiles = sourceDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".dat"));
        if (datFiles == null || datFiles.length == 0) {
            LOGGER.warning("No DAT files found in source directory: " + sourceDir.getPath());
            return 0;
        }
        
        int successCount = 0;
        
        // Обрабатываем каждый DAT-файл
        for (File datFile : datFiles) {
            try {
                // Определяем имя выходного TXT-файла
                String txtFileName = datFile.getName().substring(0, datFile.getName().length() - 4) + ".txt";
                File outputTxt = new File(outputDir, txtFileName);
                
                // Конвертируем DAT-файл в TXT-файл
                ProcessingResult result = datToTxt(datFile, outputTxt, cryptoVersion);
                if (result.isSuccess()) {
                    successCount++;
                    LOGGER.info("Converted " + datFile.getName() + " to " + txtFileName);
                } else {
                    LOGGER.warning("Failed to convert " + datFile.getName() + ": " + result.getMessage());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error processing DAT file: " + datFile.getName(), e);
            }
        }
        
        return successCount;
    }
    
    @Override
    public int batchReencrypt(File sourceDir, File outputDir, CryptoEngine.CryptoVersion sourceVersion, CryptoEngine.CryptoVersion targetVersion) {
        // Проверяем, что исходный каталог существует и является каталогом
        if (!sourceDir.exists() || !sourceDir.isDirectory()) {
            LOGGER.severe("Source directory does not exist or is not a directory: " + sourceDir.getPath());
            return 0;
        }
        
        // Создаем выходной каталог, если он не существует
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        
        // Собираем список DAT-файлов в исходном каталоге
        File[] datFiles = sourceDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".dat"));
        if (datFiles == null || datFiles.length == 0) {
            LOGGER.warning("No DAT files found in source directory: " + sourceDir.getPath());
            return 0;
        }
        
        int successCount = 0;
        
        // Обрабатываем каждый DAT-файл
        for (File datFile : datFiles) {
            try {
                // Определяем имя выходного DAT-файла
                File outputDat = new File(outputDir, datFile.getName());
                
                // Перешифровываем DAT-файл
                ProcessingResult result = reencryptDat(datFile, outputDat, sourceVersion, targetVersion);
                if (result.isSuccess()) {
                    successCount++;
                    LOGGER.info("Reencrypted " + datFile.getName() + " from " + sourceVersion + " to " + targetVersion);
                } else {
                    LOGGER.warning("Failed to reencrypt " + datFile.getName() + ": " + result.getMessage());
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error processing DAT file: " + datFile.getName(), e);
            }
        }
        
        return successCount;
    }
}
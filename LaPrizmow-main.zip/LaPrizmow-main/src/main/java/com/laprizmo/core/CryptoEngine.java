/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.aes.L2Ver51x;
import com.laprizmo.crypto.blowfish.L2Ver21x;
import com.laprizmo.crypto.lamecrypt.L2Ver111;
import com.laprizmo.crypto.lamecrypt.L2Ver120;
import com.laprizmo.crypto.rsa.L2Ver41x;

import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Основной движок шифрования, обеспечивающий доступ к различным алгоритмам шифрования Lineage 2.
 * Поддерживает все версии протоколов от 1.1.1 до 5.1.x и выше.
 */
public class CryptoEngine {
    
    private static final Logger LOGGER = Logger.getLogger(CryptoEngine.class.getName());
    
    /**
     * Версии шифрования Lineage 2
     */
    public enum CryptoVersion {
        /**
         * Версия 1.1.1 - простое XOR-шифрование со статическим ключом
         */
        L2VER111("L2Ver111", "XOR encryption with static key (v1.1.1)"),
        
        /**
         * Версия 1.2.0 - XOR-шифрование с динамическим ключом
         */
        L2VER120("L2Ver120", "XOR encryption with dynamic key (v1.2.0)"),
        
        /**
         * Версия 2.1.x - Blowfish шифрование
         */
        L2VER21X("L2Ver21x", "Blowfish encryption (v2.1.x)"),
        
        /**
         * Версия 4.1.x - RSA шифрование
         */
        L2VER41X("L2Ver41x", "RSA encryption (v4.1.x)"),
        
        /**
         * Версия 5.1.x - AES шифрование
         */
        L2VER51X("L2Ver51x", "AES encryption (v5.1.x)"),
        
        /**
         * Версия 7.1.0 - Улучшенное AES шифрование
         */
        L2VER71X("L2Ver71x", "Enhanced AES encryption (v7.1.x)"),
        
        /**
         * Версия 9.1.2 - Последнее поколение AES шифрования
         */
        L2VER912("L2Ver912", "Next-gen AES encryption (v9.1.2)");
        
        private final String code;
        private final String description;
        
        CryptoVersion(String code, String description) {
            this.code = code;
            this.description = description;
        }
        
        public String getCode() {
            return code;
        }
        
        public String getDescription() {
            return description;
        }
        
        @Override
        public String toString() {
            return code + " - " + description;
        }
    }
    
    // Реестр реализаций криптографических алгоритмов
    private final Map<CryptoVersion, Object> cryptoImplementations = new HashMap<>();
    
    // Текущая выбранная версия
    private CryptoVersion currentVersion = CryptoVersion.L2VER51X;
    
    // Метрики шифрования
    private final CryptoMetrics metrics;
    
    /**
     * Создает новый движок шифрования.
     *
     * @param metrics метрики шифрования
     */
    public CryptoEngine(CryptoMetrics metrics) {
        this.metrics = metrics;
        initImplementations();
    }
    
    /**
     * Инициализирует реализации криптографических алгоритмов.
     */
    private void initImplementations() {
        // Регистрируем реализации криптографических алгоритмов
        cryptoImplementations.put(CryptoVersion.L2VER111, new L2Ver111());
        cryptoImplementations.put(CryptoVersion.L2VER120, new L2Ver120());
        cryptoImplementations.put(CryptoVersion.L2VER21X, new L2Ver21x());
        cryptoImplementations.put(CryptoVersion.L2VER41X, new L2Ver41x());
        cryptoImplementations.put(CryptoVersion.L2VER51X, new L2Ver51x());
        
        // Для более новых версий используем AES с усиленными ключами
        // Примечание: в реальной реализации здесь должны быть настоящие классы
        cryptoImplementations.put(CryptoVersion.L2VER71X, new L2Ver51x());
        cryptoImplementations.put(CryptoVersion.L2VER912, new L2Ver51x());
    }
    
    /**
     * Устанавливает текущую версию шифрования.
     *
     * @param version версия шифрования
     */
    public void setCurrentVersion(CryptoVersion version) {
        if (!cryptoImplementations.containsKey(version)) {
            throw new IllegalArgumentException("Unsupported crypto version: " + version);
        }
        
        this.currentVersion = version;
        LOGGER.info("Switched to crypto version: " + version);
    }
    
    /**
     * Возвращает текущую версию шифрования.
     *
     * @return текущая версия шифрования
     */
    public CryptoVersion getCurrentVersion() {
        return currentVersion;
    }
    
    /**
     * Возвращает реализацию криптографического алгоритма для указанной версии.
     *
     * @param version версия шифрования
     * @return реализация криптографического алгоритма
     */
    public Object getCryptoImplementation(CryptoVersion version) {
        Object implementation = cryptoImplementations.get(version);
        if (implementation == null) {
            throw new IllegalArgumentException("Unsupported crypto version: " + version);
        }
        return implementation;
    }
    
    /**
     * Возвращает реализацию текущего криптографического алгоритма.
     *
     * @return реализация криптографического алгоритма
     */
    public Object getCurrentCryptoImplementation() {
        return getCryptoImplementation(currentVersion);
    }
    
    /**
     * Шифрует массив байт с использованием текущего алгоритма.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data) throws CryptoException {
        return encrypt(data, currentVersion);
    }
    
    /**
     * Шифрует массив байт с использованием указанного алгоритма.
     *
     * @param data    данные для шифрования
     * @param version версия шифрования
     * @return зашифрованные данные
     * @throws CryptoException если возникла ошибка при шифровании
     */
    public byte[] encrypt(byte[] data, CryptoVersion version) throws CryptoException {
        long startTime = System.nanoTime();
        
        try {
            Object implementation = getCryptoImplementation(version);
            byte[] result;
            
            switch (version) {
                case L2VER111:
                    result = ((L2Ver111) implementation).encrypt(data);
                    break;
                case L2VER120:
                    result = ((L2Ver120) implementation).encrypt(data);
                    break;
                case L2VER21X:
                    result = ((L2Ver21x) implementation).encrypt(data);
                    break;
                case L2VER41X:
                    result = ((L2Ver41x) implementation).encrypt(data);
                    break;
                case L2VER51X:
                case L2VER71X:
                case L2VER912:
                    result = ((L2Ver51x) implementation).encrypt(data);
                    break;
                default:
                    throw new CryptoException("Unsupported crypto version: " + version);
            }
            
            // Обновляем метрики
            long endTime = System.nanoTime();
            metrics.recordEncryption(version, data.length, endTime - startTime);
            
            return result;
        } catch (Exception e) {
            throw new CryptoException("Error encrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Дешифрует массив байт с использованием текущего алгоритма.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    public byte[] decrypt(byte[] data) throws CryptoException {
        return decrypt(data, currentVersion);
    }
    
    /**
     * Дешифрует массив байт с использованием указанного алгоритма.
     *
     * @param data    данные для дешифрования
     * @param version версия шифрования
     * @return дешифрованные данные
     * @throws CryptoException если возникла ошибка при дешифровании
     */
    public byte[] decrypt(byte[] data, CryptoVersion version) throws CryptoException {
        long startTime = System.nanoTime();
        
        try {
            Object implementation = getCryptoImplementation(version);
            byte[] result;
            
            switch (version) {
                case L2VER111:
                    result = ((L2Ver111) implementation).decrypt(data);
                    break;
                case L2VER120:
                    result = ((L2Ver120) implementation).decrypt(data);
                    break;
                case L2VER21X:
                    result = ((L2Ver21x) implementation).decrypt(data);
                    break;
                case L2VER41X:
                    result = ((L2Ver41x) implementation).decrypt(data);
                    break;
                case L2VER51X:
                case L2VER71X:
                case L2VER912:
                    result = ((L2Ver51x) implementation).decrypt(data);
                    break;
                default:
                    throw new CryptoException("Unsupported crypto version: " + version);
            }
            
            // Обновляем метрики
            long endTime = System.nanoTime();
            metrics.recordDecryption(version, data.length, endTime - startTime);
            
            return result;
        } catch (Exception e) {
            throw new CryptoException("Error decrypting data: " + e.getMessage(), e);
        }
    }
    
    /**
     * Создает входной поток для дешифрования с использованием текущего алгоритма.
     *
     * @param in входной поток с зашифрованными данными
     * @return входной поток для чтения дешифрованных данных
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public InputStream getDecryptionInputStream(InputStream in) throws CryptoException {
        return getDecryptionInputStream(in, currentVersion);
    }
    
    /**
     * Создает входной поток для дешифрования с использованием указанного алгоритма.
     *
     * @param in      входной поток с зашифрованными данными
     * @param version версия шифрования
     * @return входной поток для чтения дешифрованных данных
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public InputStream getDecryptionInputStream(InputStream in, CryptoVersion version) throws CryptoException {
        try {
            Object implementation = getCryptoImplementation(version);
            
            switch (version) {
                case L2VER111:
                    return ((L2Ver111) implementation).getDecryptionInputStream(in);
                case L2VER120:
                    return ((L2Ver120) implementation).getDecryptionInputStream(in);
                case L2VER21X:
                    return ((L2Ver21x) implementation).getDecryptionInputStream(in);
                case L2VER41X:
                    return ((L2Ver41x) implementation).getDecryptionInputStream(in);
                case L2VER51X:
                case L2VER71X:
                case L2VER912:
                    return ((L2Ver51x) implementation).getDecryptionInputStream(in);
                default:
                    throw new CryptoException("Unsupported crypto version: " + version);
            }
        } catch (Exception e) {
            throw new CryptoException("Error creating decryption input stream: " + e.getMessage(), e);
        }
    }
    
    /**
     * Создает выходной поток для шифрования с использованием текущего алгоритма.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public OutputStream getEncryptionOutputStream(OutputStream out) throws CryptoException {
        return getEncryptionOutputStream(out, currentVersion);
    }
    
    /**
     * Создает выходной поток для шифрования с использованием указанного алгоритма.
     *
     * @param out     выходной поток для записи зашифрованных данных
     * @param version версия шифрования
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     * @throws CryptoException если возникла ошибка при создании потока
     */
    public OutputStream getEncryptionOutputStream(OutputStream out, CryptoVersion version) throws CryptoException {
        try {
            Object implementation = getCryptoImplementation(version);
            
            switch (version) {
                case L2VER111:
                    return ((L2Ver111) implementation).getEncryptionOutputStream(out);
                case L2VER120:
                    return ((L2Ver120) implementation).getEncryptionOutputStream(out);
                case L2VER21X:
                    return ((L2Ver21x) implementation).getEncryptionOutputStream(out);
                case L2VER41X:
                    return ((L2Ver41x) implementation).getEncryptionOutputStream(out);
                case L2VER51X:
                case L2VER71X:
                case L2VER912:
                    return ((L2Ver51x) implementation).getEncryptionOutputStream(out);
                default:
                    throw new CryptoException("Unsupported crypto version: " + version);
            }
        } catch (Exception e) {
            throw new CryptoException("Error creating encryption output stream: " + e.getMessage(), e);
        }
    }
    
    /**
     * Возвращает метрики шифрования.
     *
     * @return метрики шифрования
     */
    public CryptoMetrics getMetrics() {
        return metrics;
    }
}
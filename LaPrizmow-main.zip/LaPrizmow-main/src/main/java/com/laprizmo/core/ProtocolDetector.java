/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.CRC32;

/**
 * Детектор протокола и формата файлов.
 * Автоматически определяет версию и тип шифрования файла.
 */
public class ProtocolDetector {
    
    private static final Logger LOGGER = Logger.getLogger(ProtocolDetector.class.getName());
    
    // Сигнатура файла XOR версии 120
    private static final int XOR_120_SIGNATURE = 0x414C1C;
    
    // Сигнатура файла Blowfish версии 21x
    private static final int BLOWFISH_21X_SIGNATURE = 0x414C1B;
    
    // Сигнатура файла Blowfish версии 212
    private static final int BLOWFISH_212_SIGNATURE = 0x414C2B;
    
    // Сигнатура файла RSA версии 41x
    private static final int RSA_41X_SIGNATURE = 0x414C14;
    
    // Сигнатура файла AES версии 51x
    private static final int AES_51X_SIGNATURE = 0x414C15;
    
    // Байты сигнатуры lamecrypt версии 111
    private static final byte[] LAMECRYPT_111_SIGNATURE = new byte[] {
        (byte) 0x46, (byte) 0x4F, (byte) 0x52, (byte) 0x4D, // "FORM"
        (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, // длина (переменная)
        (byte) 0x49, (byte) 0x4C, (byte) 0x32, (byte) 0x55  // "IL2U"
    };
    
    // Байты сигнатуры XOR версии 111
    private static final byte[] XOR_111_SIGNATURE = new byte[] {
        (byte) 0x00, (byte) 0x00, (byte) 0x01, (byte) 0x00
    };
    
    // Байты сигнатуры XOR версии 121
    private static final byte[] XOR_121_SIGNATURE = new byte[] {
        (byte) 0x64, (byte) 0x00, (byte) 0x00, (byte) 0x00, 
        (byte) 0x44, (byte) 0x5F, (byte) 0x44, (byte) 0x45
    };
    
    /**
     * Информация о протоколе файла.
     */
    public static class ProtocolInfo {
        // Версия протокола
        private final int protocolVersion;
        
        // Тип криптографии
        private final CryptoOperations.CryptoType cryptoType;
        
        // Флаг сжатия
        private final boolean compressed;
        
        // Дополнительные параметры
        private final Map<String, Object> params;
        
        /**
         * Создает информацию о протоколе.
         *
         * @param protocolVersion версия протокола
         * @param cryptoType тип криптографии
         */
        public ProtocolInfo(int protocolVersion, CryptoOperations.CryptoType cryptoType) {
            this(protocolVersion, cryptoType, false);
        }
        
        /**
         * Создает информацию о протоколе.
         *
         * @param protocolVersion версия протокола
         * @param cryptoType тип криптографии
         * @param compressed флаг сжатия
         */
        public ProtocolInfo(int protocolVersion, CryptoOperations.CryptoType cryptoType, boolean compressed) {
            this.protocolVersion = protocolVersion;
            this.cryptoType = cryptoType;
            this.compressed = compressed;
            this.params = new HashMap<>();
        }
        
        /**
         * Возвращает версию протокола.
         *
         * @return версия протокола
         */
        public int getProtocolVersion() {
            return protocolVersion;
        }
        
        /**
         * Возвращает тип криптографии.
         *
         * @return тип криптографии
         */
        public CryptoOperations.CryptoType getCryptoType() {
            return cryptoType;
        }
        
        /**
         * Проверяет, сжат ли файл.
         *
         * @return true, если файл сжат
         */
        public boolean isCompressed() {
            return compressed;
        }
        
        /**
         * Устанавливает дополнительный параметр.
         *
         * @param key ключ параметра
         * @param value значение параметра
         */
        public void setParam(String key, Object value) {
            params.put(key, value);
        }
        
        /**
         * Возвращает дополнительный параметр.
         *
         * @param key ключ параметра
         * @return значение параметра или null, если параметр не найден
         */
        public Object getParam(String key) {
            return params.get(key);
        }
        
        /**
         * Возвращает дополнительный параметр как строку.
         *
         * @param key ключ параметра
         * @return значение параметра или null, если параметр не найден
         */
        public String getStringParam(String key) {
            Object value = params.get(key);
            return value != null ? value.toString() : null;
        }
        
        /**
         * Возвращает дополнительный параметр как целое число.
         *
         * @param key ключ параметра
         * @param defaultValue значение по умолчанию
         * @return значение параметра или значение по умолчанию, если параметр не найден
         */
        public int getIntParam(String key, int defaultValue) {
            Object value = params.get(key);
            if (value instanceof Number) {
                return ((Number) value).intValue();
            } else if (value instanceof String) {
                try {
                    return Integer.parseInt((String) value);
                } catch (NumberFormatException e) {
                    return defaultValue;
                }
            }
            return defaultValue;
        }
        
        /**
         * Возвращает дополнительный параметр как логическое значение.
         *
         * @param key ключ параметра
         * @param defaultValue значение по умолчанию
         * @return значение параметра или значение по умолчанию, если параметр не найден
         */
        public boolean getBooleanParam(String key, boolean defaultValue) {
            Object value = params.get(key);
            if (value instanceof Boolean) {
                return (Boolean) value;
            } else if (value instanceof String) {
                return Boolean.parseBoolean((String) value);
            }
            return defaultValue;
        }
        
        /**
         * Возвращает все дополнительные параметры.
         *
         * @return карта с параметрами
         */
        public Map<String, Object> getParams() {
            return new HashMap<>(params);
        }
        
        @Override
        public String toString() {
            return "ProtocolInfo{" +
                    "protocolVersion=" + protocolVersion +
                    ", cryptoType=" + cryptoType +
                    ", compressed=" + compressed +
                    ", params=" + params +
                    '}';
        }
    }
    
    /**
     * Определяет протокол файла.
     *
     * @param filename имя файла
     * @return информация о протоколе или null, если протокол не удалось определить
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static ProtocolInfo detectProtocol(String filename) throws IOException {
        File file = new File(filename);
        if (!file.exists() || !file.isFile() || !file.canRead()) {
            throw new IOException("Can't read file: " + filename);
        }
        
        try (FileInputStream fis = new FileInputStream(file)) {
            // Читаем до 32 КБ для анализа
            int headerSize = Math.min((int)file.length(), 32 * 1024);
            byte[] header = new byte[headerSize];
            int bytesRead = fis.read(header);
            
            if (bytesRead < 12) {
                throw new IOException("File is too small: " + filename);
            }
            
            // Проверяем сигнатуру XOR 120
            if (bytesRead >= 4 && matchSignature(header, 0, XOR_120_SIGNATURE)) {
                LOGGER.fine("Detected XOR 120 protocol");
                return createXor120Info(header);
            }
            
            // Проверяем сигнатуру Blowfish 21x
            if (bytesRead >= 4 && matchSignature(header, 0, BLOWFISH_21X_SIGNATURE)) {
                LOGGER.fine("Detected Blowfish 21x protocol");
                return createBlowfish21xInfo(header);
            }
            
            // Проверяем сигнатуру Blowfish 212
            if (bytesRead >= 4 && matchSignature(header, 0, BLOWFISH_212_SIGNATURE)) {
                LOGGER.fine("Detected Blowfish 212 protocol");
                return createBlowfish212Info(header);
            }
            
            // Проверяем сигнатуру RSA 41x
            if (bytesRead >= 4 && matchSignature(header, 0, RSA_41X_SIGNATURE)) {
                LOGGER.fine("Detected RSA 41x protocol");
                return createRsa41xInfo(header);
            }
            
            // Проверяем сигнатуру AES 51x
            if (bytesRead >= 4 && matchSignature(header, 0, AES_51X_SIGNATURE)) {
                LOGGER.fine("Detected AES 51x protocol");
                return createAes51xInfo(header);
            }
            
            // Проверяем сигнатуру Lamecrypt 111
            if (bytesRead >= 12 && matchBytes(header, 0, LAMECRYPT_111_SIGNATURE, 0, 4) &&
                matchBytes(header, 8, LAMECRYPT_111_SIGNATURE, 8, 4)) {
                LOGGER.fine("Detected Lamecrypt 111 protocol (L2 Interface)");
                return new ProtocolInfo(111, CryptoOperations.CryptoType.LAMECRYPT);
            }
            
            // Проверяем сигнатуру XOR 111
            if (bytesRead >= 4 && matchBytes(header, 0, XOR_111_SIGNATURE, 0, 4)) {
                LOGGER.fine("Detected XOR 111 protocol");
                return new ProtocolInfo(111, CryptoOperations.CryptoType.XOR);
            }
            
            // Проверяем сигнатуру XOR 121
            if (bytesRead >= 8 && matchBytes(header, 0, XOR_121_SIGNATURE, 0, 8)) {
                LOGGER.fine("Detected XOR 121 protocol");
                ProtocolInfo info = new ProtocolInfo(121, CryptoOperations.CryptoType.XOR);
                
                // Получаем имя файла для ключа XOR 121
                String baseName = file.getName();
                if (baseName.toLowerCase().startsWith("enc-") || baseName.toLowerCase().startsWith("dec-")) {
                    baseName = baseName.substring(4);
                }
                info.setParam("filename", baseName);
                
                return info;
            }
            
            // Проверяем контрольную сумму в конце файла (tail check)
            ProtocolInfo tailCheckInfo = detectByTailCheck(file);
            if (tailCheckInfo != null) {
                return tailCheckInfo;
            }
            
            // Если не удалось определить протокол, пробуем по расширению или имени файла
            ProtocolInfo filenameInfo = detectByFilename(file.getName());
            if (filenameInfo != null) {
                return filenameInfo;
            }
            
            // Пытаемся определить по содержимому
            ProtocolInfo contentInfo = detectByContent(header);
            if (contentInfo != null) {
                return contentInfo;
            }
            
            LOGGER.warning("Could not determine protocol for file: " + filename);
            return null;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error detecting protocol: " + e.getMessage(), e);
            throw new IOException("Error detecting protocol: " + e.getMessage(), e);
        }
    }
    
    /**
     * Определяет протокол по хвосту файла (контрольной сумме).
     *
     * @param file файл для проверки
     * @return информация о протоколе или null, если протокол не удалось определить
     */
    private static ProtocolInfo detectByTailCheck(File file) {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            long fileSize = raf.length();
            
            // Файл слишком маленький для проверки хвоста
            if (fileSize < 8) {
                return null;
            }
            
            // Читаем хвост файла
            raf.seek(fileSize - 8);
            byte[] tail = new byte[8];
            raf.read(tail);
            
            // Получаем контрольную сумму из хвоста
            ByteBuffer buffer = ByteBuffer.wrap(tail);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            int tailSize = buffer.getInt();
            int checksum = buffer.getInt();
            
            // Проверяем допустимость размера хвоста
            if (tailSize <= 0 || tailSize >= fileSize) {
                return null;
            }
            
            // Читаем данные для проверки контрольной суммы
            raf.seek(fileSize - tailSize - 8);
            byte[] data = new byte[tailSize];
            raf.read(data);
            
            // Вычисляем контрольную сумму
            CRC32 crc = new CRC32();
            crc.update(data);
            int calculatedChecksum = (int) crc.getValue();
            
            // Если контрольные суммы совпадают, это, вероятно, файл с одним из известных протоколов
            if (checksum == calculatedChecksum) {
                // Проверяем первые байты для определения типа
                raf.seek(0);
                byte[] header = new byte[4];
                raf.read(header);
                
                if (matchSignature(header, 0, XOR_120_SIGNATURE)) {
                    return createXor120Info(header);
                } else if (matchSignature(header, 0, BLOWFISH_21X_SIGNATURE)) {
                    return createBlowfish21xInfo(header);
                } else if (matchSignature(header, 0, BLOWFISH_212_SIGNATURE)) {
                    return createBlowfish212Info(header);
                } else if (matchSignature(header, 0, RSA_41X_SIGNATURE)) {
                    return createRsa41xInfo(header);
                } else if (matchSignature(header, 0, AES_51X_SIGNATURE)) {
                    return createAes51xInfo(header);
                }
                
                // Если тип не определен, но контрольная сумма верна, предполагаем XOR 120
                return createXor120Info(header);
            }
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Error checking file tail: " + e.getMessage(), e);
        }
        
        return null;
    }
    
    /**
     * Определяет протокол по имени файла.
     *
     * @param filename имя файла
     * @return информация о протоколе или null, если протокол не удалось определить
     */
    private static ProtocolInfo detectByFilename(String filename) {
        filename = filename.toLowerCase();
        
        // Проверяем префиксы файлов
        if (filename.startsWith("enc-")) {
            // Зашифрованные файлы (AES)
            return new ProtocolInfo(516, CryptoOperations.CryptoType.AES);
        } else if (filename.startsWith("dec-")) {
            // Расшифрованные файлы (XOR)
            return new ProtocolInfo(120, CryptoOperations.CryptoType.XOR);
        }
        
        // Проверяем расширение файла
        if (filename.endsWith(".dat") || filename.endsWith(".dat_")) {
            // Старые файлы данных (XOR)
            return new ProtocolInfo(111, CryptoOperations.CryptoType.XOR);
        } else if (filename.endsWith(".unx")) {
            // Файлы данных Interlude (XOR)
            return new ProtocolInfo(120, CryptoOperations.CryptoType.XOR);
        } else if (filename.endsWith(".enx")) {
            // Зашифрованные файлы Interlude (AES)
            return new ProtocolInfo(516, CryptoOperations.CryptoType.AES);
        } else if (filename.endsWith(".zip") || filename.endsWith(".jar")) {
            // Архивы (без шифрования)
            return null;
        } else if (filename.equals("ssq.dat")) {
            // Файл серверной стороны (XOR)
            return new ProtocolInfo(111, CryptoOperations.CryptoType.XOR);
        }
        
        return null;
    }
    
    /**
     * Определяет протокол по содержимому файла.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе или null, если протокол не удалось определить
     */
    private static ProtocolInfo detectByContent(byte[] header) {
        // Здесь могут быть дополнительные эвристики для определения протокола
        return null;
    }
    
    /**
     * Создает информацию о протоколе XOR 120.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе
     */
    private static ProtocolInfo createXor120Info(byte[] header) {
        boolean compressed = false;
        
        // Проверяем флаг сжатия в заголовке
        if (header.length >= 7 && header[4] == 0x01) {
            compressed = true;
        }
        
        return new ProtocolInfo(120, CryptoOperations.CryptoType.XOR, compressed);
    }
    
    /**
     * Создает информацию о протоколе Blowfish 21x.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе
     */
    private static ProtocolInfo createBlowfish21xInfo(byte[] header) {
        boolean compressed = false;
        int version = 211;
        
        // Проверяем флаг сжатия в заголовке
        if (header.length >= 7) {
            if (header[4] == 0x01) {
                compressed = true;
            }
            
            // Определяем точную версию
            if (header.length >= 8) {
                version = header[7] & 0xFF;
                if (version < 210 || version > 219) {
                    version = 211; // По умолчанию
                }
            }
        }
        
        ProtocolInfo info = new ProtocolInfo(version, CryptoOperations.CryptoType.BLOWFISH, compressed);
        info.setParam("subversion", version);
        return info;
    }
    
    /**
     * Создает информацию о протоколе Blowfish 212.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе
     */
    private static ProtocolInfo createBlowfish212Info(byte[] header) {
        boolean compressed = false;
        
        // Проверяем флаг сжатия в заголовке
        if (header.length >= 7 && header[4] == 0x01) {
            compressed = true;
        }
        
        return new ProtocolInfo(212, CryptoOperations.CryptoType.BLOWFISH, compressed);
    }
    
    /**
     * Создает информацию о протоколе RSA 41x.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе
     */
    private static ProtocolInfo createRsa41xInfo(byte[] header) {
        boolean compressed = false;
        int version = 413;
        
        // Проверяем флаг сжатия в заголовке
        if (header.length >= 7) {
            if (header[4] == 0x01) {
                compressed = true;
            }
            
            // Определяем точную версию
            if (header.length >= 8) {
                version = header[7] & 0xFF;
                if (version == 0) {
                    version = 413; // По умолчанию для Gracia Final
                } else if (version == 1) {
                    version = 414; // Gracia Epilogue
                } else if (version == 2) {
                    version = 415; // Gracia Final Update
                } else if (version == 3) {
                    version = 416; // Freya
                } else {
                    version = 413; // По умолчанию
                }
            }
        }
        
        ProtocolInfo info = new ProtocolInfo(version, CryptoOperations.CryptoType.RSA, compressed);
        info.setParam("subversion", version);
        return info;
    }
    
    /**
     * Создает информацию о протоколе AES 51x.
     *
     * @param header начало файла для анализа
     * @return информация о протоколе
     */
    private static ProtocolInfo createAes51xInfo(byte[] header) {
        boolean compressed = false;
        int version = 516;
        
        // Проверяем флаг сжатия в заголовке
        if (header.length >= 7) {
            if (header[4] == 0x01) {
                compressed = true;
            }
            
            // Определяем точную версию
            if (header.length >= 8) {
                version = header[7] & 0xFF;
                if (version == 0) {
                    version = 516; // По умолчанию для Hellbound
                } else if (version == 1) {
                    version = 517; // GoD
                } else if (version == 2) {
                    version = 530; // Harmony
                } else if (version == 3) {
                    version = 531; // Tauti
                } else if (version == 4) {
                    version = 532; // Glory Days
                } else if (version == 5) {
                    version = 534; // Infinite Odyssey
                } else if (version == 6) {
                    version = 559; // Helios
                } else if (version == 7) {
                    version = 578; // Eternal
                } else if (version == 8) {
                    version = 581; // Prelude of War
                } else if (version == 9) {
                    version = 600; // Fafurion
                } else if (version > 9) {
                    version = 600 + version - 9; // Более новые версии
                } else {
                    version = 516; // По умолчанию
                }
            }
        }
        
        ProtocolInfo info = new ProtocolInfo(version, CryptoOperations.CryptoType.AES, compressed);
        info.setParam("subversion", version);
        return info;
    }
    
    /**
     * Проверяет, совпадает ли сигнатура.
     *
     * @param data массив байтов для проверки
     * @param offset смещение в массиве
     * @param signature сигнатура для сравнения
     * @return true, если сигнатура совпадает
     */
    private static boolean matchSignature(byte[] data, int offset, int signature) {
        if (data.length < offset + 3) {
            return false;
        }
        
        int value = ((data[offset] & 0xFF) << 16) | 
                    ((data[offset + 1] & 0xFF) << 8) | 
                    (data[offset + 2] & 0xFF);
        
        return value == signature;
    }
    
    /**
     * Проверяет, совпадают ли байты.
     *
     * @param data1 первый массив байтов
     * @param offset1 смещение в первом массиве
     * @param data2 второй массив байтов
     * @param offset2 смещение во втором массиве
     * @param length количество байтов для сравнения
     * @return true, если байты совпадают
     */
    private static boolean matchBytes(byte[] data1, int offset1, byte[] data2, int offset2, int length) {
        if (data1.length < offset1 + length || data2.length < offset2 + length) {
            return false;
        }
        
        for (int i = 0; i < length; i++) {
            if (data1[offset1 + i] != data2[offset2 + i]) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Возвращает информацию о файле.
     *
     * @param filename имя файла
     * @return информация о файле в текстовом виде
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static String getFileInfo(String filename) throws IOException {
        File file = new File(filename);
        if (!file.exists() || !file.isFile()) {
            throw new IOException("File not found: " + filename);
        }
        
        StringBuilder info = new StringBuilder();
        info.append("File: ").append(file.getName()).append("\n");
        info.append("Size: ").append(file.length()).append(" bytes\n");
        
        try {
            ProtocolInfo protocol = detectProtocol(filename);
            if (protocol != null) {
                info.append("Protocol: ").append(protocol.getProtocolVersion()).append("\n");
                info.append("Crypto: ").append(protocol.getCryptoType()).append("\n");
                info.append("Compressed: ").append(protocol.isCompressed()).append("\n");
                
                // Добавляем дополнительные параметры
                Map<String, Object> params = protocol.getParams();
                if (!params.isEmpty()) {
                    info.append("Additional parameters:\n");
                    for (Map.Entry<String, Object> entry : params.entrySet()) {
                        info.append("  ").append(entry.getKey()).append(": ")
                            .append(entry.getValue()).append("\n");
                    }
                }
            } else {
                info.append("Protocol: Unknown (may be unencrypted or unsupported format)\n");
            }
        } catch (Exception e) {
            info.append("Error detecting protocol: ").append(e.getMessage()).append("\n");
        }
        
        // Добавляем hex dump первых 128 байтов файла
        try (FileInputStream fis = new FileInputStream(file)) {
            int headerSize = Math.min((int)file.length(), 128);
            byte[] header = new byte[headerSize];
            int bytesRead = fis.read(header);
            
            info.append("\nHex dump (first ").append(bytesRead).append(" bytes):\n");
            for (int i = 0; i < bytesRead; i += 16) {
                info.append(String.format("%04X: ", i));
                
                for (int j = 0; j < 16; j++) {
                    if (i + j < bytesRead) {
                        info.append(String.format("%02X ", header[i + j]));
                    } else {
                        info.append("   ");
                    }
                }
                
                info.append(" | ");
                
                for (int j = 0; j < 16; j++) {
                    if (i + j < bytesRead) {
                        byte b = header[i + j];
                        if (b >= 32 && b < 127) {
                            info.append((char) b);
                        } else {
                            info.append('.');
                        }
                    } else {
                        info.append(' ');
                    }
                }
                
                info.append("\n");
            }
        }
        
        return info.toString();
    }
    
    /**
     * Создает параметры шифрования для указанного протокола.
     *
     * @param protocolInfo информация о протоколе
     * @return параметры шифрования
     * @throws CryptoException если протокол не поддерживается
     */
    public static CryptoOperations.CryptoParams createCryptoParams(ProtocolInfo protocolInfo) 
            throws CryptoException {
        if (protocolInfo == null) {
            throw new CryptoException("Protocol info is null");
        }
        
        CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
        params.setProtocolVersion(protocolInfo.getProtocolVersion());
        params.setCryptoType(protocolInfo.getCryptoType());
        params.setCompressed(protocolInfo.isCompressed());
        
        // Копируем дополнительные параметры
        Map<String, Object> additionalParams = protocolInfo.getParams();
        for (Map.Entry<String, Object> entry : additionalParams.entrySet()) {
            params.setParam(entry.getKey(), entry.getValue());
        }
        
        return params;
    }
}
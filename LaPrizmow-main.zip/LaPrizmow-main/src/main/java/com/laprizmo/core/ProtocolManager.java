/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;
import com.laprizmo.crypto.aes.L2Ver51x;
import com.laprizmo.crypto.blowfish.L2Ver21x;
import com.laprizmo.crypto.blowfish.L2Ver212;
import com.laprizmo.crypto.rsa.L2Ver41x;
import com.laprizmo.crypto.rsa.RSAConfig;
import com.laprizmo.crypto.xor.L2Ver111;
import com.laprizmo.crypto.xor.L2Ver120;
import com.laprizmo.crypto.xor.L2Ver121;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Менеджер протоколов шифрования Lineage 2.
 * Обеспечивает централизованное управление протоколами и ключами шифрования.
 */
public class ProtocolManager {
    
    // Типы протоколов шифрования
    public enum ProtocolType {
        XOR,            // Простой XOR с фиксированным ключом
        XOR_POSITION,   // XOR с ключом, зависящим от позиции
        XOR_FILENAME,   // XOR с ключом, зависящим от имени файла
        BLOWFISH,       // Blowfish шифрование
        RSA,            // RSA шифрование
        AES            // AES шифрование
    }
    
    // Карта соответствия версий протоколов их типам
    private static final Map<Integer, ProtocolType> PROTOCOL_TYPES = new HashMap<>();
    
    // Карта соответствия версий протоколов их заголовкам
    private static final Map<Integer, String> PROTOCOL_HEADERS = new HashMap<>();
    
    // Карта соответствия версий XOR протоколов их ключам
    private static final Map<Integer, Integer> XOR_KEYS = new HashMap<>();
    
    // Карта соответствия версий Blowfish протоколов их ключам
    private static final Map<Integer, String> BLOWFISH_KEYS = new HashMap<>();
    
    static {
        // Инициализация типов протоколов
        PROTOCOL_TYPES.put(111, ProtocolType.XOR);
        PROTOCOL_TYPES.put(120, ProtocolType.XOR_POSITION);
        PROTOCOL_TYPES.put(121, ProtocolType.XOR_FILENAME);
        PROTOCOL_TYPES.put(211, ProtocolType.BLOWFISH);
        PROTOCOL_TYPES.put(212, ProtocolType.BLOWFISH);
        PROTOCOL_TYPES.put(411, ProtocolType.RSA);
        PROTOCOL_TYPES.put(412, ProtocolType.RSA);
        PROTOCOL_TYPES.put(413, ProtocolType.RSA);
        PROTOCOL_TYPES.put(414, ProtocolType.RSA);
        PROTOCOL_TYPES.put(510, ProtocolType.AES);
        PROTOCOL_TYPES.put(511, ProtocolType.AES);
        PROTOCOL_TYPES.put(512, ProtocolType.AES);
        
        // Инициализация заголовков
        for (Integer protocol : PROTOCOL_TYPES.keySet()) {
            PROTOCOL_HEADERS.put(protocol, "Lineage2Ver" + protocol);
        }
        
        // Инициализация ключей XOR
        XOR_KEYS.put(111, 0xAC);
        XOR_KEYS.put(120, 0xE6); // Начальная позиция для XOR_POSITION
        
        // Инициализация ключей Blowfish
        BLOWFISH_KEYS.put(211, "31==-%&@!^+][;'.]94-");
        BLOWFISH_KEYS.put(212, "[;'.]94-&@%!^+]-31==");
    }
    
    // Экземпляр синглтона
    private static ProtocolManager instance;
    
    // Пользовательские ключи
    private Map<Integer, Object> customKeys = new HashMap<>();
    
    // Флаг использования устаревших RSA ключей
    private boolean useLegacyRSA = false;
    
    // Пользовательские заголовки
    private Map<Integer, String> customHeaders = new HashMap<>();
    
    /**
     * Приватный конструктор для реализации синглтона.
     */
    private ProtocolManager() {
    }
    
    /**
     * Получает экземпляр менеджера протоколов.
     *
     * @return экземпляр менеджера протоколов
     */
    public static synchronized ProtocolManager getInstance() {
        if (instance == null) {
            instance = new ProtocolManager();
        }
        return instance;
    }
    
    /**
     * Получает тип протокола для указанной версии.
     *
     * @param protocolVersion версия протокола
     * @return тип протокола
     * @throws IllegalArgumentException если версия протокола не поддерживается
     */
    public ProtocolType getProtocolType(int protocolVersion) {
        ProtocolType type = PROTOCOL_TYPES.get(protocolVersion);
        if (type == null) {
            throw new IllegalArgumentException("Unsupported protocol version: " + protocolVersion);
        }
        return type;
    }
    
    /**
     * Создает объект шифрования для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @param fileName имя файла (для XOR_FILENAME)
     * @return объект шифрования
     * @throws CryptoException если версия протокола не поддерживается или произошла ошибка при создании объекта шифрования
     */
    public Object createCryptor(int protocolVersion, String fileName) throws CryptoException {
        ProtocolType type = getProtocolType(protocolVersion);
        
        try {
            switch (type) {
                case XOR:
                    int xorKey = getXorKey(protocolVersion);
                    return new L2Ver111(xorKey);
                
                case XOR_POSITION:
                    int startPosition = getXorKey(protocolVersion);
                    return new L2Ver120(startPosition);
                
                case XOR_FILENAME:
                    if (fileName == null || fileName.isEmpty()) {
                        throw new CryptoException("Filename is required for XOR_FILENAME protocol");
                    }
                    return new L2Ver121(fileName, true);
                
                case BLOWFISH:
                    String blowfishKey = getBlowfishKey(protocolVersion);
                    if (protocolVersion == 212) {
                        return new L2Ver212(blowfishKey);
                    } else {
                        return new L2Ver21x(blowfishKey.getBytes());
                    }
                
                case RSA:
                    RSAConfig config = RSAConfig.getForProtocol(protocolVersion, useLegacyRSA);
                    return new L2Ver41x(config);
                
                case AES:
                    return new L2Ver51x();
                
                default:
                    throw new CryptoException("Unsupported protocol type: " + type);
            }
        } catch (Exception e) {
            throw new CryptoException("Error creating cryptor: " + e.getMessage(), e);
        }
    }
    
    /**
     * Получает заголовок для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @return заголовок протокола
     */
    public String getProtocolHeader(int protocolVersion) {
        // Проверяем наличие пользовательского заголовка
        String customHeader = customHeaders.get(protocolVersion);
        if (customHeader != null) {
            return customHeader;
        }
        
        // Возвращаем стандартный заголовок
        String header = PROTOCOL_HEADERS.get(protocolVersion);
        if (header == null) {
            throw new IllegalArgumentException("Unsupported protocol version: " + protocolVersion);
        }
        return header;
    }
    
    /**
     * Устанавливает пользовательский заголовок для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @param header пользовательский заголовок
     */
    public void setCustomHeader(int protocolVersion, String header) {
        if (header != null && !header.isEmpty()) {
            customHeaders.put(protocolVersion, header);
        } else {
            customHeaders.remove(protocolVersion);
        }
    }
    
    /**
     * Устанавливает пользовательский ключ XOR для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @param key ключ XOR
     */
    public void setCustomXorKey(int protocolVersion, int key) {
        ProtocolType type = PROTOCOL_TYPES.get(protocolVersion);
        if (type == ProtocolType.XOR || type == ProtocolType.XOR_POSITION) {
            customKeys.put(protocolVersion, key);
        } else {
            throw new IllegalArgumentException("Protocol version " + protocolVersion + " is not an XOR protocol");
        }
    }
    
    /**
     * Устанавливает пользовательский ключ Blowfish для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @param key ключ Blowfish
     */
    public void setCustomBlowfishKey(int protocolVersion, String key) {
        ProtocolType type = PROTOCOL_TYPES.get(protocolVersion);
        if (type == ProtocolType.BLOWFISH) {
            customKeys.put(protocolVersion, key);
        } else {
            throw new IllegalArgumentException("Protocol version " + protocolVersion + " is not a Blowfish protocol");
        }
    }
    
    /**
     * Устанавливает пользовательскую конфигурацию RSA для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @param config конфигурация RSA
     */
    public void setCustomRSAConfig(int protocolVersion, RSAConfig config) {
        ProtocolType type = PROTOCOL_TYPES.get(protocolVersion);
        if (type == ProtocolType.RSA) {
            customKeys.put(protocolVersion, config);
        } else {
            throw new IllegalArgumentException("Protocol version " + protocolVersion + " is not an RSA protocol");
        }
    }
    
    /**
     * Устанавливает флаг использования устаревших RSA ключей.
     *
     * @param useLegacy использовать ли устаревшие ключи
     */
    public void setUseLegacyRSA(boolean useLegacy) {
        this.useLegacyRSA = useLegacy;
    }
    
    /**
     * Проверяет, используются ли устаревшие RSA ключи.
     *
     * @return true, если используются устаревшие ключи
     */
    public boolean isUsingLegacyRSA() {
        return useLegacyRSA;
    }
    
    /**
     * Сбрасывает все пользовательские настройки.
     */
    public void resetCustomSettings() {
        customKeys.clear();
        customHeaders.clear();
        useLegacyRSA = false;
    }
    
    /**
     * Получает входной поток для дешифрования данных по указанному протоколу.
     *
     * @param in входной поток с зашифрованными данными
     * @param protocolVersion версия протокола
     * @param fileName имя файла (для XOR_FILENAME)
     * @return входной поток с дешифрованными данными
     * @throws CryptoException если произошла ошибка при создании потока
     */
    public InputStream getDecryptionInputStream(InputStream in, int protocolVersion, String fileName) throws CryptoException {
        Object cryptor = createCryptor(protocolVersion, fileName);
        ProtocolType type = getProtocolType(protocolVersion);
        
        switch (type) {
            case XOR:
                return ((L2Ver111) cryptor).getDecryptionInputStream(in);
            case XOR_POSITION:
                return ((L2Ver120) cryptor).getDecryptionInputStream(in);
            case XOR_FILENAME:
                return ((L2Ver121) cryptor).getDecryptionInputStream(in);
            case BLOWFISH:
                if (protocolVersion == 212) {
                    return ((L2Ver212) cryptor).getDecryptionInputStream(in);
                } else {
                    return ((L2Ver21x) cryptor).getDecryptionInputStream(in);
                }
            case RSA:
                return ((L2Ver41x) cryptor).getDecryptionInputStream(in);
            case AES:
                return ((L2Ver51x) cryptor).getDecryptionInputStream(in);
            default:
                throw new CryptoException("Unsupported protocol type: " + type);
        }
    }
    
    /**
     * Получает выходной поток для шифрования данных по указанному протоколу.
     *
     * @param out выходной поток для записи зашифрованных данных
     * @param protocolVersion версия протокола
     * @param fileName имя файла (для XOR_FILENAME)
     * @return выходной поток для записи данных, которые будут автоматически зашифрованы
     * @throws CryptoException если произошла ошибка при создании потока
     */
    public OutputStream getEncryptionOutputStream(OutputStream out, int protocolVersion, String fileName) throws CryptoException {
        Object cryptor = createCryptor(protocolVersion, fileName);
        ProtocolType type = getProtocolType(protocolVersion);
        
        switch (type) {
            case XOR:
                return ((L2Ver111) cryptor).getEncryptionOutputStream(out);
            case XOR_POSITION:
                return ((L2Ver120) cryptor).getEncryptionOutputStream(out);
            case XOR_FILENAME:
                return ((L2Ver121) cryptor).getEncryptionOutputStream(out);
            case BLOWFISH:
                if (protocolVersion == 212) {
                    return ((L2Ver212) cryptor).getEncryptionOutputStream(out);
                } else {
                    return ((L2Ver21x) cryptor).getEncryptionOutputStream(out);
                }
            case RSA:
                return ((L2Ver41x) cryptor).getEncryptionOutputStream(out);
            case AES:
                return ((L2Ver51x) cryptor).getEncryptionOutputStream(out);
            default:
                throw new CryptoException("Unsupported protocol type: " + type);
        }
    }
    
    /**
     * Получает ключ XOR для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @return ключ XOR
     * @throws CryptoException если версия протокола не поддерживается
     */
    private int getXorKey(int protocolVersion) throws CryptoException {
        // Проверяем наличие пользовательского ключа
        Object customKey = customKeys.get(protocolVersion);
        if (customKey != null && customKey instanceof Integer) {
            return (Integer) customKey;
        }
        
        // Возвращаем стандартный ключ
        Integer key = XOR_KEYS.get(protocolVersion);
        if (key == null) {
            throw new CryptoException("No XOR key defined for protocol version: " + protocolVersion);
        }
        return key;
    }
    
    /**
     * Получает ключ Blowfish для указанной версии протокола.
     *
     * @param protocolVersion версия протокола
     * @return ключ Blowfish
     * @throws CryptoException если версия протокола не поддерживается
     */
    private String getBlowfishKey(int protocolVersion) throws CryptoException {
        // Проверяем наличие пользовательского ключа
        Object customKey = customKeys.get(protocolVersion);
        if (customKey != null && customKey instanceof String) {
            return (String) customKey;
        }
        
        // Возвращаем стандартный ключ
        String key = BLOWFISH_KEYS.get(protocolVersion);
        if (key == null) {
            throw new CryptoException("No Blowfish key defined for protocol version: " + protocolVersion);
        }
        return key;
    }
}
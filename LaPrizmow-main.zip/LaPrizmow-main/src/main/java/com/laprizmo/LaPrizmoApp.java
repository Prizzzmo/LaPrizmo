/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo;

import com.laprizmo.cli.CommandLineProcessor;
import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.*;
import com.laprizmo.crypto.CryptoException;
import com.laprizmo.ui.LaPrizmoGUI;

import java.io.*;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Главный класс приложения LaPrizmo.
 * Обеспечивает запуск приложения в графическом или консольном режиме.
 */
public class LaPrizmoApp {
    
    private static final Logger LOGGER = Logger.getLogger(LaPrizmoApp.class.getName());
    
    // Основные компоненты приложения
    private final ConfigManager configManager;
    private final CryptoEngine cryptoEngine;
    private final CryptoMetrics cryptoMetrics;
    private final GameFileProcessor gameFileProcessor;
    
    /**
     * Создает новый экземпляр приложения.
     */
    public LaPrizmoApp() {
        // Инициализация компонентов
        configManager = ConfigManager.getInstance();
        cryptoEngine = new CryptoEngine(configManager.getDefaultCryptoVersion());
        cryptoMetrics = new CryptoMetrics();
        gameFileProcessor = new DefaultGameFileProcessor(cryptoEngine, cryptoMetrics);
    }
    
    /**
     * Запускает приложение в графическом режиме.
     */
    public void startGUI() {
        try {
            LaPrizmoGUI gui = new LaPrizmoGUI(cryptoEngine, cryptoMetrics, gameFileProcessor, configManager);
            gui.display();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to start GUI", e);
            System.err.println("Critical error: Failed to start GUI");
            e.printStackTrace();
        }
    }
    
    /**
     * Запускает приложение в консольном режиме.
     *
     * @param args аргументы командной строки
     */
    public void startConsole(String[] args) {
        if (args.length < 1) {
            printUsage();
            return;
        }
        
        // Проверяем, если первый аргумент начинается с дефиса, 
        // используем новый CommandLineProcessor, иначе старый обработчик
        if (args[0].startsWith("-") || isAdvancedCommand(args[0])) {
            LOGGER.info("Using advanced command line processor");
        } else {
            try {
                processLegacyConsoleCommands(args);
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error in legacy console mode", e);
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
    
    /**
     * Проверяет, является ли команда расширенной.
     * 
     * @param command команда для проверки
     * @return true, если команда расширенная
     */
    private boolean isAdvancedCommand(String command) {
        return command.equals("encode") || command.equals("decode");
    }
    
    /**
     * Обрабатывает команды консольного режима в устаревшем формате.
     *
     * @param args аргументы командной строки
     * @throws IOException     если возникла ошибка ввода/вывода
     * @throws CryptoException если возникла ошибка в криптографических операциях
     */
    private void processLegacyConsoleCommands(String[] args) throws IOException, CryptoException {
        String command = args[0].toLowerCase();
        
        switch (command) {
            case "decrypt":
                if (args.length < 3) {
                    System.err.println("Error: Not enough arguments for decrypt command");
                    printUsage();
                    return;
                }
                
                File inputFile = new File(args[1]);
                File outputFile = new File(args[2]);
                
                // Установка версии шифрования, если указана
                if (args.length > 3) {
                    setCryptoVersionFromArg(args[3]);
                }
                
                System.out.println("Decrypting " + inputFile.getPath() + " to " + outputFile.getPath());
                gameFileProcessor.decryptFile(inputFile, outputFile);
                System.out.println("Decryption completed successfully");
                break;
                
            case "encrypt":
                if (args.length < 3) {
                    System.err.println("Error: Not enough arguments for encrypt command");
                    printUsage();
                    return;
                }
                
                inputFile = new File(args[1]);
                outputFile = new File(args[2]);
                
                // Установка версии шифрования, если указана
                if (args.length > 3) {
                    setCryptoVersionFromArg(args[3]);
                }
                
                System.out.println("Encrypting " + inputFile.getPath() + " to " + outputFile.getPath());
                gameFileProcessor.encryptFile(inputFile, outputFile);
                System.out.println("Encryption completed successfully");
                break;
                
            case "convert":
                if (args.length < 3) {
                    System.err.println("Error: Not enough arguments for convert command");
                    printUsage();
                    return;
                }
                
                inputFile = new File(args[1]);
                outputFile = new File(args[2]);
                
                if (args[1].toLowerCase().endsWith(".txt")) {
                    System.out.println("Converting TXT to DAT: " + inputFile.getPath() + " to " + outputFile.getPath());
                    gameFileProcessor.convertToDat(inputFile, outputFile);
                } else {
                    System.out.println("Converting DAT to TXT: " + inputFile.getPath() + " to " + outputFile.getPath());
                    gameFileProcessor.convertToTxt(inputFile, outputFile);
                }
                
                System.out.println("Conversion completed successfully");
                break;
                
            case "version":
                System.out.println("LaPrizmo v1.1.0");
                System.out.println("Current crypto version: " + cryptoEngine.getVersion());
                System.out.println("Available crypto versions:");
                for (CryptoEngine.CryptoVersion version : CryptoEngine.CryptoVersion.values()) {
                    if (version != CryptoEngine.CryptoVersion.UNKNOWN) {
                        System.out.println("  " + version.name() + ": " + version.getDescription() + 
                                          " (" + version.getAlgorithm() + ")");
                    }
                }
                break;
                
            case "help":
                printUsage();
                break;
                
            default:
                System.err.println("Error: Unknown command: " + command);
                printUsage();
                break;
        }
    }
    
    /**
     * Устанавливает версию шифрования из аргумента командной строки.
     *
     * @param versionArg аргумент версии
     */
    private void setCryptoVersionFromArg(String versionArg) {
        try {
            // Пробуем разные форматы указания версии
            CryptoEngine.CryptoVersion version;
            
            if (versionArg.startsWith("VER_")) {
                version = CryptoEngine.CryptoVersion.valueOf(versionArg);
            } else {
                version = CryptoEngine.CryptoVersion.valueOf("VER_" + versionArg);
            }
            
            cryptoEngine.setVersion(version);
            System.out.println("Using crypto version: " + version.getDescription() + 
                              " (" + version.getAlgorithm() + ")");
        } catch (IllegalArgumentException e) {
            System.err.println("Warning: Invalid crypto version specified: " + versionArg);
            System.err.println("Using default version: " + cryptoEngine.getVersion().getDescription());
        }
    }
    
    /**
     * Выводит информацию об использовании программы.
     */
    private void printUsage() {
        System.out.println("LaPrizmo - Lineage 2 Encryption Utility v1.1.0");
        System.out.println();
        System.out.println("Legacy Mode Usage:");
        System.out.println("  java -jar laprizmo.jar                  - Start GUI mode");
        System.out.println("  java -jar laprizmo.jar <command> <args> - Execute command in console mode");
        System.out.println();
        System.out.println("Legacy Commands:");
        System.out.println("  decrypt <input_file> <output_file> [version] - Decrypt file");
        System.out.println("  encrypt <input_file> <output_file> [version] - Encrypt file");
        System.out.println("  convert <input_file> <output_file>           - Convert between DAT and TXT formats");
        System.out.println("  version                                      - Show version information");
        System.out.println("  help                                         - Show this help message");
        System.out.println();
        System.out.println("Advanced Mode Usage (compatible with open-l2encdec):");
        System.out.println("  java -jar laprizmo.jar -c decode -p 212 -o output.ini input.ini");
        System.out.println("  java -jar laprizmo.jar -h  - Show advanced help message");
        System.out.println();
        System.out.println("Legacy Version values:");
        for (CryptoEngine.CryptoVersion version : CryptoEngine.CryptoVersion.values()) {
            if (version != CryptoEngine.CryptoVersion.UNKNOWN) {
                System.out.println("  " + version.name().replace("VER_", "") + " - " + 
                                 version.getDescription() + " (" + version.getAlgorithm() + ")");
            }
        }
    }
    
    /**
     * Главный метод приложения.
     *
     * @param args аргументы командной строки
     */
    public static void main(String[] args) {
        // Проверяем наличие аргументов
        if (args.length > 0 && (args[0].startsWith("-") || args[0].equals("encode") || args[0].equals("decode"))) {
            // Используем расширенный CLI обработчик для аргументов в формате open-l2encdec
            if (CommandLineProcessor.processArgs(args)) {
                return; // Обработка выполнена, завершаем программу
            }
        }
        
        // Либо нет аргументов, либо они в старом формате, либо открыть GUI после обработки
        LaPrizmoApp app = new LaPrizmoApp();
        
        if (args.length == 0) {
            // Запуск в графическом режиме
            app.startGUI();
        } else {
            // Запуск в консольном режиме
            app.startConsole(args);
        }
    }
}
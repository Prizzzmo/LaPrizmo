/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui.components;

import com.laprizmo.util.BatchProcessor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.NumberFormat;

/**
 * Компонент для отображения индикатора прогресса операции.
 * Поддерживает отображение процента выполнения, количества обработанных файлов
 * и возможность отмены операции.
 */
public class ProgressIndicator extends JPanel {
    
    // Форматирование чисел
    private static final NumberFormat NUMBER_FORMAT = NumberFormat.getNumberInstance();
    
    // Панель прогресса
    private final JProgressBar progressBar;
    
    // Метка с информацией о прогрессе
    private final JLabel statusLabel;
    
    // Метка с информацией о текущем файле
    private final JLabel fileLabel;
    
    // Кнопка отмены
    private final JButton cancelButton;
    
    // Последние данные о прогрессе
    private BatchProcessor.ProgressInfo lastProgress;
    
    // Время начала операции
    private long startTime;
    
    // Ожидаемое время завершения
    private long estimatedEndTime;
    
    /**
     * Создает новый индикатор прогресса.
     */
    public ProgressIndicator() {
        super(new BorderLayout(10, 10));
        
        // Создаем компоненты
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        
        statusLabel = new JLabel("Ready");
        fileLabel = new JLabel(" ");
        fileLabel.setFont(fileLabel.getFont().deriveFont(Font.ITALIC));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setEnabled(false);
        
        // Создаем панель для меток
        JPanel labelPanel = new JPanel(new BorderLayout());
        labelPanel.add(statusLabel, BorderLayout.NORTH);
        labelPanel.add(fileLabel, BorderLayout.SOUTH);
        
        // Добавляем компоненты на панель
        add(labelPanel, BorderLayout.NORTH);
        add(progressBar, BorderLayout.CENTER);
        add(cancelButton, BorderLayout.EAST);
        
        // Устанавливаем отступы
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Инициализируем форматирование чисел
        NUMBER_FORMAT.setMaximumFractionDigits(1);
    }
    
    /**
     * Устанавливает обработчик нажатия на кнопку отмены.
     *
     * @param listener обработчик нажатия
     */
    public void setCancelActionListener(ActionListener listener) {
        cancelButton.addActionListener(listener);
    }
    
    /**
     * Обновляет индикатор прогресса.
     *
     * @param progress информация о прогрессе
     */
    public void updateProgress(BatchProcessor.ProgressInfo progress) {
        // Сохраняем данные о прогрессе
        lastProgress = progress;
        
        // Инициализируем время начала операции
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }
        
        // Обновляем компоненты интерфейса в потоке EDT
        SwingUtilities.invokeLater(() -> {
            // Обновляем полосу прогресса
            int percent = progress.getPercentComplete();
            progressBar.setValue(percent);
            
            // Обновляем метку с информацией о прогрессе
            String status = String.format("Processed: %d/%d files (%d%%) - %s / %s",
                    progress.getProcessedFiles(),
                    progress.getTotalFiles(),
                    percent,
                    formatSize(progress.getProcessedBytes()),
                    formatSize(progress.getTotalBytes()));
            statusLabel.setText(status);
            
            // Обновляем метку с информацией о текущем файле
            if (progress.getCurrentFile() != null) {
                fileLabel.setText("Current: " + progress.getCurrentFile());
            } else {
                fileLabel.setText(" ");
            }
            
            // Обновляем статус кнопки отмены
            cancelButton.setEnabled(!progress.isCompleted());
            
            // Если операция завершена, сбрасываем время начала
            if (progress.isCompleted()) {
                startTime = 0;
                estimatedEndTime = 0;
            } else {
                // Оцениваем оставшееся время
                updateEstimatedTime(progress);
            }
        });
    }
    
    /**
     * Форматирует размер в байтах в удобочитаемый вид.
     *
     * @param bytes размер в байтах
     * @return отформатированная строка
     */
    private String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return NUMBER_FORMAT.format(bytes / 1024.0) + " KB";
        } else if (bytes < 1024 * 1024 * 1024) {
            return NUMBER_FORMAT.format(bytes / (1024.0 * 1024.0)) + " MB";
        } else {
            return NUMBER_FORMAT.format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GB";
        }
    }
    
    /**
     * Обновляет оценку времени завершения.
     *
     * @param progress информация о прогрессе
     */
    private void updateEstimatedTime(BatchProcessor.ProgressInfo progress) {
        if (progress.getProcessedFiles() == 0 || progress.getTotalFiles() == 0) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - startTime;
        
        // Оцениваем оставшееся время только если прошло достаточно времени
        if (elapsedTime > 1000 && progress.getProcessedFiles() > 0) {
            double filesPerMs = (double) progress.getProcessedFiles() / elapsedTime;
            long remainingFiles = progress.getTotalFiles() - progress.getProcessedFiles();
            long estimatedRemainingTime = (long) (remainingFiles / filesPerMs);
            estimatedEndTime = currentTime + estimatedRemainingTime;
            
            // Обновляем метку с оценкой времени
            String estimatedTimeStr = formatTime(estimatedRemainingTime);
            String newStatus = statusLabel.getText() + " (ETA: " + estimatedTimeStr + ")";
            statusLabel.setText(newStatus);
        }
    }
    
    /**
     * Форматирует время в миллисекундах в удобочитаемый вид.
     *
     * @param milliseconds время в миллисекундах
     * @return отформатированная строка
     */
    private String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        
        if (hours > 0) {
            return String.format("%dh %dm", hours, minutes % 60);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds % 60);
        } else {
            return String.format("%ds", seconds);
        }
    }
    
    /**
     * Сбрасывает индикатор прогресса.
     */
    public void reset() {
        SwingUtilities.invokeLater(() -> {
            progressBar.setValue(0);
            statusLabel.setText("Ready");
            fileLabel.setText(" ");
            cancelButton.setEnabled(false);
            startTime = 0;
            estimatedEndTime = 0;
            lastProgress = null;
        });
    }
    
    /**
     * Получает последнюю информацию о прогрессе.
     *
     * @return информация о прогрессе или null, если нет данных
     */
    public BatchProcessor.ProgressInfo getLastProgress() {
        return lastProgress;
    }
    
    /**
     * Проверяет, завершена ли операция.
     *
     * @return true, если операция завершена или нет активной операции
     */
    public boolean isCompleted() {
        return lastProgress == null || lastProgress.isCompleted();
    }
    
    /**
     * Консольный индикатор прогресса.
     * Отображает прогресс в текстовом виде для использования в консольных приложениях.
     */
    public static class ConsoleProgressIndicator {
        
        // Количество символов в индикаторе
        private static final int BAR_LENGTH = 50;
        
        // Символы для отображения прогресса
        private static final char EMPTY_CHAR = '-';
        private static final char FILLED_CHAR = '=';
        private static final char CURRENT_CHAR = '>';
        
        // Последняя отображенная строка
        private String lastLine = "";
        
        /**
         * Обновляет индикатор прогресса.
         *
         * @param progress информация о прогрессе
         */
        public void updateProgress(BatchProcessor.ProgressInfo progress) {
            int percent = progress.getPercentComplete();
            int filledLength = (int) ((BAR_LENGTH * percent) / 100.0);
            
            // Создаем индикатор
            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < BAR_LENGTH; i++) {
                if (i < filledLength) {
                    bar.append(FILLED_CHAR);
                } else if (i == filledLength) {
                    bar.append(CURRENT_CHAR);
                } else {
                    bar.append(EMPTY_CHAR);
                }
            }
            
            // Форматируем информацию о прогрессе
            String progressLine = String.format("[%s] %3d%% - %d/%d files",
                    bar.toString(), percent, progress.getProcessedFiles(),
                    progress.getTotalFiles());
            
            // Если строка изменилась, выводим ее
            if (!progressLine.equals(lastLine)) {
                // Стираем предыдущую строку
                int lineLength = lastLine.length();
                if (lineLength > 0) {
                    StringBuilder erase = new StringBuilder("\r");
                    for (int i = 0; i < lineLength; i++) {
                        erase.append(" ");
                    }
                    erase.append("\r");
                    System.out.print(erase);
                }
                
                // Выводим новую строку
                System.out.print(progressLine);
                
                // Если операция завершена, добавляем перевод строки
                if (progress.isCompleted()) {
                    System.out.println();
                }
                
                // Запоминаем последнюю строку
                lastLine = progressLine;
            }
        }
        
        /**
         * Сбрасывает индикатор прогресса.
         */
        public void reset() {
            lastLine = "";
        }
    }
}
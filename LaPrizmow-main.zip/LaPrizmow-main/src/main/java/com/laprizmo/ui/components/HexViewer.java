/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui.components;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.undo.UndoManager;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Компонент для отображения и редактирования данных в шестнадцатеричном формате.
 * Поддерживает просмотр больших файлов с динамической загрузкой данных,
 * редактирование, поиск и экспорт.
 */
public class HexViewer extends JPanel {

    private static final Logger LOGGER = Logger.getLogger(HexViewer.class.getName());
    
    // Количество байт в строке
    private static final int BYTES_PER_ROW = 16;
    
    // Размер страницы при загрузке данных
    private static final int PAGE_SIZE = 4096;
    
    // Максимальный размер данных для полной загрузки
    private static final int MAX_FULL_LOAD_SIZE = 10 * 1024 * 1024; // 10 МБ
    
    // Данные для отображения
    private byte[] data;
    
    // Источник данных (файл или поток)
    private Object dataSource;
    
    // Размер данных
    private long dataSize;
    
    // Смещение текущей страницы данных
    private long currentOffset;
    
    // Таблица для отображения данных
    private JTable hexTable;
    
    // Модель данных для таблицы
    private HexTableModel tableModel;
    
    // Поле для отображения смещения
    private JTextField offsetField;
    
    // Поле для поиска
    private JTextField searchField;
    
    // Флаг режима редактирования
    private boolean editable = false;
    
    // Менеджер отмены/повтора
    private UndoManager undoManager;
    
    // Выделенные строки
    private List<Integer> highlightedRows = new ArrayList<>();
    
    // Слушатель изменений данных
    private List<DataChangeListener> dataChangeListeners = new ArrayList<>();
    
    /**
     * Слушатель изменений данных.
     */
    public interface DataChangeListener {
        /**
         * Вызывается при изменении данных.
         *
         * @param offset смещение
         * @param oldValue старое значение
         * @param newValue новое значение
         */
        void dataChanged(long offset, byte oldValue, byte newValue);
    }
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных.
     */
    public HexViewer() {
        super(new BorderLayout());
        
        initComponents();
    }
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных с указанными данными.
     *
     * @param data данные для отображения
     */
    public HexViewer(byte[] data) {
        super(new BorderLayout());
        
        initComponents();
        setData(data);
    }
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных с указанным файлом.
     *
     * @param file файл для отображения
     * @throws IOException если произошла ошибка при чтении файла
     */
    public HexViewer(File file) throws IOException {
        super(new BorderLayout());
        
        initComponents();
        setFile(file);
    }
    
    /**
     * Инициализирует компоненты интерфейса.
     */
    private void initComponents() {
        // Создаем модель таблицы
        tableModel = new HexTableModel();
        
        // Создаем таблицу
        hexTable = new JTable(tableModel);
        hexTable.setDefaultRenderer(Object.class, new HexCellRenderer());
        hexTable.setCellSelectionEnabled(true);
        hexTable.setColumnSelectionAllowed(true);
        hexTable.setRowSelectionAllowed(true);
        hexTable.getTableHeader().setReorderingAllowed(false);
        hexTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        // Настраиваем ширину столбцов
        TableColumn offsetColumn = hexTable.getColumnModel().getColumn(0);
        offsetColumn.setPreferredWidth(80);
        
        for (int i = 1; i <= BYTES_PER_ROW; i++) {
            TableColumn column = hexTable.getColumnModel().getColumn(i);
            column.setPreferredWidth(25);
        }
        
        TableColumn asciiColumn = hexTable.getColumnModel().getColumn(BYTES_PER_ROW + 1);
        asciiColumn.setPreferredWidth(160);
        
        // Создаем прокрутку
        JScrollPane scrollPane = new JScrollPane(hexTable);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        // Создаем панель инструментов
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        // Создаем кнопки
        JButton gotoButton = new JButton("Goto");
        offsetField = new JTextField(10);
        offsetField.setToolTipText("Enter offset in hex (e.g. 0x100) or decimal");
        
        JButton findButton = new JButton("Find");
        searchField = new JTextField(16);
        searchField.setToolTipText("Enter hex bytes, ASCII string, or regex pattern");
        
        JToggleButton editButton = new JToggleButton("Edit");
        editButton.setToolTipText("Toggle edit mode");
        
        JButton undoButton = new JButton("Undo");
        undoButton.setToolTipText("Undo last edit");
        undoButton.setEnabled(false);
        
        JButton redoButton = new JButton("Redo");
        redoButton.setToolTipText("Redo last edit");
        redoButton.setEnabled(false);
        
        JButton saveButton = new JButton("Save");
        saveButton.setToolTipText("Save changes");
        saveButton.setEnabled(false);
        
        // Добавляем компоненты на панель инструментов
        toolBar.add(new JLabel("Offset: "));
        toolBar.add(offsetField);
        toolBar.add(gotoButton);
        toolBar.addSeparator();
        toolBar.add(new JLabel("Find: "));
        toolBar.add(searchField);
        toolBar.add(findButton);
        toolBar.addSeparator();
        toolBar.add(editButton);
        toolBar.add(undoButton);
        toolBar.add(redoButton);
        toolBar.add(saveButton);
        
        // Создаем панель статуса
        JPanel statusPanel = new JPanel(new BorderLayout());
        JLabel statusLabel = new JLabel("Ready");
        JLabel positionLabel = new JLabel("Offset: 0x00000000");
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(positionLabel, BorderLayout.EAST);
        
        // Добавляем компоненты на панель
        add(toolBar, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);
        
        // Настраиваем менеджер отмены/повтора
        undoManager = new UndoManager();
        
        // Добавляем обработчики событий
        
        // Переход к указанному смещению
        gotoButton.addActionListener(e -> {
            try {
                String text = offsetField.getText().trim();
                long offset;
                
                if (text.startsWith("0x") || text.startsWith("0X")) {
                    offset = Long.parseLong(text.substring(2), 16);
                } else {
                    offset = Long.parseLong(text);
                }
                
                gotoOffset(offset);
                hexTable.requestFocus();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid offset format", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Поиск данных
        findButton.addActionListener(e -> {
            String searchText = searchField.getText().trim();
            if (searchText.isEmpty()) {
                return;
            }
            
            // Получаем текущую позицию
            int row = hexTable.getSelectedRow();
            int col = hexTable.getSelectedColumn();
            
            long startOffset = currentOffset;
            if (row >= 0 && col >= 1 && col <= BYTES_PER_ROW) {
                startOffset += row * BYTES_PER_ROW + (col - 1);
            }
            
            // Начинаем поиск со следующего байта
            startOffset++;
            
            try {
                // Преобразуем строку поиска в байты
                byte[] searchBytes;
                if (searchText.matches("^([0-9A-Fa-f]{2})+$")) {
                    // Шестнадцатеричная строка (например, "0A1B2C")
                    searchBytes = hexStringToBytes(searchText);
                } else {
                    // Обычная строка
                    searchBytes = searchText.getBytes(StandardCharsets.UTF_8);
                }
                
                // Выполняем поиск
                long foundOffset = findBytes(searchBytes, startOffset);
                
                if (foundOffset >= 0) {
                    // Переходим к найденному смещению
                    gotoOffset(foundOffset);
                    
                    // Выделяем найденные байты
                    int rowIndex = (int)((foundOffset - currentOffset) / BYTES_PER_ROW);
                    int colIndex = (int)((foundOffset - currentOffset) % BYTES_PER_ROW) + 1;
                    
                    hexTable.setRowSelectionInterval(rowIndex, rowIndex);
                    hexTable.setColumnSelectionInterval(colIndex, colIndex);
                    hexTable.requestFocus();
                    
                    statusLabel.setText("Found at offset 0x" + Long.toHexString(foundOffset).toUpperCase());
                } else {
                    statusLabel.setText("Not found");
                    JOptionPane.showMessageDialog(this, "Not found", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Search error", ex);
                statusLabel.setText("Search error: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Обработка клавиш в поле поиска
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    findButton.doClick();
                }
            }
        });
        
        // Обработка клавиш в поле смещения
        offsetField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    gotoButton.doClick();
                }
            }
        });
        
        // Переключение режима редактирования
        editButton.addActionListener(e -> {
            setEditable(editButton.isSelected());
            if (editButton.isSelected()) {
                statusLabel.setText("Edit mode enabled");
            } else {
                statusLabel.setText("View mode enabled");
            }
        });
        
        // Отмена последнего изменения
        undoButton.addActionListener(e -> {
            if (undoManager.canUndo()) {
                undoManager.undo();
                undoButton.setEnabled(undoManager.canUndo());
                redoButton.setEnabled(undoManager.canRedo());
                saveButton.setEnabled(true);
                hexTable.repaint();
            }
        });
        
        // Повтор последнего изменения
        redoButton.addActionListener(e -> {
            if (undoManager.canRedo()) {
                undoManager.redo();
                undoButton.setEnabled(undoManager.canUndo());
                redoButton.setEnabled(undoManager.canRedo());
                saveButton.setEnabled(true);
                hexTable.repaint();
            }
        });
        
        // Сохранение изменений
        saveButton.addActionListener(e -> {
            if (dataSource instanceof File) {
                try {
                    saveToFile((File) dataSource);
                    statusLabel.setText("Saved to " + ((File) dataSource).getName());
                    saveButton.setEnabled(false);
                } catch (IOException ex) {
                    LOGGER.log(Level.SEVERE, "Save error", ex);
                    statusLabel.setText("Save error: " + ex.getMessage());
                    JOptionPane.showMessageDialog(this, "Save error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JFileChooser fileChooser = new JFileChooser();
                if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    try {
                        saveToFile(fileChooser.getSelectedFile());
                        statusLabel.setText("Saved to " + fileChooser.getSelectedFile().getName());
                        saveButton.setEnabled(false);
                    } catch (IOException ex) {
                        LOGGER.log(Level.SEVERE, "Save error", ex);
                        statusLabel.setText("Save error: " + ex.getMessage());
                        JOptionPane.showMessageDialog(this, "Save error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        
        // Обработка выделения в таблице
        hexTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = hexTable.getSelectedRow();
                int col = hexTable.getSelectedColumn();
                
                if (row >= 0 && col >= 1 && col <= BYTES_PER_ROW) {
                    long offset = currentOffset + row * BYTES_PER_ROW + (col - 1);
                    positionLabel.setText("Offset: 0x" + Long.toHexString(offset).toUpperCase());
                }
            }
        });
        
        // Обработка клавиш в таблице
        hexTable.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (editable) {
                    handleTableKeyPress(e);
                }
            }
        });
        
        // Контекстное меню для таблицы
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem copyHexItem = new JMenuItem("Copy as Hex");
        JMenuItem copyTextItem = new JMenuItem("Copy as Text");
        JMenuItem copyRowItem = new JMenuItem("Copy Row");
        JMenuItem pasteItem = new JMenuItem("Paste");
        JMenuItem selectAllItem = new JMenuItem("Select All");
        
        popupMenu.add(copyHexItem);
        popupMenu.add(copyTextItem);
        popupMenu.add(copyRowItem);
        popupMenu.add(pasteItem);
        popupMenu.addSeparator();
        popupMenu.add(selectAllItem);
        
        hexTable.setComponentPopupMenu(popupMenu);
        
        // Обработчики пунктов меню
        copyHexItem.addActionListener(e -> copySelectionAsHex());
        copyTextItem.addActionListener(e -> copySelectionAsText());
        copyRowItem.addActionListener(e -> copyRowAsHex());
        pasteItem.addActionListener(e -> pasteFromClipboard());
        selectAllItem.addActionListener(e -> hexTable.selectAll());
        
        // Создаем прокрутку колесиком мыши с модификаторами
        hexTable.addMouseWheelListener(e -> {
            if (e.isControlDown()) {
                // Ctrl+Wheel для прокрутки по страницам
                int rotation = e.getWheelRotation();
                if (rotation < 0) {
                    // Прокрутка вверх
                    gotoOffset(Math.max(0, currentOffset - PAGE_SIZE));
                } else {
                    // Прокрутка вниз
                    gotoOffset(Math.min(dataSize - 1, currentOffset + PAGE_SIZE));
                }
                e.consume();
            }
        });
    }
    
    /**
     * Обработка нажатий клавиш в таблице.
     *
     * @param e событие клавиатуры
     */
    private void handleTableKeyPress(KeyEvent e) {
        int row = hexTable.getSelectedRow();
        int col = hexTable.getSelectedColumn();
        
        // Если выбрана ячейка с данными
        if (row >= 0 && col >= 1 && col <= BYTES_PER_ROW) {
            char keyChar = e.getKeyChar();
            
            // Проверяем, является ли символ шестнадцатеричным (0-9, A-F, a-f)
            if ((keyChar >= '0' && keyChar <= '9') || 
                (keyChar >= 'A' && keyChar <= 'F') ||
                (keyChar >= 'a' && keyChar <= 'f')) {
                
                int offset = row * BYTES_PER_ROW + (col - 1);
                if (offset < data.length) {
                    // Получаем текущее значение ячейки
                    String cellValue = (String) tableModel.getValueAt(row, col);
                    
                    // Заменяем первый или второй символ в зависимости от состояния редактирования
                    String newValue;
                    if (cellValue.length() == 2) {
                        // Заменяем первый символ и перенастраиваем на второй
                        newValue = Character.toUpperCase(keyChar) + cellValue.substring(1);
                        cellValue = newValue;
                        
                        // Переходим к следующей позиции
                        if (col < BYTES_PER_ROW) {
                            hexTable.changeSelection(row, col + 1, false, false);
                        } else if (row < tableModel.getRowCount() - 1) {
                            hexTable.changeSelection(row + 1, 1, false, false);
                        }
                    } else {
                        // Неизвестное состояние, считаем, что это первый символ
                        newValue = Character.toUpperCase(keyChar) + "0";
                    }
                    
                    try {
                        // Преобразуем строку в байт
                        byte newByte = (byte) Integer.parseInt(newValue, 16);
                        
                        // Запоминаем старое значение для отмены
                        byte oldByte = data[offset];
                        
                        // Устанавливаем новое значение
                        data[offset] = newByte;
                        
                        // Обновляем таблицу
                        tableModel.fireTableCellUpdated(row, col);
                        tableModel.fireTableCellUpdated(row, BYTES_PER_ROW + 1); // Обновляем ASCII
                        
                        // Уведомляем об изменении данных
                        notifyDataChanged(currentOffset + offset, oldByte, newByte);
                    } catch (NumberFormatException ex) {
                        // Игнорируем ошибку преобразования
                    }
                }
                
                e.consume();
            }
        }
    }
    
    /**
     * Уведомляет об изменении данных.
     *
     * @param offset смещение
     * @param oldValue старое значение
     * @param newValue новое значение
     */
    private void notifyDataChanged(long offset, byte oldValue, byte newValue) {
        for (DataChangeListener listener : dataChangeListeners) {
            listener.dataChanged(offset, oldValue, newValue);
        }
    }
    
    /**
     * Добавляет слушатель изменений данных.
     *
     * @param listener слушатель
     */
    public void addDataChangeListener(DataChangeListener listener) {
        dataChangeListeners.add(listener);
    }
    
    /**
     * Удаляет слушатель изменений данных.
     *
     * @param listener слушатель
     */
    public void removeDataChangeListener(DataChangeListener listener) {
        dataChangeListeners.remove(listener);
    }
    
    /**
     * Устанавливает данные для отображения.
     *
     * @param data данные
     */
    public void setData(byte[] data) {
        this.data = data;
        this.dataSource = data;
        this.dataSize = data.length;
        this.currentOffset = 0;
        
        tableModel.fireTableDataChanged();
    }
    
    /**
     * Устанавливает файл для отображения.
     *
     * @param file файл
     * @throws IOException если произошла ошибка при чтении файла
     */
    public void setFile(File file) throws IOException {
        this.dataSource = file;
        this.dataSize = file.length();
        this.currentOffset = 0;
        
        // Если файл небольшой, загружаем его полностью
        if (dataSize <= MAX_FULL_LOAD_SIZE) {
            loadFullFile(file);
        } else {
            loadFilePage(file, 0);
        }
        
        tableModel.fireTableDataChanged();
    }
    
    /**
     * Загружает файл полностью.
     *
     * @param file файл
     * @throws IOException если произошла ошибка при чтении файла
     */
    private void loadFullFile(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            data = new byte[(int) file.length()];
            fis.read(data);
        }
    }
    
    /**
     * Загружает страницу данных из файла.
     *
     * @param file файл
     * @param offset смещение
     * @throws IOException если произошла ошибка при чтении файла
     */
    private void loadFilePage(File file, long offset) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            raf.seek(offset);
            
            int size = (int) Math.min(PAGE_SIZE, file.length() - offset);
            data = new byte[size];
            raf.read(data);
        }
    }
    
    /**
     * Переходит к указанному смещению.
     *
     * @param offset смещение
     */
    public void gotoOffset(long offset) {
        if (offset < 0 || offset >= dataSize) {
            JOptionPane.showMessageDialog(this, "Offset out of range", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (dataSource instanceof File && dataSize > MAX_FULL_LOAD_SIZE) {
            // Для больших файлов загружаем только страницу
            try {
                currentOffset = offset - (offset % BYTES_PER_ROW);
                loadFilePage((File) dataSource, currentOffset);
                tableModel.fireTableDataChanged();
                
                // Выделяем ячейку с указанным смещением
                int row = (int) ((offset - currentOffset) / BYTES_PER_ROW);
                int col = (int) ((offset - currentOffset) % BYTES_PER_ROW) + 1;
                
                hexTable.setRowSelectionInterval(row, row);
                hexTable.setColumnSelectionInterval(col, col);
                
                // Прокручиваем к выделенной ячейке
                Rectangle rect = hexTable.getCellRect(row, col, true);
                hexTable.scrollRectToVisible(rect);
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Error loading file page", e);
                JOptionPane.showMessageDialog(this, "Error loading file page: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Для небольших файлов и массивов байтов просто прокручиваем
            int row = (int) (offset / BYTES_PER_ROW);
            int col = (int) (offset % BYTES_PER_ROW) + 1;
            
            if (row < tableModel.getRowCount()) {
                hexTable.setRowSelectionInterval(row, row);
                hexTable.setColumnSelectionInterval(col, col);
                
                // Прокручиваем к выделенной ячейке
                Rectangle rect = hexTable.getCellRect(row, col, true);
                hexTable.scrollRectToVisible(rect);
            }
        }
    }
    
    /**
     * Выполняет поиск байтов в данных.
     *
     * @param searchBytes байты для поиска
     * @param startOffset начальное смещение
     * @return смещение найденных байтов или -1, если не найдено
     */
    private long findBytes(byte[] searchBytes, long startOffset) {
        if (searchBytes == null || searchBytes.length == 0) {
            return -1;
        }
        
        if (dataSource instanceof File && dataSize > MAX_FULL_LOAD_SIZE) {
            // Для больших файлов читаем по частям
            try (RandomAccessFile raf = new RandomAccessFile((File) dataSource, "r")) {
                byte[] buffer = new byte[PAGE_SIZE];
                long offset = startOffset;
                
                while (offset + searchBytes.length <= dataSize) {
                    raf.seek(offset);
                    int bytesRead = raf.read(buffer);
                    
                    if (bytesRead < searchBytes.length) {
                        break;
                    }
                    
                    // Ищем в буфере
                    for (int i = 0; i <= bytesRead - searchBytes.length; i++) {
                        boolean found = true;
                        
                        for (int j = 0; j < searchBytes.length; j++) {
                            if (buffer[i + j] != searchBytes[j]) {
                                found = false;
                                break;
                            }
                        }
                        
                        if (found) {
                            return offset + i;
                        }
                    }
                    
                    // Смещаем буфер для поиска перекрывающихся шаблонов
                    offset += bytesRead - searchBytes.length + 1;
                }
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Error searching in file", e);
                return -1;
            }
        } else {
            // Для небольших файлов и массивов байтов ищем в памяти
            for (long i = startOffset; i <= dataSize - searchBytes.length; i++) {
                boolean found = true;
                
                for (int j = 0; j < searchBytes.length; j++) {
                    byte dataByte;
                    
                    if (data != null && i - currentOffset + j < data.length) {
                        dataByte = data[(int) (i - currentOffset + j)];
                    } else {
                        found = false;
                        break;
                    }
                    
                    if (dataByte != searchBytes[j]) {
                        found = false;
                        break;
                    }
                }
                
                if (found) {
                    return i;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Устанавливает режим редактирования.
     *
     * @param editable true для режима редактирования, false для режима просмотра
     */
    public void setEditable(boolean editable) {
        this.editable = editable;
    }
    
    /**
     * Проверяет, находится ли компонент в режиме редактирования.
     *
     * @return true, если компонент в режиме редактирования
     */
    public boolean isEditable() {
        return editable;
    }
    
    /**
     * Копирует выделенные данные в буфер обмена в шестнадцатеричном формате.
     */
    private void copySelectionAsHex() {
        int[] rows = hexTable.getSelectedRows();
        int[] cols = hexTable.getSelectedColumns();
        
        if (rows.length == 0 || cols.length == 0) {
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        
        for (int row : rows) {
            for (int col : cols) {
                if (col >= 1 && col <= BYTES_PER_ROW) {
                    int offset = row * BYTES_PER_ROW + (col - 1);
                    if (offset < data.length) {
                        sb.append(String.format("%02X", data[offset] & 0xFF));
                        sb.append(" ");
                    }
                }
            }
        }
        
        if (sb.length() > 0) {
            StringSelection selection = new StringSelection(sb.toString().trim());
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
        }
    }
    
    /**
     * Копирует выделенные данные в буфер обмена в текстовом формате.
     */
    private void copySelectionAsText() {
        int[] rows = hexTable.getSelectedRows();
        int[] cols = hexTable.getSelectedColumns();
        
        if (rows.length == 0 || cols.length == 0) {
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        
        for (int row : rows) {
            for (int col : cols) {
                if (col >= 1 && col <= BYTES_PER_ROW) {
                    int offset = row * BYTES_PER_ROW + (col - 1);
                    if (offset < data.length) {
                        byte b = data[offset];
                        if (b >= 32 && b < 127) {
                            sb.append((char) b);
                        } else {
                            sb.append('.');
                        }
                    }
                }
            }
        }
        
        if (sb.length() > 0) {
            StringSelection selection = new StringSelection(sb.toString());
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
        }
    }
    
    /**
     * Копирует выделенную строку в буфер обмена в шестнадцатеричном формате.
     */
    private void copyRowAsHex() {
        int row = hexTable.getSelectedRow();
        
        if (row < 0) {
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        
        // Добавляем смещение
        sb.append(String.format("%08X", currentOffset + row * BYTES_PER_ROW));
        sb.append(": ");
        
        // Добавляем шестнадцатеричные данные
        for (int col = 1; col <= BYTES_PER_ROW; col++) {
            int offset = row * BYTES_PER_ROW + (col - 1);
            if (offset < data.length) {
                sb.append(String.format("%02X", data[offset] & 0xFF));
                sb.append(" ");
            } else {
                sb.append("   ");
            }
        }
        
        sb.append(" | ");
        
        // Добавляем ASCII-представление
        for (int col = 1; col <= BYTES_PER_ROW; col++) {
            int offset = row * BYTES_PER_ROW + (col - 1);
            if (offset < data.length) {
                byte b = data[offset];
                if (b >= 32 && b < 127) {
                    sb.append((char) b);
                } else {
                    sb.append('.');
                }
            } else {
                sb.append(' ');
            }
        }
        
        StringSelection selection = new StringSelection(sb.toString());
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, selection);
    }
    
    /**
     * Вставляет данные из буфера обмена.
     */
    private void pasteFromClipboard() {
        if (!editable) {
            JOptionPane.showMessageDialog(this, "Editor is in read-only mode", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int row = hexTable.getSelectedRow();
        int col = hexTable.getSelectedColumn();
        
        if (row < 0 || col < 1 || col > BYTES_PER_ROW) {
            return;
        }
        
        int offset = row * BYTES_PER_ROW + (col - 1);
        if (offset >= data.length) {
            return;
        }
        
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            String text = (String) clipboard.getData(DataFlavor.stringFlavor);
            
            if (text == null || text.isEmpty()) {
                return;
            }
            
            // Пытаемся распознать как шестнадцатеричные данные
            byte[] pasteData;
            if (text.matches("^[0-9A-Fa-f\\s]+$")) {
                // Удаляем пробелы и другие разделители
                text = text.replaceAll("\\s+", "");
                pasteData = hexStringToBytes(text);
            } else {
                // Считаем обычным текстом
                pasteData = text.getBytes(StandardCharsets.UTF_8);
            }
            
            // Проверяем, не выходим ли за границы данных
            if (offset + pasteData.length > data.length) {
                pasteData = java.util.Arrays.copyOf(pasteData, data.length - offset);
            }
            
            // Вставляем данные
            for (int i = 0; i < pasteData.length; i++) {
                int dataOffset = offset + i;
                byte oldByte = data[dataOffset];
                data[dataOffset] = pasteData[i];
                
                // Уведомляем об изменении данных
                notifyDataChanged(currentOffset + dataOffset, oldByte, pasteData[i]);
            }
            
            // Обновляем таблицу
            tableModel.fireTableDataChanged();
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Paste error", e);
            JOptionPane.showMessageDialog(this, "Paste error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Сохраняет данные в файл.
     *
     * @param file файл
     * @throws IOException если произошла ошибка при записи в файл
     */
    private void saveToFile(File file) throws IOException {
        if (data == null) {
            return;
        }
        
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(data);
        }
    }
    
    /**
     * Выделяет строки в таблице.
     *
     * @param rows индексы строк
     */
    public void highlightRows(List<Integer> rows) {
        highlightedRows.clear();
        if (rows != null) {
            highlightedRows.addAll(rows);
        }
        hexTable.repaint();
    }
    
    /**
     * Преобразует шестнадцатеричную строку в массив байтов.
     *
     * @param hexString шестнадцатеричная строка
     * @return массив байтов
     */
    private byte[] hexStringToBytes(String hexString) {
        if (hexString.length() % 2 != 0) {
            hexString = hexString + "0";
        }
        
        byte[] bytes = new byte[hexString.length() / 2];
        
        for (int i = 0; i < bytes.length; i++) {
            int index = i * 2;
            int value = Integer.parseInt(hexString.substring(index, index + 2), 16);
            bytes[i] = (byte) value;
        }
        
        return bytes;
    }
    
    /**
     * Модель данных для таблицы HexViewer.
     */
    private class HexTableModel extends AbstractTableModel {
        
        @Override
        public int getRowCount() {
            if (data == null) {
                return 0;
            }
            
            return (data.length + BYTES_PER_ROW - 1) / BYTES_PER_ROW;
        }
        
        @Override
        public int getColumnCount() {
            return BYTES_PER_ROW + 2; // Offset + BYTES_PER_ROW + ASCII
        }
        
        @Override
        public String getColumnName(int column) {
            if (column == 0) {
                return "Offset";
            } else if (column <= BYTES_PER_ROW) {
                return String.format("%X", column - 1);
            } else {
                return "ASCII";
            }
        }
        
        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            if (data == null) {
                return "";
            }
            
            if (columnIndex == 0) {
                // Offset column
                return String.format("%08X", currentOffset + rowIndex * BYTES_PER_ROW);
            } else if (columnIndex <= BYTES_PER_ROW) {
                // Hex columns
                int offset = rowIndex * BYTES_PER_ROW + (columnIndex - 1);
                if (offset < data.length) {
                    return String.format("%02X", data[offset] & 0xFF);
                } else {
                    return "";
                }
            } else {
                // ASCII column
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < BYTES_PER_ROW; i++) {
                    int offset = rowIndex * BYTES_PER_ROW + i;
                    if (offset < data.length) {
                        byte b = data[offset];
                        if (b >= 32 && b < 127) {
                            sb.append((char) b);
                        } else {
                            sb.append('.');
                        }
                    } else {
                        sb.append(' ');
                    }
                }
                return sb.toString();
            }
        }
        
        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return editable && columnIndex >= 1 && columnIndex <= BYTES_PER_ROW;
        }
        
        @Override
        public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            if (!editable || data == null || !(aValue instanceof String)) {
                return;
            }
            
            if (columnIndex >= 1 && columnIndex <= BYTES_PER_ROW) {
                int offset = rowIndex * BYTES_PER_ROW + (columnIndex - 1);
                if (offset < data.length) {
                    String hexValue = (String) aValue;
                    try {
                        byte newByte = (byte) Integer.parseInt(hexValue, 16);
                        byte oldByte = data[offset];
                        data[offset] = newByte;
                        
                        // Уведомляем об изменении данных
                        notifyDataChanged(currentOffset + offset, oldByte, newByte);
                        
                        // Обновляем ASCII-представление
                        fireTableCellUpdated(rowIndex, BYTES_PER_ROW + 1);
                    } catch (NumberFormatException e) {
                        // Игнорируем ошибку преобразования
                    }
                }
            }
        }
    }
    
    /**
     * Рендерер ячеек для таблицы HexViewer.
     */
    private class HexCellRenderer extends DefaultTableCellRenderer {
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            // Настраиваем выравнивание
            if (column == 0) {
                // Смещение выравниваем по левому краю
                setHorizontalAlignment(SwingConstants.LEFT);
            } else if (column <= BYTES_PER_ROW) {
                // Шестнадцатеричные данные выравниваем по центру
                setHorizontalAlignment(SwingConstants.CENTER);
            } else {
                // ASCII-представление выравниваем по левому краю
                setHorizontalAlignment(SwingConstants.LEFT);
            }
            
            // Настраиваем шрифт
            setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
            
            // Подсвечиваем выделенные строки
            if (!isSelected && highlightedRows.contains(row)) {
                setBackground(new Color(255, 255, 220)); // Светло-желтый
            } else if (!isSelected) {
                setBackground(table.getBackground());
            }
            
            return cell;
        }
    }
}
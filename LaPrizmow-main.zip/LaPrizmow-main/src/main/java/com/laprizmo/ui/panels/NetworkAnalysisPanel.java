/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui.panels;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.ui.components.HexViewer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Панель для перехвата и анализа сетевых пакетов.
 */
public class NetworkAnalysisPanel extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(NetworkAnalysisPanel.class.getName());
    
    private final ConfigManager configManager;
    private final CryptoEngine cryptoEngine;
    
    private boolean snifferRunning = false;
    
    // Компоненты интерфейса
    private JTextField serverAddressField;
    private JTextField clientPortField;
    private JTextField serverPortField;
    private JComboBox<String> gameVersionCombo;
    private JButton startButton;
    private JButton stopButton;
    private JCheckBox decryptCheckbox;
    private JTable packetsTable;
    private DefaultTableModel packetsTableModel;
    private JTextArea packetDetailsArea;
    private HexViewer packetHexViewer;
    private JProgressBar progressBar;
    private JLabel statusLabel;
    
    /**
     * Создает новую панель для анализа сетевых пакетов.
     *
     * @param configManager менеджер конфигурации
     * @param cryptoEngine  криптографический движок
     */
    public NetworkAnalysisPanel(ConfigManager configManager, CryptoEngine cryptoEngine) {
        this.configManager = configManager;
        this.cryptoEngine = cryptoEngine;
        
        setLayout(new BorderLayout(5, 5));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        
        initComponents();
    }
    
    /**
     * Инициализирует компоненты интерфейса.
     */
    private void initComponents() {
        // Панель с настройками сети
        JPanel networkSettingsPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        networkSettingsPanel.setBorder(new TitledBorder("Настройки сети"));
        
        // Верхняя часть настроек сети
        JPanel topNetworkPanel = new JPanel(new BorderLayout(5, 5));
        
        // Адрес сервера
        JPanel serverAddressPanel = new JPanel(new BorderLayout(5, 5));
        serverAddressPanel.add(new JLabel("Адрес сервера:"), BorderLayout.WEST);
        serverAddressField = new JTextField("127.0.0.1");
        serverAddressPanel.add(serverAddressField, BorderLayout.CENTER);
        
        // Добавляем на верхнюю панель
        topNetworkPanel.add(serverAddressPanel, BorderLayout.CENTER);
        
        // Нижняя часть настроек сети
        JPanel bottomNetworkPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        
        // Порт клиента
        JPanel clientPortPanel = new JPanel(new BorderLayout(5, 5));
        clientPortPanel.add(new JLabel("Порт клиента:"), BorderLayout.WEST);
        clientPortField = new JTextField("7777");
        clientPortPanel.add(clientPortField, BorderLayout.CENTER);
        
        // Порт сервера
        JPanel serverPortPanel = new JPanel(new BorderLayout(5, 5));
        serverPortPanel.add(new JLabel("Порт сервера:"), BorderLayout.WEST);
        serverPortField = new JTextField("2106");
        serverPortPanel.add(serverPortField, BorderLayout.CENTER);
        
        // Добавляем на нижнюю панель
        bottomNetworkPanel.add(clientPortPanel);
        bottomNetworkPanel.add(serverPortPanel);
        
        // Добавляем на панель настроек сети
        networkSettingsPanel.add(topNetworkPanel);
        networkSettingsPanel.add(bottomNetworkPanel);
        
        // Панель с настройками анализатора
        JPanel analyzerSettingsPanel = new JPanel(new BorderLayout(5, 5));
        analyzerSettingsPanel.setBorder(new TitledBorder("Настройки анализатора"));
        
        // Версия игры
        JPanel versionPanel = new JPanel(new BorderLayout(5, 5));
        versionPanel.add(new JLabel("Версия игры:"), BorderLayout.WEST);
        Vector<String> versions = new Vector<>(cryptoEngine.getSupportedVersions());
        versions.sort(String::compareTo);
        gameVersionCombo = new JComboBox<>(versions);
        gameVersionCombo.setSelectedItem(configManager.getDefaultGameVersion());
        versionPanel.add(gameVersionCombo, BorderLayout.CENTER);
        
        // Галочка расшифровки
        decryptCheckbox = new JCheckBox("Расшифровывать пакеты", true);
        
        // Кнопки
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        startButton = new JButton("Запустить анализатор");
        startButton.addActionListener(e -> startSniffer());
        
        stopButton = new JButton("Остановить анализатор");
        stopButton.addActionListener(e -> stopSniffer());
        stopButton.setEnabled(false);
        
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        
        // Добавляем на панель настроек анализатора
        JPanel topAnalyzerPanel = new JPanel(new BorderLayout(5, 5));
        topAnalyzerPanel.add(versionPanel, BorderLayout.CENTER);
        topAnalyzerPanel.add(decryptCheckbox, BorderLayout.EAST);
        
        analyzerSettingsPanel.add(topAnalyzerPanel, BorderLayout.NORTH);
        analyzerSettingsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Панель с таблицей пакетов
        JPanel packetsPanel = new JPanel(new BorderLayout(5, 5));
        packetsPanel.setBorder(new TitledBorder("Пакеты"));
        
        // Модель таблицы
        String[] columnNames = {"№", "Время", "Направление", "Тип", "Размер (байт)", "Описание"};
        packetsTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Запрещаем редактирование таблицы
            }
        };
        
        packetsTable = new JTable(packetsTableModel);
        packetsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        packetsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                displayPacketDetails();
            }
        });
        
        JScrollPane tableScrollPane = new JScrollPane(packetsTable);
        packetsPanel.add(tableScrollPane, BorderLayout.CENTER);
        
        // Панель с деталями пакета
        JPanel detailsPanel = new JPanel(new BorderLayout(5, 5));
        detailsPanel.setBorder(new TitledBorder("Детали пакета"));
        
        // Разделенная панель для текста и HEX-просмотра
        JSplitPane detailsSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        detailsSplitPane.setResizeWeight(0.5);
        
        // Текстовая область для деталей
        packetDetailsArea = new JTextArea();
        packetDetailsArea.setEditable(false);
        packetDetailsArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane detailsScrollPane = new JScrollPane(packetDetailsArea);
        
        // HEX-просмотр для пакета
        packetHexViewer = new HexViewer();
        JScrollPane hexScrollPane = new JScrollPane(packetHexViewer);
        
        detailsSplitPane.setTopComponent(detailsScrollPane);
        detailsSplitPane.setBottomComponent(hexScrollPane);
        
        detailsPanel.add(detailsSplitPane, BorderLayout.CENTER);
        
        // Разделенная панель для таблицы и деталей
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        mainSplitPane.setResizeWeight(0.6);
        mainSplitPane.setTopComponent(packetsPanel);
        mainSplitPane.setBottomComponent(detailsPanel);
        
        // Панель статуса
        JPanel statusPanel = new JPanel(new BorderLayout(5, 5));
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setString("");
        
        statusLabel = new JLabel("Анализатор остановлен");
        
        statusPanel.add(progressBar, BorderLayout.CENTER);
        statusPanel.add(statusLabel, BorderLayout.EAST);
        
        // Добавляем все панели на основную панель
        JPanel topPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        topPanel.add(networkSettingsPanel);
        topPanel.add(analyzerSettingsPanel);
        
        add(topPanel, BorderLayout.NORTH);
        add(mainSplitPane, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Запускает анализатор сетевых пакетов.
     */
    public void startSniffer() {
        // Проверяем введенные данные
        if (!validateSettings()) {
            return;
        }
        
        // В реальной реализации здесь будет запуск анализатора пакетов
        snifferRunning = true;
        
        // Блокируем настройки
        setControlsEnabled(false);
        
        // Обновляем статус
        setStatus("Анализатор запущен", true);
        
        // Очищаем таблицу пакетов
        while (packetsTableModel.getRowCount() > 0) {
            packetsTableModel.removeRow(0);
        }
        
        // Очищаем детали пакета
        packetDetailsArea.setText("");
        packetHexViewer.loadData(null);
        
        // Симуляция приема пакетов (только для примера)
        simulatePackets();
    }
    
    /**
     * Останавливает анализатор сетевых пакетов.
     */
    public void stopSniffer() {
        // В реальной реализации здесь будет остановка анализатора пакетов
        snifferRunning = false;
        
        // Разблокируем настройки
        setControlsEnabled(true);
        
        // Обновляем статус
        setStatus("Анализатор остановлен", false);
    }
    
    /**
     * Показывает диалог настроек сети.
     */
    public void showNetworkSettings() {
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this), "Настройки сети", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(4, 1, 5, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Адрес сервера
        JPanel serverAddressPanel = new JPanel(new BorderLayout(5, 5));
        serverAddressPanel.add(new JLabel("Адрес сервера:"), BorderLayout.WEST);
        JTextField serverAddressField = new JTextField(this.serverAddressField.getText());
        serverAddressPanel.add(serverAddressField, BorderLayout.CENTER);
        
        // Порт клиента
        JPanel clientPortPanel = new JPanel(new BorderLayout(5, 5));
        clientPortPanel.add(new JLabel("Порт клиента:"), BorderLayout.WEST);
        JTextField clientPortField = new JTextField(this.clientPortField.getText());
        clientPortPanel.add(clientPortField, BorderLayout.CENTER);
        
        // Порт сервера
        JPanel serverPortPanel = new JPanel(new BorderLayout(5, 5));
        serverPortPanel.add(new JLabel("Порт сервера:"), BorderLayout.WEST);
        JTextField serverPortField = new JTextField(this.serverPortField.getText());
        serverPortPanel.add(serverPortField, BorderLayout.CENTER);
        
        // Кнопки
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton okButton = new JButton("ОК");
        JButton cancelButton = new JButton("Отмена");
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        
        panel.add(serverAddressPanel);
        panel.add(clientPortPanel);
        panel.add(serverPortPanel);
        panel.add(buttonPanel);
        
        okButton.addActionListener(e -> {
            // Сохраняем настройки
            this.serverAddressField.setText(serverAddressField.getText());
            this.clientPortField.setText(clientPortField.getText());
            this.serverPortField.setText(serverPortField.getText());
            dialog.dispose();
        });
        
        cancelButton.addActionListener(e -> dialog.dispose());
        
        dialog.getContentPane().add(panel);
        dialog.setVisible(true);
    }
    
    /**
     * Проверяет корректность введенных настроек.
     *
     * @return true, если настройки корректны
     */
    private boolean validateSettings() {
        // Проверяем адрес сервера
        String serverAddress = serverAddressField.getText().trim();
        if (serverAddress.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Адрес сервера не может быть пустым",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Проверяем порт клиента
        try {
            int clientPort = Integer.parseInt(clientPortField.getText().trim());
            if (clientPort < 1 || clientPort > 65535) {
                JOptionPane.showMessageDialog(this,
                        "Порт клиента должен быть в диапазоне от 1 до 65535",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Порт клиента должен быть числом",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Проверяем порт сервера
        try {
            int serverPort = Integer.parseInt(serverPortField.getText().trim());
            if (serverPort < 1 || serverPort > 65535) {
                JOptionPane.showMessageDialog(this,
                        "Порт сервера должен быть в диапазоне от 1 до 65535",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Порт сервера должен быть числом",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    /**
     * Включает или выключает элементы управления.
     *
     * @param enabled true для включения элементов
     */
    private void setControlsEnabled(boolean enabled) {
        serverAddressField.setEnabled(enabled);
        clientPortField.setEnabled(enabled);
        serverPortField.setEnabled(enabled);
        gameVersionCombo.setEnabled(enabled);
        decryptCheckbox.setEnabled(enabled);
        startButton.setEnabled(enabled);
        stopButton.setEnabled(!enabled);
    }
    
    /**
     * Устанавливает статус операции.
     *
     * @param status     текст статуса
     * @param inProgress флаг, указывающий, что операция в процессе
     */
    private void setStatus(String status, boolean inProgress) {
        statusLabel.setText(status);
        
        if (inProgress) {
            progressBar.setIndeterminate(true);
            progressBar.setString("В процессе...");
        } else {
            progressBar.setIndeterminate(false);
            progressBar.setValue(0);
            progressBar.setString("");
        }
    }
    
    /**
     * Отображает детали выбранного пакета.
     */
    private void displayPacketDetails() {
        int selectedRow = packetsTable.getSelectedRow();
        if (selectedRow < 0) {
            packetDetailsArea.setText("");
            packetHexViewer.loadData(null);
            return;
        }
        
        // В реальной реализации здесь будет получение и отображение деталей пакета
        int packetNumber = (Integer) packetsTableModel.getValueAt(selectedRow, 0);
        String direction = (String) packetsTableModel.getValueAt(selectedRow, 2);
        String packetType = (String) packetsTableModel.getValueAt(selectedRow, 3);
        int size = (Integer) packetsTableModel.getValueAt(selectedRow, 4);
        
        // Формируем текст с деталями пакета
        StringBuilder details = new StringBuilder();
        details.append("Пакет № ").append(packetNumber).append("\n");
        details.append("Направление: ").append(direction).append("\n");
        details.append("Тип: ").append(packetType).append("\n");
        details.append("Размер: ").append(size).append(" байт\n\n");
        
        // В реальной реализации здесь будет расшифровка полей пакета
        details.append("Поля пакета:\n");
        details.append("  - Field1: Value1\n");
        details.append("  - Field2: Value2\n");
        details.append("  - Field3: Value3\n");
        
        packetDetailsArea.setText(details.toString());
        packetDetailsArea.setCaretPosition(0);
        
        // В реальной реализации здесь будет загрузка данных пакета в HEX-просмотр
        byte[] dummyData = new byte[size];
        for (int i = 0; i < size; i++) {
            dummyData[i] = (byte) (i % 256);
        }
        packetHexViewer.loadData(dummyData);
    }
    
    /**
     * Симуляция приема пакетов (только для примера).
     */
    private void simulatePackets() {
        // Создаем таймер для симуляции приема пакетов
        Timer timer = new Timer(1000, new ActionListener() {
            private int packetCounter = 1;
            private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
            private final String[] directions = {"Client->Server", "Server->Client"};
            private final String[] packetTypes = {"SM_CHAR_LIST", "CM_CHAR_SELECT", "SM_CHAR_INFO", "CM_MOVE"};
            
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!snifferRunning) {
                    ((Timer) e.getSource()).stop();
                    return;
                }
                
                // Симулируем новый пакет
                String time = dateFormat.format(new Date());
                String direction = directions[packetCounter % 2];
                String packetType = packetTypes[packetCounter % packetTypes.length];
                int size = 20 + (packetCounter % 100);
                String description = "Описание пакета " + packetType;
                
                // Добавляем пакет в таблицу
                packetsTableModel.addRow(new Object[]{
                        packetCounter, time, direction, packetType, size, description
                });
                
                // Прокручиваем таблицу к последней строке
                packetsTable.scrollRectToVisible(packetsTable.getCellRect(
                        packetsTableModel.getRowCount() - 1, 0, true));
                
                // Выбираем последнюю строку
                if (packetsTable.getSelectedRow() < 0) {
                    packetsTable.setRowSelectionInterval(
                            packetsTableModel.getRowCount() - 1,
                            packetsTableModel.getRowCount() - 1);
                }
                
                packetCounter++;
            }
        });
        
        timer.start();
    }
}
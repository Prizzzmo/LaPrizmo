/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.GameFileProcessor;
import com.laprizmo.plugin.Plugin;
import com.laprizmo.plugin.PluginManager;
import com.laprizmo.ui.components.HexViewer;
import com.laprizmo.ui.panels.FileConversionPanel;
import com.laprizmo.ui.panels.NetworkAnalysisPanel;
import com.laprizmo.ui.panels.SettingsPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Главное окно графического интерфейса LaPrizmo.
 */
public class LaPrizmoGUI extends JFrame {
    private static final Logger LOGGER = Logger.getLogger(LaPrizmoGUI.class.getName());
    
    private static final String TITLE = "LaPrizmo - Lineage 2 Crypt Utility";
    private static final int WIDTH = 900;
    private static final int HEIGHT = 700;
    
    private final ConfigManager configManager;
    private final CryptoEngine cryptoEngine;
    private final PluginManager pluginManager;
    private final GameFileProcessor fileProcessor;
    
    private final JTabbedPane tabbedPane;
    private final Map<String, JComponent> pluginPanels = new HashMap<>();
    
    private FileConversionPanel fileConversionPanel;
    private NetworkAnalysisPanel networkAnalysisPanel;
    private SettingsPanel settingsPanel;
    
    /**
     * Создает новое главное окно приложения.
     *
     * @param configManager менеджер конфигурации
     * @param cryptoEngine  криптографический движок
     * @param pluginManager менеджер плагинов
     * @param fileProcessor процессор файлов
     */
    public LaPrizmoGUI(
            ConfigManager configManager,
            CryptoEngine cryptoEngine,
            PluginManager pluginManager,
            GameFileProcessor fileProcessor) {
        this.configManager = configManager;
        this.cryptoEngine = cryptoEngine;
        this.pluginManager = pluginManager;
        this.fileProcessor = fileProcessor;
        
        // Настраиваем окно
        setTitle(TITLE);
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Центрируем окно
        
        // Устанавливаем иконку приложения, если она существует
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/icons/laprizmo.png"));
            setIconImage(icon.getImage());
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Не удалось загрузить иконку приложения", e);
        }
        
        // Инициализируем компоненты интерфейса
        tabbedPane = new JTabbedPane();
        initComponents();
        
        // Добавляем обработчик закрытия окна
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveSettings();
            }
        });
    }
    
    /**
     * Инициализирует компоненты интерфейса.
     */
    private void initComponents() {
        // Создаем основные панели
        fileConversionPanel = new FileConversionPanel(configManager, cryptoEngine, fileProcessor);
        networkAnalysisPanel = new NetworkAnalysisPanel(configManager, cryptoEngine);
        settingsPanel = new SettingsPanel(configManager, pluginManager);
        
        // Добавляем панели на вкладки
        tabbedPane.addTab("Конвертация файлов", null, fileConversionPanel, "Шифрование и дешифрование файлов");
        tabbedPane.addTab("Анализ сети", null, networkAnalysisPanel, "Анализ сетевых пакетов");
        tabbedPane.addTab("Настройки", null, settingsPanel, "Настройки приложения");
        
        // Добавляем вкладки для плагинов
        addPluginTabs();
        
        // Добавляем панель вкладок на окно
        getContentPane().add(tabbedPane, BorderLayout.CENTER);
        
        // Создаем меню
        JMenuBar menuBar = createMenuBar();
        setJMenuBar(menuBar);
        
        // Создаем строку состояния
        JPanel statusBar = createStatusBar();
        getContentPane().add(statusBar, BorderLayout.SOUTH);
    }
    
    /**
     * Создает строку меню.
     *
     * @return строка меню
     */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // Меню "Файл"
        JMenu fileMenu = new JMenu("Файл");
        
        JMenuItem openItem = new JMenuItem("Открыть DAT...");
        openItem.addActionListener(e -> fileConversionPanel.openDatFile());
        fileMenu.add(openItem);
        
        JMenuItem saveItem = new JMenuItem("Сохранить TXT...");
        saveItem.addActionListener(e -> fileConversionPanel.saveTxtFile());
        fileMenu.add(saveItem);
        
        JMenuItem saveDatItem = new JMenuItem("Сохранить DAT...");
        saveDatItem.addActionListener(e -> fileConversionPanel.saveDatFile());
        fileMenu.add(saveDatItem);
        
        fileMenu.addSeparator();
        
        JMenuItem batchItem = new JMenuItem("Пакетная обработка...");
        batchItem.addActionListener(e -> fileConversionPanel.showBatchProcessDialog());
        fileMenu.add(batchItem);
        
        fileMenu.addSeparator();
        
        JMenuItem exitItem = new JMenuItem("Выход");
        exitItem.addActionListener(e -> {
            saveSettings();
            System.exit(0);
        });
        fileMenu.add(exitItem);
        
        menuBar.add(fileMenu);
        
        // Меню "Сеть"
        JMenu networkMenu = new JMenu("Сеть");
        
        JMenuItem startSnifferItem = new JMenuItem("Запустить анализатор...");
        startSnifferItem.addActionListener(e -> networkAnalysisPanel.startSniffer());
        networkMenu.add(startSnifferItem);
        
        JMenuItem stopSnifferItem = new JMenuItem("Остановить анализатор");
        stopSnifferItem.addActionListener(e -> networkAnalysisPanel.stopSniffer());
        networkMenu.add(stopSnifferItem);
        
        networkMenu.addSeparator();
        
        JMenuItem settingsItem = new JMenuItem("Настройки сети...");
        settingsItem.addActionListener(e -> networkAnalysisPanel.showNetworkSettings());
        networkMenu.add(settingsItem);
        
        menuBar.add(networkMenu);
        
        // Меню "Инструменты"
        JMenu toolsMenu = new JMenu("Инструменты");
        
        JMenuItem hexViewerItem = new JMenuItem("Просмотр HEX...");
        hexViewerItem.addActionListener(e -> showHexViewer());
        toolsMenu.add(hexViewerItem);
        
        JMenuItem detectVersionItem = new JMenuItem("Определить версию...");
        detectVersionItem.addActionListener(e -> fileConversionPanel.detectGameVersion());
        toolsMenu.add(detectVersionItem);
        
        menuBar.add(toolsMenu);
        
        // Меню "Справка"
        JMenu helpMenu = new JMenu("Справка");
        
        JMenuItem aboutItem = new JMenuItem("О программе...");
        aboutItem.addActionListener(e -> showAboutDialog());
        helpMenu.add(aboutItem);
        
        menuBar.add(helpMenu);
        
        return menuBar;
    }
    
    /**
     * Создает строку состояния.
     *
     * @return панель строки состояния
     */
    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        
        JLabel statusLabel = new JLabel("Готово");
        statusBar.add(statusLabel, BorderLayout.WEST);
        
        JLabel versionLabel = new JLabel("LaPrizmo v1.0.0");
        statusBar.add(versionLabel, BorderLayout.EAST);
        
        return statusBar;
    }
    
    /**
     * Добавляет вкладки для плагинов.
     */
    private void addPluginTabs() {
        for (Plugin plugin : pluginManager.getPlugins()) {
            try {
                JPanel pluginPanel = plugin.getSettingsPanel();
                if (pluginPanel != null) {
                    tabbedPane.addTab(plugin.getName(), null, pluginPanel, plugin.getDescription());
                    pluginPanels.put(plugin.getId(), pluginPanel);
                }
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Ошибка при добавлении вкладки плагина: " + plugin.getName(), e);
            }
        }
    }
    
    /**
     * Сохраняет настройки приложения.
     */
    private void saveSettings() {
        try {
            configManager.saveConfig();
            LOGGER.info("Настройки сохранены");
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Не удалось сохранить настройки: " + e.getMessage(), e);
            JOptionPane.showMessageDialog(this,
                    "Не удалось сохранить настройки: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Показывает диалог "О программе".
     */
    private void showAboutDialog() {
        JOptionPane.showMessageDialog(this,
                "LaPrizmo - Утилита для работы с криптографией Lineage 2\n\n" +
                "Версия: 1.0.0\n" +
                "Автор: LaPrizmo Team\n\n" +
                "Поддерживаемые версии игры: 1.1.1 - 5.1.3\n\n" +
                "Количество плагинов: " + pluginManager.getPluginCount() + "\n\n" +
                "Copyright © 2023 LaPrizmo. Все права защищены.",
                "О программе", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Показывает окно просмотра HEX.
     */
    private void showHexViewer() {
        JDialog dialog = new JDialog(this, "HEX Просмотр", true);
        dialog.setSize(700, 500);
        dialog.setLocationRelativeTo(this);
        
        HexViewer hexViewer = new HexViewer();
        JScrollPane scrollPane = new JScrollPane(hexViewer);
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton openButton = new JButton("Открыть файл...");
        openButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(configManager.getLastInputDir());
            int result = chooser.showOpenDialog(dialog);
            if (result == JFileChooser.APPROVE_OPTION) {
                hexViewer.loadFile(chooser.getSelectedFile());
                configManager.setLastInputDir(chooser.getSelectedFile().getParent());
            }
        });
        controlPanel.add(openButton);
        
        dialog.getContentPane().add(controlPanel, BorderLayout.NORTH);
        dialog.getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        dialog.setVisible(true);
    }
}
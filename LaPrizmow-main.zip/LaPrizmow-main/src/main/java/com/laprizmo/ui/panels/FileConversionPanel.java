/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui.panels;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.GameFileProcessor;
import com.laprizmo.crypto.CryptoException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Панель для конвертации файлов между форматами DAT и TXT.
 */
public class FileConversionPanel extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(FileConversionPanel.class.getName());
    
    private final ConfigManager configManager;
    private final CryptoEngine cryptoEngine;
    private final GameFileProcessor fileProcessor;
    
    // Компоненты интерфейса
    private JTextField filePathField;
    private JComboBox<String> gameVersionCombo;
    private JButton openButton;
    private JButton saveTxtButton;
    private JButton saveDatButton;
    private JButton detectVersionButton;
    private JTextArea textArea;
    private JProgressBar progressBar;
    private JLabel statusLabel;
    
    // Текущий открытый файл
    private File currentFile;
    private String currentGameVersion;
    private boolean isDatFile;
    
    /**
     * Создает новую панель для конвертации файлов.
     *
     * @param configManager менеджер конфигурации
     * @param cryptoEngine  криптографический движок
     * @param fileProcessor процессор файлов
     */
    public FileConversionPanel(
            ConfigManager configManager,
            CryptoEngine cryptoEngine,
            GameFileProcessor fileProcessor) {
        this.configManager = configManager;
        this.cryptoEngine = cryptoEngine;
        this.fileProcessor = fileProcessor;
        
        setLayout(new BorderLayout(5, 5));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        
        initComponents();
    }
    
    /**
     * Инициализирует компоненты интерфейса.
     */
    private void initComponents() {
        // Панель с кнопками и полями
        JPanel controlPanel = new JPanel(new BorderLayout(5, 5));
        controlPanel.setBorder(new TitledBorder("Файл"));
        
        // Поле пути к файлу и кнопка открытия
        JPanel filePanel = new JPanel(new BorderLayout(5, 5));
        filePathField = new JTextField();
        filePathField.setEditable(false);
        openButton = new JButton("Открыть...");
        openButton.addActionListener(e -> openDatFile());
        filePanel.add(filePathField, BorderLayout.CENTER);
        filePanel.add(openButton, BorderLayout.EAST);
        
        // Выбор версии игры и кнопка определения версии
        JPanel versionPanel = new JPanel(new BorderLayout(5, 5));
        versionPanel.setBorder(new TitledBorder("Версия игры"));
        
        // Список версий игры
        Vector<String> versions = new Vector<>(cryptoEngine.getSupportedVersions());
        versions.sort(String::compareTo);
        gameVersionCombo = new JComboBox<>(versions);
        gameVersionCombo.setSelectedItem(configManager.getDefaultGameVersion());
        
        detectVersionButton = new JButton("Определить");
        detectVersionButton.addActionListener(e -> detectGameVersion());
        
        versionPanel.add(gameVersionCombo, BorderLayout.CENTER);
        versionPanel.add(detectVersionButton, BorderLayout.EAST);
        
        // Кнопки сохранения
        JPanel savePanel = new JPanel(new GridLayout(1, 2, 5, 0));
        saveTxtButton = new JButton("Сохранить TXT");
        saveTxtButton.addActionListener(e -> saveTxtFile());
        saveTxtButton.setEnabled(false);
        
        saveDatButton = new JButton("Сохранить DAT");
        saveDatButton.addActionListener(e -> saveDatFile());
        saveDatButton.setEnabled(false);
        
        savePanel.add(saveTxtButton);
        savePanel.add(saveDatButton);
        
        // Добавляем панели на панель управления
        JPanel topControlPanel = new JPanel(new BorderLayout(5, 5));
        topControlPanel.add(filePanel, BorderLayout.CENTER);
        topControlPanel.add(versionPanel, BorderLayout.EAST);
        
        controlPanel.add(topControlPanel, BorderLayout.NORTH);
        controlPanel.add(savePanel, BorderLayout.SOUTH);
        
        // Основная панель с текстом
        JPanel contentPanel = new JPanel(new BorderLayout(5, 5));
        contentPanel.setBorder(new TitledBorder("Содержимое"));
        
        textArea = new JTextArea();
        textArea.setEditable(true);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Панель статуса
        JPanel statusPanel = new JPanel(new BorderLayout(5, 5));
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setString("");
        
        statusLabel = new JLabel("Готово");
        
        statusPanel.add(progressBar, BorderLayout.CENTER);
        statusPanel.add(statusLabel, BorderLayout.EAST);
        
        // Добавляем все панели на основную панель
        add(controlPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Открывает файл для обработки.
     */
    public void openDatFile() {
        JFileChooser chooser = new JFileChooser(configManager.getLastInputDir());
        chooser.setFileFilter(new FileNameExtensionFilter("DAT файлы (*.dat)", "dat"));
        
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            configManager.setLastInputDir(selectedFile.getParent());
            
            openFile(selectedFile);
        }
    }
    
    /**
     * Открывает указанный файл.
     *
     * @param file файл для открытия
     */
    private void openFile(File file) {
        try {
            currentFile = file;
            filePathField.setText(file.getPath());
            
            // Определяем тип файла по расширению
            String fileName = file.getName().toLowerCase();
            isDatFile = fileName.endsWith(".dat");
            
            if (isDatFile) {
                // Пытаемся определить версию игры
                String detectedVersion = fileProcessor.detectGameVersion(file);
                if (detectedVersion != null) {
                    gameVersionCombo.setSelectedItem(detectedVersion);
                    currentGameVersion = detectedVersion;
                } else {
                    currentGameVersion = (String) gameVersionCombo.getSelectedItem();
                }
                
                // Пытаемся расшифровать файл
                setStatus("Расшифровка файла...", true);
                
                // Создаем временный файл для расшифрованных данных
                File tempFile = File.createTempFile("laprizmo_", ".txt");
                tempFile.deleteOnExit();
                
                if (fileProcessor.datToTxt(file, tempFile, currentGameVersion)) {
                    // Загружаем расшифрованные данные в текстовое поле
                    textArea.setText(new String(Files.readAllBytes(tempFile.toPath())));
                    textArea.setCaretPosition(0);
                    saveTxtButton.setEnabled(true);
                    saveDatButton.setEnabled(false);
                    setStatus("Файл успешно расшифрован", false);
                } else {
                    textArea.setText("Ошибка расшифровки файла");
                    saveTxtButton.setEnabled(false);
                    saveDatButton.setEnabled(false);
                    setStatus("Ошибка расшифровки файла", false);
                }
            } else {
                // Просто загружаем текстовый файл
                textArea.setText(new String(Files.readAllBytes(file.toPath())));
                textArea.setCaretPosition(0);
                saveTxtButton.setEnabled(false);
                saveDatButton.setEnabled(true);
                setStatus("Файл загружен", false);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Ошибка открытия файла: " + file.getName(), e);
            JOptionPane.showMessageDialog(this,
                    "Ошибка открытия файла: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            
            textArea.setText("");
            saveTxtButton.setEnabled(false);
            saveDatButton.setEnabled(false);
            setStatus("Ошибка открытия файла", false);
        }
    }
    
    /**
     * Сохраняет текущий файл в формате TXT.
     */
    public void saveTxtFile() {
        if (currentFile == null) {
            JOptionPane.showMessageDialog(this,
                    "Нет открытого файла",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JFileChooser chooser = new JFileChooser(configManager.getLastOutputDir());
        chooser.setFileFilter(new FileNameExtensionFilter("TXT файлы (*.txt)", "txt"));
        
        // Предлагаем имя файла на основе текущего
        String suggestedName = currentFile.getName();
        if (suggestedName.toLowerCase().endsWith(".dat")) {
            suggestedName = suggestedName.substring(0, suggestedName.length() - 4) + ".txt";
        } else {
            suggestedName += ".txt";
        }
        chooser.setSelectedFile(new File(chooser.getCurrentDirectory(), suggestedName));
        
        int result = chooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            configManager.setLastOutputDir(selectedFile.getParent());
            
            // Проверяем расширение
            if (!selectedFile.getName().toLowerCase().endsWith(".txt")) {
                selectedFile = new File(selectedFile.getPath() + ".txt");
            }
            
            // Предупреждаем о перезаписи
            if (selectedFile.exists()) {
                int overwrite = JOptionPane.showConfirmDialog(this,
                        "Файл " + selectedFile.getName() + " уже существует. Перезаписать?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION);
                if (overwrite != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            
            try {
                // Сохраняем текст из текстового поля
                Files.write(selectedFile.toPath(), textArea.getText().getBytes());
                setStatus("Файл сохранен: " + selectedFile.getName(), false);
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Ошибка сохранения файла: " + selectedFile.getName(), e);
                JOptionPane.showMessageDialog(this,
                        "Ошибка сохранения файла: " + e.getMessage(),
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                setStatus("Ошибка сохранения файла", false);
            }
        }
    }
    
    /**
     * Сохраняет текущий файл в формате DAT.
     */
    public void saveDatFile() {
        JFileChooser chooser = new JFileChooser(configManager.getLastOutputDir());
        chooser.setFileFilter(new FileNameExtensionFilter("DAT файлы (*.dat)", "dat"));
        
        // Предлагаем имя файла на основе текущего
        String suggestedName = currentFile != null ? currentFile.getName() : "new.dat";
        if (suggestedName.toLowerCase().endsWith(".txt")) {
            suggestedName = suggestedName.substring(0, suggestedName.length() - 4) + ".dat";
        } else if (!suggestedName.toLowerCase().endsWith(".dat")) {
            suggestedName += ".dat";
        }
        chooser.setSelectedFile(new File(chooser.getCurrentDirectory(), suggestedName));
        
        int result = chooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            configManager.setLastOutputDir(selectedFile.getParent());
            
            // Проверяем расширение
            if (!selectedFile.getName().toLowerCase().endsWith(".dat")) {
                selectedFile = new File(selectedFile.getPath() + ".dat");
            }
            
            // Предупреждаем о перезаписи
            if (selectedFile.exists()) {
                int overwrite = JOptionPane.showConfirmDialog(this,
                        "Файл " + selectedFile.getName() + " уже существует. Перезаписать?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION);
                if (overwrite != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            
            try {
                // Создаем временный текстовый файл
                File tempFile = File.createTempFile("laprizmo_", ".txt");
                tempFile.deleteOnExit();
                
                // Сохраняем текст из текстового поля во временный файл
                Files.write(tempFile.toPath(), textArea.getText().getBytes());
                
                // Шифруем текстовый файл
                String gameVersion = (String) gameVersionCombo.getSelectedItem();
                
                setStatus("Шифрование файла...", true);
                
                if (fileProcessor.txtToDat(tempFile, selectedFile, gameVersion)) {
                    setStatus("Файл успешно зашифрован и сохранен: " + selectedFile.getName(), false);
                    
                    // Предлагаем установить новый файл как текущий
                    int switchToDat = JOptionPane.showConfirmDialog(this,
                            "Открыть DAT-файл для редактирования?",
                            "Подтверждение", JOptionPane.YES_NO_OPTION);
                    if (switchToDat == JOptionPane.YES_OPTION) {
                        openFile(selectedFile);
                    }
                } else {
                    setStatus("Ошибка шифрования файла", false);
                }
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Ошибка сохранения файла: " + selectedFile.getName(), e);
                JOptionPane.showMessageDialog(this,
                        "Ошибка сохранения файла: " + e.getMessage(),
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                setStatus("Ошибка сохранения файла", false);
            }
        }
    }
    
    /**
     * Пытается определить версию игры для текущего файла.
     */
    public void detectGameVersion() {
        if (currentFile == null) {
            JOptionPane.showMessageDialog(this,
                    "Сначала откройте файл",
                    "Информация", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        if (!isDatFile) {
            JOptionPane.showMessageDialog(this,
                    "Определение версии возможно только для DAT-файлов",
                    "Информация", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        try {
            setStatus("Определение версии...", true);
            
            String version = fileProcessor.detectGameVersion(currentFile);
            
            if (version != null) {
                gameVersionCombo.setSelectedItem(version);
                currentGameVersion = version;
                setStatus("Определена версия: " + version, false);
                
                // Предлагаем перезагрузить файл с новой версией
                int reload = JOptionPane.showConfirmDialog(this,
                        "Перезагрузить файл с версией " + version + "?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION);
                if (reload == JOptionPane.YES_OPTION) {
                    openFile(currentFile);
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "Не удалось определить версию игры",
                        "Информация", JOptionPane.INFORMATION_MESSAGE);
                setStatus("Не удалось определить версию", false);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Ошибка определения версии", e);
            JOptionPane.showMessageDialog(this,
                    "Ошибка определения версии: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            setStatus("Ошибка определения версии", false);
        }
    }
    
    /**
     * Показывает диалог пакетной обработки файлов.
     */
    public void showBatchProcessDialog() {
        // Создаем диалог
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this), "Пакетная обработка", true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        
        // Создаем панель с элементами управления
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Панель с выбором директорий
        JPanel dirPanel = new JPanel(new GridLayout(2, 1, 0, 10));
        
        // Входная директория
        JPanel inputDirPanel = new JPanel(new BorderLayout(5, 5));
        inputDirPanel.setBorder(new TitledBorder("Входная директория"));
        JTextField inputDirField = new JTextField(configManager.getLastInputDir());
        JButton browseInputButton = new JButton("Обзор");
        inputDirPanel.add(inputDirField, BorderLayout.CENTER);
        inputDirPanel.add(browseInputButton, BorderLayout.EAST);
        
        // Выходная директория
        JPanel outputDirPanel = new JPanel(new BorderLayout(5, 5));
        outputDirPanel.setBorder(new TitledBorder("Выходная директория"));
        JTextField outputDirField = new JTextField(configManager.getLastOutputDir());
        JButton browseOutputButton = new JButton("Обзор");
        outputDirPanel.add(outputDirField, BorderLayout.CENTER);
        outputDirPanel.add(browseOutputButton, BorderLayout.EAST);
        
        dirPanel.add(inputDirPanel);
        dirPanel.add(outputDirPanel);
        
        // Панель с настройками
        JPanel settingsPanel = new JPanel(new GridLayout(3, 1, 0, 10));
        settingsPanel.setBorder(new TitledBorder("Настройки"));
        
        // Выбор версии игры
        JPanel versionPanel = new JPanel(new BorderLayout(5, 5));
        JLabel versionLabel = new JLabel("Версия игры:");
        Vector<String> versions = new Vector<>(cryptoEngine.getSupportedVersions());
        versions.sort(String::compareTo);
        JComboBox<String> versionCombo = new JComboBox<>(versions);
        versionCombo.setSelectedItem(configManager.getDefaultGameVersion());
        versionPanel.add(versionLabel, BorderLayout.WEST);
        versionPanel.add(versionCombo, BorderLayout.CENTER);
        
        // Шаблон файлов
        JPanel patternPanel = new JPanel(new BorderLayout(5, 5));
        JLabel patternLabel = new JLabel("Шаблон файлов:");
        JTextField patternField = new JTextField("*.dat");
        patternPanel.add(patternLabel, BorderLayout.WEST);
        patternPanel.add(patternField, BorderLayout.CENTER);
        
        // Рекурсивная обработка
        JPanel recursivePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JCheckBox recursiveCheck = new JCheckBox("Обрабатывать вложенные директории", configManager.isRecursiveProcessing());
        recursivePanel.add(recursiveCheck);
        
        settingsPanel.add(versionPanel);
        settingsPanel.add(patternPanel);
        settingsPanel.add(recursivePanel);
        
        // Панель с кнопками
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton startButton = new JButton("Начать");
        JButton cancelButton = new JButton("Отмена");
        buttonPanel.add(startButton);
        buttonPanel.add(cancelButton);
        
        // Панель для вывода логов
        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(new TitledBorder("Лог"));
        
        // Панель с прогрессом
        JPanel progressPanel = new JPanel(new BorderLayout(5, 5));
        JProgressBar batchProgressBar = new JProgressBar();
        batchProgressBar.setStringPainted(true);
        batchProgressBar.setString("");
        progressPanel.add(batchProgressBar, BorderLayout.CENTER);
        
        // Собираем все панели вместе
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.add(dirPanel, BorderLayout.NORTH);
        topPanel.add(settingsPanel, BorderLayout.CENTER);
        
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(logScroll, BorderLayout.CENTER);
        panel.add(progressPanel, BorderLayout.SOUTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Добавляем действия для кнопки обзора входной директории
        browseInputButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(inputDirField.getText());
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int result = chooser.showOpenDialog(dialog);
            if (result == JFileChooser.APPROVE_OPTION) {
                inputDirField.setText(chooser.getSelectedFile().getPath());
            }
        });
        
        // Добавляем действия для кнопки обзора выходной директории
        browseOutputButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(outputDirField.getText());
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int result = chooser.showOpenDialog(dialog);
            if (result == JFileChooser.APPROVE_OPTION) {
                outputDirField.setText(chooser.getSelectedFile().getPath());
            }
        });
        
        // Добавляем действие для кнопки отмены
        cancelButton.addActionListener(e -> dialog.dispose());
        
        // Добавляем действие для кнопки запуска
        startButton.addActionListener(e -> {
            // Проверяем входные данные
            File inputDir = new File(inputDirField.getText());
            File outputDir = new File(outputDirField.getText());
            
            if (!inputDir.exists() || !inputDir.isDirectory()) {
                JOptionPane.showMessageDialog(dialog,
                        "Входная директория не существует или не является директорией",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!outputDir.exists()) {
                int create = JOptionPane.showConfirmDialog(dialog,
                        "Выходная директория не существует. Создать?",
                        "Подтверждение", JOptionPane.YES_NO_OPTION);
                if (create != JOptionPane.YES_OPTION) {
                    return;
                }
                
                if (!outputDir.mkdirs()) {
                    JOptionPane.showMessageDialog(dialog,
                            "Не удалось создать выходную директорию",
                            "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Сохраняем настройки
            configManager.setLastInputDir(inputDir.getPath());
            configManager.setLastOutputDir(outputDir.getPath());
            configManager.setRecursiveProcessing(recursiveCheck.isSelected());
            
            // Запускаем пакетную обработку в отдельном потоке
            String gameVersion = (String) versionCombo.getSelectedItem();
            String filePattern = patternField.getText();
            boolean recursive = recursiveCheck.isSelected();
            
            // Блокируем UI
            startButton.setEnabled(false);
            cancelButton.setEnabled(false);
            browseInputButton.setEnabled(false);
            browseOutputButton.setEnabled(false);
            versionCombo.setEnabled(false);
            patternField.setEnabled(false);
            recursiveCheck.setEnabled(false);
            
            new SwingWorker<Integer, String>() {
                @Override
                protected Integer doInBackground() throws Exception {
                    try {
                        // Запускаем пакетную обработку
                        return fileProcessor.batchProcess(
                                inputDir, outputDir, filePattern, gameVersion, recursive);
                    } catch (Exception ex) {
                        publish("Ошибка: " + ex.getMessage());
                        return 0;
                    }
                }
                
                @Override
                protected void process(java.util.List<String> chunks) {
                    // Обновляем лог
                    for (String chunk : chunks) {
                        logArea.append(chunk + "\n");
                    }
                    // Прокручиваем лог вниз
                    logArea.setCaretPosition(logArea.getDocument().getLength());
                }
                
                @Override
                protected void done() {
                    try {
                        int count = get();
                        logArea.append("Обработка завершена. Всего обработано файлов: " + count + "\n");
                        
                        // Разблокируем UI
                        startButton.setEnabled(true);
                        cancelButton.setEnabled(true);
                        browseInputButton.setEnabled(true);
                        browseOutputButton.setEnabled(true);
                        versionCombo.setEnabled(true);
                        patternField.setEnabled(true);
                        recursiveCheck.setEnabled(true);
                        
                    } catch (Exception ex) {
                        logArea.append("Ошибка: " + ex.getMessage() + "\n");
                    }
                }
            }.execute();
        });
        
        dialog.getContentPane().add(panel);
        dialog.setVisible(true);
    }
    
    /**
     * Устанавливает статус операции.
     *
     * @param status    текст статуса
     * @param inProgress флаг, указывающий, что операция в процессе
     */
    private void setStatus(String status, boolean inProgress) {
        statusLabel.setText(status);
        
        if (inProgress) {
            progressBar.setIndeterminate(true);
            progressBar.setString("В процессе...");
        } else {
            progressBar.setIndeterminate(false);
            progressBar.setValue(0);
            progressBar.setString("");
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.laprizmo.ui.panels;

import com.laprizmo.config.ConfigManager;
import com.laprizmo.plugin.Plugin;
import com.laprizmo.plugin.PluginManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Панель настроек приложения.
 */
public class SettingsPanel extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(SettingsPanel.class.getName());
    
    private final ConfigManager configManager;
    private final PluginManager pluginManager;
    
    // Компоненты интерфейса для настроек приложения
    private JComboBox<String> themeCombo;
    private JComboBox<String> languageCombo;
    private JComboBox<String> defaultGameVersionCombo;
    private JCheckBox showMetricsCheckbox;
    private JSpinner batchSizeSpinner;
    private JCheckBox recursiveProcessingCheckbox;
    
    // Компоненты интерфейса для настроек логирования
    private JComboBox<String> logLevelCombo;
    
    // Компоненты интерфейса для плагинов
    private JTable pluginsTable;
    private DefaultTableModel pluginsTableModel;
    private JButton reloadPluginsButton;
    private JButton pluginSettingsButton;
    
    /**
     * Создает новую панель настроек.
     *
     * @param configManager менеджер конфигурации
     * @param pluginManager менеджер плагинов
     */
    public SettingsPanel(ConfigManager configManager, PluginManager pluginManager) {
        this.configManager = configManager;
        this.pluginManager = pluginManager;
        
        setLayout(new BorderLayout(5, 5));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        
        initComponents();
        loadSettings();
    }
    
    /**
     * Инициализирует компоненты интерфейса.
     */
    private void initComponents() {
        // Создаем панель с вкладками
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Панель с общими настройками
        JPanel generalPanel = createGeneralPanel();
        tabbedPane.addTab("Общие", null, generalPanel, "Общие настройки");
        
        // Панель с настройками логирования
        JPanel loggingPanel = createLoggingPanel();
        tabbedPane.addTab("Логирование", null, loggingPanel, "Настройки логирования");
        
        // Панель с плагинами
        JPanel pluginsPanel = createPluginsPanel();
        tabbedPane.addTab("Плагины", null, pluginsPanel, "Управление плагинами");
        
        // Добавляем панель вкладок
        add(tabbedPane, BorderLayout.CENTER);
        
        // Панель с кнопками
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton saveButton = new JButton("Сохранить");
        saveButton.addActionListener(e -> saveSettings());
        
        JButton cancelButton = new JButton("Отмена");
        cancelButton.addActionListener(e -> loadSettings());
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Создает панель с общими настройками.
     *
     * @return панель с общими настройками
     */
    private JPanel createGeneralPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 1, 0, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Тема интерфейса
        JPanel themePanel = new JPanel(new BorderLayout(5, 5));
        themePanel.add(new JLabel("Тема интерфейса:"), BorderLayout.WEST);
        themeCombo = new JComboBox<>(new String[]{"system", "light", "dark"});
        themePanel.add(themeCombo, BorderLayout.CENTER);
        
        // Язык интерфейса
        JPanel languagePanel = new JPanel(new BorderLayout(5, 5));
        languagePanel.add(new JLabel("Язык интерфейса:"), BorderLayout.WEST);
        languageCombo = new JComboBox<>(new String[]{"ru", "en"});
        languagePanel.add(languageCombo, BorderLayout.CENTER);
        
        // Версия игры по умолчанию
        JPanel versionPanel = new JPanel(new BorderLayout(5, 5));
        versionPanel.add(new JLabel("Версия игры по умолчанию:"), BorderLayout.WEST);
        Vector<String> supportedVersions = new Vector<>();
        supportedVersions.add("1.1.1");
        supportedVersions.add("1.2.0");
        supportedVersions.add("2.1.0");
        supportedVersions.add("4.1.1");
        supportedVersions.add("4.1.2");
        supportedVersions.add("4.1.3");
        supportedVersions.add("4.1.4");
        supportedVersions.add("5.1.1");
        supportedVersions.add("5.1.2");
        supportedVersions.add("5.1.3");
        defaultGameVersionCombo = new JComboBox<>(supportedVersions);
        versionPanel.add(defaultGameVersionCombo, BorderLayout.CENTER);
        
        // Показывать метрики
        JPanel metricsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        showMetricsCheckbox = new JCheckBox("Показывать метрики производительности");
        metricsPanel.add(showMetricsCheckbox);
        
        // Размер пакета для пакетной обработки
        JPanel batchSizePanel = new JPanel(new BorderLayout(5, 5));
        batchSizePanel.add(new JLabel("Размер пакета для пакетной обработки:"), BorderLayout.WEST);
        batchSizeSpinner = new JSpinner(new SpinnerNumberModel(100, 1, 10000, 10));
        batchSizePanel.add(batchSizeSpinner, BorderLayout.CENTER);
        
        // Рекурсивная обработка
        JPanel recursivePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        recursiveProcessingCheckbox = new JCheckBox("Рекурсивная обработка вложенных директорий");
        recursivePanel.add(recursiveProcessingCheckbox);
        
        // Добавляем все на панель
        panel.add(themePanel);
        panel.add(languagePanel);
        panel.add(versionPanel);
        panel.add(metricsPanel);
        panel.add(batchSizePanel);
        panel.add(recursivePanel);
        
        return panel;
    }
    
    /**
     * Создает панель с настройками логирования.
     *
     * @return панель с настройками логирования
     */
    private JPanel createLoggingPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Уровень логирования
        JPanel logLevelPanel = new JPanel(new BorderLayout(5, 5));
        logLevelPanel.add(new JLabel("Уровень логирования:"), BorderLayout.WEST);
        logLevelCombo = new JComboBox<>(new String[]{"OFF", "SEVERE", "WARNING", "INFO", "CONFIG", "FINE", "FINER", "FINEST", "ALL"});
        logLevelPanel.add(logLevelCombo, BorderLayout.CENTER);
        
        // Добавляем на панель
        panel.add(logLevelPanel, BorderLayout.NORTH);
        
        return panel;
    }
    
    /**
     * Создает панель с плагинами.
     *
     * @return панель с плагинами
     */
    private JPanel createPluginsPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Таблица плагинов
        String[] columnNames = {"ID", "Название", "Версия", "Автор", "Описание"};
        pluginsTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Запрещаем редактирование таблицы
            }
        };
        
        pluginsTable = new JTable(pluginsTableModel);
        pluginsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(pluginsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Панель с кнопками
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        reloadPluginsButton = new JButton("Перезагрузить плагины");
        reloadPluginsButton.addActionListener(e -> reloadPlugins());
        
        pluginSettingsButton = new JButton("Настройки плагина");
        pluginSettingsButton.addActionListener(e -> showPluginSettings());
        pluginSettingsButton.setEnabled(false);
        
        // Активируем кнопку настроек при выборе плагина
        pluginsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                pluginSettingsButton.setEnabled(pluginsTable.getSelectedRow() >= 0);
            }
        });
        
        buttonPanel.add(reloadPluginsButton);
        buttonPanel.add(pluginSettingsButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Загружаем список плагинов
        loadPluginsList();
        
        return panel;
    }
    
    /**
     * Загружает список плагинов в таблицу.
     */
    private void loadPluginsList() {
        // Очищаем таблицу
        while (pluginsTableModel.getRowCount() > 0) {
            pluginsTableModel.removeRow(0);
        }
        
        // Загружаем плагины
        for (Plugin plugin : pluginManager.getPlugins()) {
            pluginsTableModel.addRow(new Object[]{
                    plugin.getId(),
                    plugin.getName(),
                    plugin.getVersion(),
                    plugin.getAuthor(),
                    plugin.getDescription()
            });
        }
    }
    
    /**
     * Перезагружает плагины.
     */
    private void reloadPlugins() {
        try {
            // Выгружаем плагины
            pluginManager.unloadPlugins();
            
            // Загружаем плагины
            pluginManager.loadPlugins(new java.io.File("plugins"));
            
            // Обновляем список
            loadPluginsList();
            
            JOptionPane.showMessageDialog(this,
                    "Плагины успешно перезагружены",
                    "Информация", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Ошибка перезагрузки плагинов", e);
            JOptionPane.showMessageDialog(this,
                    "Ошибка перезагрузки плагинов: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Показывает диалог настроек выбранного плагина.
     */
    private void showPluginSettings() {
        int selectedRow = pluginsTable.getSelectedRow();
        if (selectedRow < 0) {
            return;
        }
        
        String pluginId = (String) pluginsTableModel.getValueAt(selectedRow, 0);
        Plugin plugin = pluginManager.getPluginById(pluginId);
        
        if (plugin == null) {
            JOptionPane.showMessageDialog(this,
                    "Плагин не найден",
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Показываем диалог с панелью настроек плагина
        JPanel settingsPanel = plugin.getSettingsPanel();
        
        if (settingsPanel == null) {
            JOptionPane.showMessageDialog(this,
                    "У плагина нет настроек",
                    "Информация", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                "Настройки плагина " + plugin.getName(), true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        
        dialog.getContentPane().add(settingsPanel);
        dialog.setVisible(true);
    }
    
    /**
     * Загружает настройки из конфигурации.
     */
    private void loadSettings() {
        // Общие настройки
        themeCombo.setSelectedItem(configManager.getUiTheme());
        languageCombo.setSelectedItem(configManager.getUiLanguage());
        defaultGameVersionCombo.setSelectedItem(configManager.getDefaultGameVersion());
        showMetricsCheckbox.setSelected(configManager.isShowMetrics());
        batchSizeSpinner.setValue(configManager.getBatchSize());
        recursiveProcessingCheckbox.setSelected(configManager.isRecursiveProcessing());
        
        // Настройки логирования
        logLevelCombo.setSelectedItem(configManager.getLogLevel());
    }
    
    /**
     * Сохраняет настройки в конфигурацию.
     */
    private void saveSettings() {
        try {
            // Общие настройки
            configManager.setUiTheme((String) themeCombo.getSelectedItem());
            configManager.setUiLanguage((String) languageCombo.getSelectedItem());
            configManager.setDefaultGameVersion((String) defaultGameVersionCombo.getSelectedItem());
            configManager.setShowMetrics(showMetricsCheckbox.isSelected());
            configManager.setBatchSize((Integer) batchSizeSpinner.getValue());
            configManager.setRecursiveProcessing(recursiveProcessingCheckbox.isSelected());
            
            // Настройки логирования
            configManager.setLogLevel((String) logLevelCombo.getSelectedItem());
            
            // Сохраняем в файл
            configManager.saveConfig();
            
            JOptionPane.showMessageDialog(this,
                    "Настройки успешно сохранены",
                    "Информация", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Ошибка сохранения настроек", e);
            JOptionPane.showMessageDialog(this,
                    "Ошибка сохранения настроек: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolDetector;
import com.laprizmo.core.ProtocolDetector.ProtocolInfo;
import java.io.IOException;

/**
 * Пример дешифрования файла Lineage 2 с автоматическим определением протокола.
 * Этот пример демонстрирует базовое использование LaPrizmo API для дешифрования
 * игрового файла.
 */
public class BasicDecryptExample {
    
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java BasicDecryptExample <input_file> <output_file>");
            return;
        }
        
        String inputFile = args[0];
        String outputFile = args[1];
        
        try {
            // Шаг 1: Определяем протокол файла
            ProtocolInfo protocolInfo = ProtocolDetector.detectProtocol(inputFile);
            
            if (protocolInfo == null) {
                System.out.println("Error: Could not detect protocol for file " + inputFile);
                return;
            }
            
            // Выводим информацию о протоколе
            System.out.println("Detected protocol: " + protocolInfo.getProtocolVersion());
            System.out.println("Crypto type: " + protocolInfo.getCryptoType());
            System.out.println("Compressed: " + protocolInfo.isCompressed());
            
            // Шаг 2: Создаем параметры дешифрования на основе обнаруженного протокола
            CryptoOperations.CryptoParams params = 
                ProtocolDetector.createCryptoParams(protocolInfo);
            
            // Шаг 3: Получаем экземпляр CryptoEngine
            CryptoEngine engine = CryptoEngine.getInstance();
            
            // Шаг 4: Дешифруем файл
            System.out.println("Decrypting file...");
            engine.decryptFile(inputFile, outputFile, params);
            System.out.println("File decrypted successfully: " + outputFile);
            
        } catch (IOException e) {
            System.err.println("IO Error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
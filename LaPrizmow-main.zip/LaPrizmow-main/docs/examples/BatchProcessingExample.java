/*
 * Copyright (c) 2025 Prizmo
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.util.BatchProcessor;
import com.laprizmo.ui.components.ProgressIndicator.ConsoleProgressIndicator;
import java.io.IOException;

/**
 * Пример пакетной обработки файлов Lineage 2.
 * Этот пример демонстрирует использование BatchProcessor для обработки 
 * множества файлов с индикацией прогресса.
 */
public class BatchProcessingExample {
    
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java BatchProcessingExample <input_dir> <output_dir> <operation>");
            System.out.println("  operation: encrypt or decrypt");
            return;
        }
        
        String inputDir = args[0];
        String outputDir = args[1];
        String operation = args[2].toLowerCase();
        
        if (!operation.equals("encrypt") && !operation.equals("decrypt")) {
            System.out.println("Error: Operation must be 'encrypt' or 'decrypt'");
            return;
        }
        
        boolean isEncrypt = operation.equals("encrypt");
        
        try {
            // Шаг 1: Создаем экземпляр CryptoOperations
            CryptoOperations cryptoOperations = new CryptoOperations();
            
            // Шаг 2: Создаем параметры криптографии
            CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
            
            if (isEncrypt) {
                // Для шифрования нужно указать конкретный протокол и тип
                params.setProtocolVersion(516); // Например, используем протокол 516 (AES)
                params.setCryptoType(CryptoOperations.CryptoType.AES);
                params.setCompressed(true);
            } else {
                // Для дешифрования параметры могут быть автоматически определены
                // Пустые параметры означают автоопределение
            }
            
            // Шаг 3: Создаем экземпляр BatchProcessor
            BatchProcessor processor = new BatchProcessor(cryptoOperations, params);
            
            // Шаг 4: Настраиваем параметры обработки
            processor.setOutputDirectory(outputDir)
                     .setPreserveDirectoryStructure(true)
                     .setOverwriteExisting(false)
                     .setMaxThreads(Runtime.getRuntime().availableProcessors())
                     .setFileFilter(".*\\.(dat|unx|enx)"); // Фильтр для файлов .dat, .unx, .enx
            
            // Шаг 5: Создаем индикатор прогресса для консоли
            ConsoleProgressIndicator progressIndicator = new ConsoleProgressIndicator();
            processor.setProgressHandler(progressIndicator::updateProgress);
            
            // Шаг 6: Запускаем обработку
            System.out.println("Starting batch " + operation + " from " + inputDir + " to " + outputDir);
            long startTime = System.currentTimeMillis();
            
            int processedFiles = processor.process(inputDir, isEncrypt);
            
            long elapsedTime = System.currentTimeMillis() - startTime;
            System.out.println("\nProcessed " + processedFiles + " files in " + (elapsedTime / 1000) + " seconds");
            
        } catch (IOException e) {
            System.err.println("IO Error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
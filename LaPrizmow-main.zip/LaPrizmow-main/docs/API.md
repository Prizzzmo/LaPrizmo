# LaPrizmo API Documentation

## Содержание

1. [Введение](#введение)
2. [Основные пакеты](#основные-пакеты)
3. [Core API](#core-api)
4. [Crypto API](#crypto-api)
5. [Network API](#network-api)
6. [File API](#file-api)
7. [Plugin API](#plugin-api)
8. [UI API](#ui-api)
9. [Utilities API](#utilities-api)
10. [Примеры использования](#примеры-использования)
11. [Расширения API](#расширения-api)
12. [Обратная совместимость](#обратная-совместимость)

## Введение

LaPrizmo API представляет собой набор интерфейсов и классов для работы с криптографическими алгоритмами Lineage 2, обработки файлов, анализа сетевых пакетов и расширения функциональности через плагины. API разделен на несколько логических модулей, каждый из которых отвечает за определенную функциональность.

### Версионирование API

LaPrizmo использует семантическое версионирование (SemVer). Текущая версия API: 1.0.0.

- **Major** (первое число): увеличивается при несовместимых изменениях API
- **Minor** (второе число): увеличивается при добавлении новой функциональности с обратной совместимостью
- **Patch** (третье число): увеличивается при исправлении ошибок с обратной совместимостью

### Соглашения по именованию

- **Пакеты**: именуются в нижнем регистре, используют формат `com.laprizmo.<module>`
- **Классы и интерфейсы**: используют CamelCase с большой буквы
- **Методы**: используют camelCase с маленькой буквы
- **Константы**: используют UPPER_SNAKE_CASE
- **Переменные**: используют camelCase с маленькой буквы

## Основные пакеты

LaPrizmo API организован в следующие основные пакеты:

| Пакет | Описание |
|-------|----------|
| `com.laprizmo.core` | Основное ядро приложения, включая движок шифрования и управление протоколами |
| `com.laprizmo.crypto` | Реализации криптографических алгоритмов (XOR, Blowfish, RSA, AES, и т.д.) |
| `com.laprizmo.network` | Компоненты для работы с сетевыми пакетами |
| `com.laprizmo.plugin` | API для создания и управления плагинами |
| `com.laprizmo.ui` | Компоненты пользовательского интерфейса |
| `com.laprizmo.util` | Утилитарные классы |

## Core API

### Обзор

Core API предоставляет основную функциональность для шифрования/дешифрования данных, включая управление протоколами и определение форматов файлов.

### Основные классы и интерфейсы

#### `CryptoEngine`

Основной класс для выполнения криптографических операций.

```java
public class CryptoEngine {
    /**
     * Получает экземпляр CryptoEngine (Singleton).
     */
    public static CryptoEngine getInstance();
    
    /**
     * Шифрует файл.
     *
     * @param inputFile  путь к входному файлу
     * @param outputFile путь к выходному файлу
     * @param params     параметры шифрования
     * @throws CryptoException в случае ошибки шифрования
     * @throws IOException     в случае ошибки ввода/вывода
     */
    public void encryptFile(String inputFile, String outputFile, CryptoOperations.CryptoParams params)
            throws CryptoException, IOException;
    
    /**
     * Дешифрует файл.
     *
     * @param inputFile  путь к входному файлу
     * @param outputFile путь к выходному файлу
     * @param params     параметры дешифрования (если null или пустые, будет выполнено автоопределение)
     * @throws CryptoException в случае ошибки дешифрования
     * @throws IOException     в случае ошибки ввода/вывода
     */
    public void decryptFile(String inputFile, String outputFile, CryptoOperations.CryptoParams params)
            throws CryptoException, IOException;
    
    /**
     * Шифрует массив байтов.
     *
     * @param data   данные для шифрования
     * @param params параметры шифрования
     * @return зашифрованные данные
     * @throws CryptoException в случае ошибки шифрования
     */
    public byte[] encrypt(byte[] data, CryptoOperations.CryptoParams params)
            throws CryptoException;
    
    /**
     * Дешифрует массив байтов.
     *
     * @param data   данные для дешифрования
     * @param params параметры дешифрования
     * @return дешифрованные данные
     * @throws CryptoException в случае ошибки дешифрования
     */
    public byte[] decrypt(byte[] data, CryptoOperations.CryptoParams params)
            throws CryptoException;
}
```

#### `CryptoOperations`

Класс для выполнения криптографических операций с поддержкой различных алгоритмов.

```java
public class CryptoOperations {
    /**
     * Типы криптографии.
     */
    public enum CryptoType {
        XOR,
        BLOWFISH,
        RSA,
        AES,
        LAMECRYPT
    }
    
    /**
     * Параметры криптографических операций.
     */
    public static class CryptoParams {
        // Основные параметры
        private int protocolVersion;
        private CryptoType cryptoType;
        private boolean compressed;
        private Map<String, Object> additionalParams;
        
        // Конструкторы, геттеры, сеттеры
        // ...
        
        /**
         * Устанавливает дополнительный параметр.
         */
        public void setParam(String key, Object value);
        
        /**
         * Получает дополнительный параметр.
         */
        public Object getParam(String key);
    }
    
    /**
     * Шифрует файл с указанными параметрами.
     */
    public void encryptFile(String inputFile, String outputFile, CryptoParams params)
            throws CryptoException, IOException;
    
    /**
     * Дешифрует файл с указанными параметрами.
     */
    public void decryptFile(String inputFile, String outputFile, CryptoParams params)
            throws CryptoException, IOException;
    
    // Другие методы для шифрования/дешифрования
    // ...
}
```

#### `ProtocolManager`

Управляет протоколами и криптографическими алгоритмами для разных версий.

```java
public class ProtocolManager {
    /**
     * Получает экземпляр ProtocolManager (Singleton).
     */
    public static ProtocolManager getInstance();
    
    /**
     * Получает алгоритм шифрования для указанного протокола и типа.
     *
     * @param protocolVersion версия протокола
     * @param cryptoType     тип криптографии
     * @return алгоритм шифрования или null, если не поддерживается
     */
    public CryptoAlgorithm getCryptoAlgorithm(int protocolVersion, CryptoOperations.CryptoType cryptoType);
    
    /**
     * Возвращает список поддерживаемых версий протокола.
     */
    public int[] getSupportedProtocols();
    
    /**
     * Проверяет, поддерживается ли указанная версия протокола.
     */
    public boolean isProtocolSupported(int protocolVersion);
    
    /**
     * Возвращает типы криптографии, поддерживаемые для указанной версии протокола.
     */
    public CryptoOperations.CryptoType[] getSupportedCryptoTypes(int protocolVersion);
}
```

#### `ProtocolDetector`

Определяет версию протокола и тип шифрования файла.

```java
public class ProtocolDetector {
    /**
     * Информация о протоколе файла.
     */
    public static class ProtocolInfo {
        private final int protocolVersion;
        private final CryptoOperations.CryptoType cryptoType;
        private final boolean compressed;
        private final Map<String, Object> params;
        
        // Геттеры, сеттеры...
    }
    
    /**
     * Определяет протокол файла.
     *
     * @param filename имя файла
     * @return информация о протоколе или null, если не удалось определить
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static ProtocolInfo detectProtocol(String filename) throws IOException;
    
    /**
     * Создает параметры шифрования для указанного протокола.
     *
     * @param protocolInfo информация о протоколе
     * @return параметры шифрования
     */
    public static CryptoOperations.CryptoParams createCryptoParams(ProtocolInfo protocolInfo);
}
```

#### `GameFileProcessor`

Обрабатывает файлы игры для конкретных форматов.

```java
public interface GameFileProcessor {
    /**
     * Обрабатывает файл.
     *
     * @param inputFile  входной файл
     * @param outputFile выходной файл
     * @param params     параметры обработки
     * @throws IOException если произошла ошибка при обработке файла
     */
    void processFile(String inputFile, String outputFile, Map<String, Object> params) throws IOException;
    
    /**
     * Проверяет, поддерживается ли указанный файл.
     *
     * @param filename имя файла
     * @return true, если файл поддерживается
     */
    boolean supportsFile(String filename);
    
    /**
     * Возвращает описание формата файла.
     */
    String getFormatDescription();
}
```

## Crypto API

### Обзор

Crypto API предоставляет интерфейсы и реализации различных криптографических алгоритмов, используемых в Lineage 2.

### Основные классы и интерфейсы

#### `CryptoAlgorithm`

Базовый интерфейс для всех криптографических алгоритмов.

```java
public interface CryptoAlgorithm {
    /**
     * Шифрует данные.
     *
     * @param data данные для шифрования
     * @return зашифрованные данные
     * @throws CryptoException если произошла ошибка при шифровании
     */
    byte[] encrypt(byte[] data) throws CryptoException;
    
    /**
     * Дешифрует данные.
     *
     * @param data данные для дешифрования
     * @return дешифрованные данные
     * @throws CryptoException если произошла ошибка при дешифровании
     */
    byte[] decrypt(byte[] data) throws CryptoException;
    
    /**
     * Возвращает версию протокола, поддерживаемую этим алгоритмом.
     */
    int getProtocolVersion();
}
```

#### `CryptoException`

Исключение, выбрасываемое при ошибках криптографических операций.

```java
public class CryptoException extends Exception {
    // Конструкторы
    public CryptoException(String message);
    public CryptoException(String message, Throwable cause);
    public CryptoException(Throwable cause);
}
```

#### `FinishableOutputStream`

Интерфейс для выходных потоков с поддержкой завершения операций.

```java
public interface FinishableOutputStream {
    /**
     * Завершает запись, выполняя необходимые финальные операции.
     *
     * @throws IOException если произошла ошибка при завершении
     */
    void finish() throws IOException;
}
```

### Пакеты с реализациями

#### `com.laprizmo.crypto.xor`

Реализации алгоритма XOR для разных версий протокола.

- `L2Ver111`: XOR реализация для протокола 111
- `L2Ver120`: XOR реализация для протокола 120
- `L2Ver121`: XOR реализация для протокола 121 (с ключом из имени файла)

#### `com.laprizmo.crypto.blowfish`

Реализации алгоритма Blowfish.

- `BlowfishEngine`: Базовый движок Blowfish
- `L2Ver212`: Blowfish реализация для протокола 212
- `L2Ver21x`: Blowfish реализация для протоколов 210-219

#### `com.laprizmo.crypto.rsa`

Реализации алгоритма RSA.

- `RSAConfig`: Конфигурация ключей RSA
- `EnhancedRSAConfig`: Расширенная конфигурация с поддержкой дополнительных ключей
- `RSAEngine`: Базовый движок RSA
- `L2Ver41x`: RSA реализация для протоколов 411-416

#### `com.laprizmo.crypto.aes`

Реализации алгоритма AES.

- `L2Ver51x`: AES реализация для протоколов 516-912

#### `com.laprizmo.crypto.lamecrypt`

Реализации простых алгоритмов для старых версий.

- `L2Ver111`: Lamecrypt реализация для протокола 111
- `L2Ver120`: Lamecrypt реализация для протокола 120

## Network API

### Обзор

Network API предоставляет инструменты для работы с сетевыми пакетами Lineage 2, включая их перехват, анализ и модификацию.

### Основные классы и интерфейсы

#### `L2Packet`

Класс, представляющий сетевой пакет Lineage 2.

```java
public class L2Packet {
    /**
     * Направление пакета.
     */
    public enum Direction {
        CLIENT_TO_SERVER,
        SERVER_TO_CLIENT
    }
    
    /**
     * Создает новый пакет из сырых данных.
     *
     * @param rawData   сырые данные пакета
     * @param direction направление пакета
     */
    public L2Packet(byte[] rawData, Direction direction);
    
    /**
     * Создает новый пакет с заданными параметрами.
     *
     * @param opcode    код операции
     * @param payload   данные пакета
     * @param direction направление пакета
     */
    public L2Packet(int opcode, byte[] payload, Direction direction);
    
    /**
     * Возвращает сырые данные пакета.
     */
    public byte[] getRawData();
    
    /**
     * Возвращает направление пакета.
     */
    public Direction getDirection();
    
    /**
     * Возвращает код операции пакета.
     */
    public int getOpcode();
    
    /**
     * Возвращает данные пакета (без кода операции).
     */
    public byte[] getPayload();
    
    /**
     * Возвращает время создания пакета.
     */
    public long getTimestamp();
}
```

#### `LivePacketProcessor`

Класс для перехвата и обработки пакетов в реальном времени.

```java
public class LivePacketProcessor {
    /**
     * Интерфейс слушателя пакетов.
     */
    public interface PacketListener {
        /**
         * Вызывается при получении пакета.
         */
        void onPacketReceived(L2Packet packet);
    }
    
    /**
     * Интерфейс фильтра пакетов.
     */
    public interface PacketFilter {
        /**
         * Проверяет, должен ли пакет быть обработан.
         */
        boolean accept(L2Packet packet);
    }
    
    /**
     * Создает новый процессор пакетов.
     *
     * @param serverHost      хост сервера
     * @param serverPort      порт сервера
     * @param localPort       локальный порт для прослушивания
     * @param protocolVersion версия протокола
     */
    public LivePacketProcessor(String serverHost, int serverPort, int localPort, int protocolVersion);
    
    /**
     * Добавляет слушателя пакетов.
     */
    public void addListener(PacketListener listener);
    
    /**
     * Удаляет слушателя пакетов.
     */
    public void removeListener(PacketListener listener);
    
    /**
     * Добавляет фильтр пакетов.
     */
    public void addFilter(PacketFilter filter);
    
    /**
     * Удаляет фильтр пакетов.
     */
    public void removeFilter(PacketFilter filter);
    
    /**
     * Запускает перехват пакетов.
     */
    public void start() throws IOException;
    
    /**
     * Останавливает перехват пакетов.
     */
    public void stop();
    
    /**
     * Устанавливает правило модификации пакетов.
     */
    public void setModificationRule(PacketModifier modifier);
}
```

#### `PacketAnalyzer`

Класс для анализа структуры и содержимого пакетов.

```java
public class PacketAnalyzer {
    /**
     * Информация о пакете.
     */
    public static class PacketInfo {
        private final String type;
        private final Map<String, Object> fields;
        
        // Геттеры, сеттеры...
    }
    
    /**
     * Создает новый анализатор пакетов.
     */
    public PacketAnalyzer();
    
    /**
     * Устанавливает версию протокола.
     */
    public void setProtocolVersion(int protocolVersion);
    
    /**
     * Анализирует пакет.
     *
     * @param packet пакет для анализа
     * @return информация о пакете
     */
    public PacketInfo analyzePacket(L2Packet packet);
    
    /**
     * Создает пакет из структурированной информации.
     *
     * @param type      тип пакета
     * @param fields    поля пакета
     * @param direction направление пакета
     * @return созданный пакет
     */
    public L2Packet createPacket(String type, Map<String, Object> fields, L2Packet.Direction direction);
}
```

## File API

### Обзор

File API предоставляет инструменты для работы с файлами, включая пакетную обработку и специальные функции для DAT-файлов.

### Основные классы и интерфейсы

#### `BatchProcessor`

Класс для пакетной обработки файлов.

```java
public class BatchProcessor {
    /**
     * Информация о прогрессе обработки.
     */
    public static class ProgressInfo {
        private final int totalFiles;
        private final int processedFiles;
        private final int successfulFiles;
        private final int failedFiles;
        private final long totalBytes;
        private final long processedBytes;
        private final String currentFile;
        private final boolean completed;
        
        // Геттеры...
        
        /**
         * Возвращает процент выполнения.
         */
        public int getPercentComplete();
    }
    
    /**
     * Создает новый процессор для пакетной обработки.
     *
     * @param cryptoOperations операции криптографии
     * @param params           параметры криптографической операции
     */
    public BatchProcessor(CryptoOperations cryptoOperations, CryptoOperations.CryptoParams params);
    
    /**
     * Устанавливает выходную директорию.
     */
    public BatchProcessor setOutputDirectory(String outputDirectory);
    
    /**
     * Устанавливает флаг сохранения структуры директорий.
     */
    public BatchProcessor setPreserveDirectoryStructure(boolean preserve);
    
    /**
     * Устанавливает флаг перезаписи существующих файлов.
     */
    public BatchProcessor setOverwriteExisting(boolean overwrite);
    
    /**
     * Устанавливает максимальное количество потоков для параллельной обработки.
     */
    public BatchProcessor setMaxThreads(int maxThreads);
    
    /**
     * Устанавливает регулярное выражение для фильтрации файлов.
     */
    public BatchProcessor setFileFilter(String regex);
    
    /**
     * Устанавливает обработчик прогресса.
     */
    public BatchProcessor setProgressHandler(Consumer<ProgressInfo> progressHandler);
    
    /**
     * Отменяет текущую операцию.
     */
    public void cancel();
    
    /**
     * Проверяет, была ли отменена операция.
     */
    public boolean isCancelled();
    
    /**
     * Сбрасывает флаг отмены операции.
     */
    public void resetCancel();
    
    /**
     * Выполняет обработку файлов.
     *
     * @param inputPath путь к входному файлу или директории
     * @param isEncrypt true для шифрования, false для дешифрования
     * @return результат обработки (количество успешно обработанных файлов)
     * @throws IOException если произошла ошибка при чтении файла
     */
    public int process(String inputPath, boolean isEncrypt) throws IOException;
}
```

#### `DatFileUtils`

Утилиты для работы с DAT-файлами Lineage 2.

```java
public class DatFileUtils {
    /**
     * Информация о разделе DAT-файла.
     */
    public static class DatChunk {
        private final String id;
        private final int size;
        private final long offset;
        private String type;
        private final List<DatChunk> children;
        
        // Геттеры, сеттеры...
    }
    
    /**
     * Анализирует DAT-файл и возвращает информацию о его структуре.
     *
     * @param filename имя файла
     * @return корневой раздел файла
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static DatChunk analyzeDatFile(String filename) throws IOException;
    
    /**
     * Извлекает данные раздела из файла.
     *
     * @param filename имя файла
     * @param chunk    информация о разделе
     * @return данные раздела
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static byte[] extractChunkData(String filename, DatChunk chunk) throws IOException;
    
    /**
     * Извлекает все текстовые данные из файла.
     *
     * @param filename имя файла
     * @return карта с найденными текстовыми данными (путь -> содержимое)
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static Map<String, String> extractTextData(String filename) throws IOException;
    
    /**
     * Добавляет контрольную сумму в конец файла.
     *
     * @param filename имя файла
     * @param tailSize размер данных для расчета контрольной суммы
     * @throws IOException если произошла ошибка при записи в файл
     */
    public static void addChecksum(String filename, int tailSize) throws IOException;
    
    /**
     * Проверяет контрольную сумму в конце файла.
     *
     * @param filename имя файла
     * @return true, если контрольная сумма верна
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static boolean verifyChecksum(String filename) throws IOException;
    
    /**
     * Удаляет контрольную сумму из конца файла.
     *
     * @param filename имя файла
     * @throws IOException если произошла ошибка при записи в файл
     */
    public static void removeChecksum(String filename) throws IOException;
    
    /**
     * Извлекает вложенные файлы из DAT-файла.
     *
     * @param filename  имя файла
     * @param outputDir выходная директория
     * @return список извлеченных файлов
     * @throws IOException если произошла ошибка при чтении или записи файлов
     */
    public static List<String> extractNestedFiles(String filename, String outputDir) throws IOException;
    
    /**
     * Генерирует отчет о структуре DAT-файла.
     *
     * @param filename имя файла
     * @return отчет о структуре файла
     * @throws IOException если произошла ошибка при чтении файла
     */
    public static String generateDatReport(String filename) throws IOException;
}
```

#### `ZlibUtils`

Утилиты для работы с алгоритмом сжатия ZLib.

```java
public class ZlibUtils {
    /**
     * Сжимает массив байтов с использованием ZLib.
     *
     * @param data данные для сжатия
     * @return сжатые данные
     * @throws IOException если произошла ошибка при сжатии
     */
    public static byte[] compress(byte[] data) throws IOException;
    
    /**
     * Сжимает массив байтов с использованием ZLib с указанным уровнем сжатия.
     *
     * @param data  данные для сжатия
     * @param level уровень сжатия (0-9, где 9 - максимальное сжатие)
     * @return сжатые данные
     * @throws IOException если произошла ошибка при сжатии
     */
    public static byte[] compress(byte[] data, int level) throws IOException;
    
    /**
     * Распаковывает массив байтов с использованием ZLib.
     *
     * @param data сжатые данные
     * @return распакованные данные
     * @throws IOException если произошла ошибка при распаковке
     */
    public static byte[] decompress(byte[] data) throws IOException;
    
    /**
     * Распаковывает массив байтов с использованием ZLib с указанием ожидаемого размера.
     *
     * @param data         сжатые данные
     * @param expectedSize ожидаемый размер распакованных данных или -1, если размер неизвестен
     * @return распакованные данные
     * @throws IOException если произошла ошибка при распаковке
     */
    public static byte[] decompress(byte[] data, int expectedSize) throws IOException;
    
    // Дополнительные методы для работы с файлами и потоками...
}
```

## Plugin API

### Обзор

Plugin API предоставляет интерфейсы и классы для создания и управления плагинами, расширяющими функциональность LaPrizmo.

### Основные классы и интерфейсы

#### `Plugin`

Интерфейс, который должен реализовывать каждый плагин.

```java
public interface Plugin {
    /**
     * Возвращает уникальный идентификатор плагина.
     */
    String getId();
    
    /**
     * Возвращает отображаемое имя плагина.
     */
    String getName();
    
    /**
     * Возвращает версию плагина.
     */
    String getVersion();
    
    /**
     * Инициализирует плагин.
     *
     * @param context контекст плагина
     * @throws Exception если произошла ошибка инициализации
     */
    void initialize(PluginContext context) throws Exception;
    
    /**
     * Завершает работу плагина.
     */
    void shutdown();
}
```

#### `PluginContext`

Контекст, предоставляемый плагину для доступа к API приложения.

```java
public interface PluginContext {
    /**
     * Возвращает API ядра приложения.
     */
    CoreAPI getCoreAPI();
    
    /**
     * Возвращает API пользовательского интерфейса.
     */
    UIAPI getUIAPI();
    
    /**
     * Возвращает API сетевого модуля.
     */
    NetworkAPI getNetworkAPI();
    
    /**
     * Возвращает API файлового модуля.
     */
    FileAPI getFileAPI();
    
    /**
     * Регистрирует обработчик события.
     *
     * @param eventType тип события
     * @param handler   обработчик события
     */
    void registerEventHandler(String eventType, EventHandler handler);
    
    /**
     * Отменяет регистрацию обработчика события.
     *
     * @param eventType тип события
     * @param handler   обработчик события
     */
    void unregisterEventHandler(String eventType, EventHandler handler);
    
    /**
     * Возвращает настройки плагина.
     */
    PluginSettings getSettings();
    
    /**
     * Возвращает логгер для плагина.
     */
    Logger getLogger();
}
```

#### `PluginManager`

Управляет загрузкой и использованием плагинов.

```java
public class PluginManager {
    /**
     * Получает экземпляр PluginManager (Singleton).
     */
    public static PluginManager getInstance();
    
    /**
     * Загружает плагин из JAR-файла.
     *
     * @param file JAR-файл плагина
     * @throws Exception если произошла ошибка при загрузке
     */
    public void loadPlugin(File file) throws Exception;
    
    /**
     * Выгружает плагин.
     *
     * @param pluginId идентификатор плагина
     * @return true, если плагин был выгружен
     */
    public boolean unloadPlugin(String pluginId);
    
    /**
     * Возвращает плагин по идентификатору.
     *
     * @param pluginId идентификатор плагина
     * @return плагин или null, если не найден
     */
    public Plugin getPlugin(String pluginId);
    
    /**
     * Возвращает все загруженные плагины.
     */
    public Map<String, Plugin> getPlugins();
    
    /**
     * Проверяет, загружен ли плагин.
     *
     * @param pluginId идентификатор плагина
     * @return true, если плагин загружен
     */
    public boolean isPluginLoaded(String pluginId);
    
    /**
     * Загружает все плагины из указанной директории.
     *
     * @param directory директория с плагинами
     * @return список идентификаторов загруженных плагинов
     */
    public List<String> loadPlugins(String directory);
    
    /**
     * Устанавливает директорию плагинов.
     *
     * @param directory путь к директории плагинов
     */
    public void setPluginDirectory(String directory);
    
    /**
     * Получает директорию плагинов.
     */
    public String getPluginDirectory();
}
```

#### `EventHandler`

Интерфейс для обработчиков событий.

```java
public interface EventHandler {
    /**
     * Обрабатывает событие.
     *
     * @param event событие
     */
    void handle(Event event);
}
```

#### `Event`

Базовый класс для событий.

```java
public class Event {
    private final String type;
    private final Map<String, Object> data;
    
    /**
     * Создает новое событие.
     *
     * @param type тип события
     */
    public Event(String type);
    
    /**
     * Создает новое событие с данными.
     *
     * @param type тип события
     * @param data данные события
     */
    public Event(String type, Map<String, Object> data);
    
    /**
     * Возвращает тип события.
     */
    public String getType();
    
    /**
     * Возвращает данные события.
     */
    public Map<String, Object> getData();
    
    /**
     * Возвращает значение из данных события.
     *
     * @param key ключ
     * @return значение или null, если не найдено
     */
    public Object getValue(String key);
}
```

## UI API

### Обзор

UI API предоставляет компоненты и интерфейсы для работы с пользовательским интерфейсом LaPrizmo.

### Основные классы и интерфейсы

#### `HexViewer`

Компонент для просмотра и редактирования данных в шестнадцатеричном формате.

```java
public class HexViewer extends JPanel {
    /**
     * Слушатель изменений данных.
     */
    public interface DataChangeListener {
        /**
         * Вызывается при изменении данных.
         *
         * @param offset   смещение
         * @param oldValue старое значение
         * @param newValue новое значение
         */
        void dataChanged(long offset, byte oldValue, byte newValue);
    }
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных.
     */
    public HexViewer();
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных с указанными данными.
     *
     * @param data данные для отображения
     */
    public HexViewer(byte[] data);
    
    /**
     * Создает новый просмотрщик шестнадцатеричных данных с указанным файлом.
     *
     * @param file файл для отображения
     * @throws IOException если произошла ошибка при чтении файла
     */
    public HexViewer(File file) throws IOException;
    
    /**
     * Устанавливает данные для отображения.
     *
     * @param data данные
     */
    public void setData(byte[] data);
    
    /**
     * Устанавливает файл для отображения.
     *
     * @param file файл
     * @throws IOException если произошла ошибка при чтении файла
     */
    public void setFile(File file) throws IOException;
    
    /**
     * Переходит к указанному смещению.
     *
     * @param offset смещение
     */
    public void gotoOffset(long offset);
    
    /**
     * Устанавливает режим редактирования.
     *
     * @param editable true для режима редактирования, false для режима просмотра
     */
    public void setEditable(boolean editable);
    
    /**
     * Проверяет, находится ли компонент в режиме редактирования.
     */
    public boolean isEditable();
    
    /**
     * Добавляет слушатель изменений данных.
     *
     * @param listener слушатель
     */
    public void addDataChangeListener(DataChangeListener listener);
    
    /**
     * Удаляет слушатель изменений данных.
     *
     * @param listener слушатель
     */
    public void removeDataChangeListener(DataChangeListener listener);
    
    /**
     * Выделяет строки в таблице.
     *
     * @param rows индексы строк
     */
    public void highlightRows(List<Integer> rows);
}
```

#### `ProgressIndicator`

Компонент для отображения индикатора прогресса операции.

```java
public class ProgressIndicator extends JPanel {
    /**
     * Создает новый индикатор прогресса.
     */
    public ProgressIndicator();
    
    /**
     * Устанавливает обработчик нажатия на кнопку отмены.
     *
     * @param listener обработчик нажатия
     */
    public void setCancelActionListener(ActionListener listener);
    
    /**
     * Обновляет индикатор прогресса.
     *
     * @param progress информация о прогрессе
     */
    public void updateProgress(BatchProcessor.ProgressInfo progress);
    
    /**
     * Сбрасывает индикатор прогресса.
     */
    public void reset();
    
    /**
     * Получает последнюю информацию о прогрессе.
     */
    public BatchProcessor.ProgressInfo getLastProgress();
    
    /**
     * Проверяет, завершена ли операция.
     */
    public boolean isCompleted();
    
    /**
     * Консольный индикатор прогресса.
     */
    public static class ConsoleProgressIndicator {
        /**
         * Обновляет индикатор прогресса.
         *
         * @param progress информация о прогрессе
         */
        public void updateProgress(BatchProcessor.ProgressInfo progress);
        
        /**
         * Сбрасывает индикатор прогресса.
         */
        public void reset();
    }
}
```

## Utilities API

### Обзор

Utilities API предоставляет различные утилитарные классы для упрощения работы с приложением.

### Основные классы

#### `ZlibUtils`

```java
// См. выше в разделе File API
```

#### `DatFileUtils`

```java
// См. выше в разделе File API
```

## Примеры использования

### Дешифрование файла

```java
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolDetector;

public class DecryptExample {
    public static void main(String[] args) {
        try {
            // Определение протокола файла
            ProtocolDetector.ProtocolInfo info = ProtocolDetector.detectProtocol("encrypted.dat");
            
            if (info != null) {
                System.out.println("Detected protocol: " + info.getProtocolVersion());
                System.out.println("Crypto type: " + info.getCryptoType());
                
                // Создание параметров на основе обнаруженной информации
                CryptoOperations.CryptoParams params = ProtocolDetector.createCryptoParams(info);
                
                // Получение экземпляра CryptoEngine
                CryptoEngine engine = CryptoEngine.getInstance();
                
                // Дешифрование файла
                engine.decryptFile("encrypted.dat", "decrypted.dat", params);
                
                System.out.println("File decrypted successfully!");
            } else {
                System.out.println("Could not detect protocol for the file.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Шифрование файла

```java
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;

public class EncryptExample {
    public static void main(String[] args) {
        try {
            // Создание параметров шифрования
            CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
            params.setProtocolVersion(516);
            params.setCryptoType(CryptoOperations.CryptoType.AES);
            params.setCompressed(true);
            
            // Получение экземпляра CryptoEngine
            CryptoEngine engine = CryptoEngine.getInstance();
            
            // Шифрование файла
            engine.encryptFile("decrypted.dat", "encrypted.dat", params);
            
            System.out.println("File encrypted successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Пакетная обработка файлов

```java
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.util.BatchProcessor;

public class BatchExample {
    public static void main(String[] args) {
        try {
            // Создание параметров для шифрования
            CryptoOperations cryptoOperations = new CryptoOperations();
            CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
            params.setProtocolVersion(120);
            params.setCryptoType(CryptoOperations.CryptoType.XOR);
            
            // Создание процессора пакетной обработки
            BatchProcessor processor = new BatchProcessor(cryptoOperations, params)
                    .setOutputDirectory("output")
                    .setPreserveDirectoryStructure(true)
                    .setFileFilter(".*\\.dat")
                    .setMaxThreads(4)
                    .setProgressHandler(progress -> {
                        System.out.printf("Progress: %d%% (%d/%d files)\n",
                                progress.getPercentComplete(),
                                progress.getProcessedFiles(),
                                progress.getTotalFiles());
                    });
            
            // Запуск дешифрования
            int processedFiles = processor.process("input_directory", false);
            
            System.out.println("Processed " + processedFiles + " files.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Анализ DAT-файла

```java
import com.laprizmo.util.DatFileUtils;

public class DatAnalysisExample {
    public static void main(String[] args) {
        try {
            // Анализ DAT-файла
            DatFileUtils.DatChunk root = DatFileUtils.analyzeDatFile("game_data.dat");
            
            // Генерация отчета
            String report = DatFileUtils.generateDatReport("game_data.dat");
            System.out.println(report);
            
            // Извлечение текстовых данных
            Map<String, String> textData = DatFileUtils.extractTextData("game_data.dat");
            for (Map.Entry<String, String> entry : textData.entrySet()) {
                System.out.println("Found text: " + entry.getKey());
            }
            
            // Извлечение вложенных файлов
            List<String> extractedFiles = DatFileUtils.extractNestedFiles("game_data.dat", "extracted");
            System.out.println("Extracted " + extractedFiles.size() + " files.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Перехват сетевых пакетов

```java
import com.laprizmo.network.L2Packet;
import com.laprizmo.network.LivePacketProcessor;
import com.laprizmo.network.PacketAnalyzer;

public class PacketCaptureExample {
    public static void main(String[] args) {
        try {
            // Создание процессора пакетов
            LivePacketProcessor processor = new LivePacketProcessor(
                    "game.server.com", 7777, 7778, 413);
            
            // Создание анализатора пакетов
            PacketAnalyzer analyzer = new PacketAnalyzer();
            analyzer.setProtocolVersion(413);
            
            // Добавление слушателя пакетов
            processor.addListener(packet -> {
                String direction = packet.getDirection() == L2Packet.Direction.CLIENT_TO_SERVER ?
                        "C->S" : "S->C";
                
                System.out.printf("[%s] Opcode: 0x%02X, Size: %d bytes\n",
                        direction, packet.getOpcode(), packet.getRawData().length);
                
                // Анализ пакета
                PacketAnalyzer.PacketInfo info = analyzer.analyzePacket(packet);
                if (info != null) {
                    System.out.println("Packet type: " + info.getType());
                    for (Map.Entry<String, Object> field : info.getFields().entrySet()) {
                        System.out.println("  " + field.getKey() + ": " + field.getValue());
                    }
                }
            });
            
            // Добавление фильтра пакетов
            processor.addFilter(packet -> packet.getOpcode() != 0x03); // Исключаем heartbeat
            
            // Запуск перехвата
            processor.start();
            
            System.out.println("Packet capture started. Configure client to connect to 127.0.0.1:7778");
            System.out.println("Press Enter to stop...");
            System.in.read();
            
            // Остановка перехвата
            processor.stop();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Создание плагина

```java
import com.laprizmo.plugin.Plugin;
import com.laprizmo.plugin.PluginContext;

public class CustomPlugin implements Plugin {
    private PluginContext context;
    
    @Override
    public String getId() {
        return "custom-plugin";
    }
    
    @Override
    public String getName() {
        return "Custom Plugin";
    }
    
    @Override
    public String getVersion() {
        return "1.0.0";
    }
    
    @Override
    public void initialize(PluginContext context) throws Exception {
        this.context = context;
        
        // Получение логгера
        context.getLogger().info("Custom plugin initializing");
        
        // Регистрация обработчика события
        context.registerEventHandler("file.open", event -> {
            String filePath = (String) event.getValue("path");
            context.getLogger().info("File opened: " + filePath);
        });
        
        // Добавление пункта меню
        context.getUIAPI().addMenuItem("Tools", "Custom Plugin", e -> {
            // Действие при выборе пункта меню
            context.getUIAPI().showMessage("Custom Plugin", "Hello from Custom Plugin!");
        });
        
        context.getLogger().info("Custom plugin initialized successfully");
    }
    
    @Override
    public void shutdown() {
        context.getLogger().info("Custom plugin shutting down");
    }
}
```

## Расширения API

LaPrizmo поддерживает расширение API через плагины. Плагины могут:

1. Добавлять новые форматы файлов
2. Расширять криптографические алгоритмы
3. Добавлять новые компоненты интерфейса
4. Предоставлять новые инструменты для анализа

### Добавление обработчика файлов

```java
import com.laprizmo.core.GameFileProcessor;

public class CustomFileProcessor implements GameFileProcessor {
    @Override
    public void processFile(String inputFile, String outputFile, Map<String, Object> params) throws IOException {
        // Реализация обработки файла
    }
    
    @Override
    public boolean supportsFile(String filename) {
        // Проверка, поддерживается ли формат файла
        return filename.endsWith(".custom");
    }
    
    @Override
    public String getFormatDescription() {
        return "Custom file format";
    }
}
```

### Добавление нового алгоритма шифрования

```java
import com.laprizmo.crypto.CryptoAlgorithm;
import com.laprizmo.crypto.CryptoException;

public class CustomCrypto implements CryptoAlgorithm {
    @Override
    public byte[] encrypt(byte[] data) throws CryptoException {
        // Реализация шифрования
        return data;
    }
    
    @Override
    public byte[] decrypt(byte[] data) throws CryptoException {
        // Реализация дешифрования
        return data;
    }
    
    @Override
    public int getProtocolVersion() {
        return 999; // Пользовательская версия
    }
}
```

## Обратная совместимость

LaPrizmo стремится поддерживать обратную совместимость между версиями API. При обновлении версий:

- **Major версия (1.x.x → 2.0.0)**: Может содержать несовместимые изменения, требующие обновления кода
- **Minor версия (1.0.x → 1.1.0)**: Добавляет новую функциональность без нарушения обратной совместимости
- **Patch версия (1.0.0 → 1.0.1)**: Содержит только исправления ошибок

### Устаревшие методы

Методы, которые планируются к удалению в будущих версиях, помечаются аннотацией `@Deprecated`:

```java
/**
 * @deprecated Используйте {@link #newMethod()} вместо этого метода.
 *             Будет удален в версии 2.0.0.
 */
@Deprecated
public void oldMethod() {
    // Реализация
}

/**
 * Замена устаревшего метода.
 */
public void newMethod() {
    // Новая реализация
}
```

### Совместимость плагинов

Плагины, разработанные для определенной версии LaPrizmo, могут быть несовместимы с новыми версиями. Для обеспечения совместимости:

1. Плагины должны указывать минимальную и максимальную версию LaPrizmo, с которой они совместимы
2. LaPrizmo проверяет совместимость плагинов при загрузке
3. Несовместимые плагины не загружаются

Пример метаданных плагина:

```properties
plugin.name=Custom Plugin
plugin.version=1.0.0
plugin.minAppVersion=1.0.0
plugin.maxAppVersion=1.9.9
```
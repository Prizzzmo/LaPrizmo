# Руководство разработчика LaPrizmo

## Содержание

1. [Введение](#введение)
2. [Архитектура](#архитектура)
3. [Требования к среде разработки](#требования-к-среде-разработки)
4. [Настройка среды разработки](#настройка-среды-разработки)
5. [Структура проекта](#структура-проекта)
6. [Ключевые компоненты](#ключевые-компоненты)
7. [Система плагинов](#система-плагинов)
8. [Разработка пользовательского интерфейса](#разработка-пользовательского-интерфейса)
9. [Крипто-модули](#крипто-модули)
10. [Работа с сетевыми пакетами](#работа-с-сетевыми-пакетами)
11. [Обработка файлов](#обработка-файлов)
12. [Тестирование](#тестирование)
13. [Сборка проекта](#сборка-проекта)
14. [Вклад в проект](#вклад-в-проект)
15. [API документация](#api-документация)

## Введение

Данное руководство предназначено для разработчиков, которые хотят расширить функциональность LaPrizmo, разработать плагины или внести вклад в основной проект. Здесь вы найдете информацию об архитектуре, компонентах и API проекта.

LaPrizmo построен с использованием модульной архитектуры, что позволяет легко расширять и модифицировать различные компоненты системы. Проект написан на Java с использованием Java 11 в качестве минимальной версии.

## Архитектура

LaPrizmo использует многоуровневую архитектуру с четким разделением ответственности между компонентами:

```
+-----------------------------------+
|            Пользовательский интерфейс          |
|  (GUI, CLI, Web-интерфейс)        |
+-----------------------------------+
                 |
+-----------------------------------+
|         Бизнес-логика            |
| (Сервисы, Контроллеры, Утилиты)  |
+-----------------------------------+
                 |
+-----------------------------------+
|            Ядро                  |
| (Криптография, Сетевой код, I/O) |
+-----------------------------------+
                 |
+-----------------------------------+
|         Система плагинов         |
|   (Расширения, Адаптеры)         |
+-----------------------------------+
```

### Ключевые принципы архитектуры

1. **Модульность**: Все компоненты разделены на модули с четко определенными интерфейсами
2. **Инверсия зависимостей**: Высокоуровневые модули не зависят от низкоуровневых модулей, обе зависят от абстракций
3. **Слабая связанность**: Модули взаимодействуют через абстрактные интерфейсы
4. **Высокая когезия**: Связанная функциональность группируется вместе
5. **Расширяемость**: Архитектура поддерживает расширение через интерфейсы и плагины

### Взаимодействие компонентов

1. **Пользовательский интерфейс**:
   - Взаимодействует с бизнес-логикой через интерфейсы сервисов
   - Не имеет прямого доступа к ядру или компонентам плагинов

2. **Бизнес-логика**:
   - Координирует работу между пользовательским интерфейсом и ядром
   - Обрабатывает высокоуровневые бизнес-процессы
   - Управляет транзакциями и состоянием

3. **Ядро**:
   - Предоставляет базовую функциональность (криптография, сеть, I/O)
   - Не зависит от пользовательского интерфейса или бизнес-логики
   - Использует только общие интерфейсы для взаимодействия с другими модулями

4. **Система плагинов**:
   - Обеспечивает расширяемость всех уровней
   - Взаимодействует с ядром через стабильные API
   - Позволяет добавлять новую функциональность без изменения основного кода

## Требования к среде разработки

### Минимальные требования

- **Java Development Kit (JDK)**: 11 или выше
- **Maven**: 3.6.0 или выше
- **Git**: Для управления версиями
- **Интегрированная среда разработки (IDE)**: IntelliJ IDEA, Eclipse или NetBeans
- **Операционная система**: Windows, Linux или macOS

### Рекомендуемые инструменты

- **JDK**: Amazon Corretto 17 или OpenJDK 17
- **IDE**: IntelliJ IDEA Ultimate Edition
- **Дополнительные инструменты**:
  - **Gradle**: Альтернативная система сборки (опционально)
  - **Docker**: Для тестирования в изолированной среде
  - **SonarQube**: Для анализа качества кода
  - **JProfiler**: Для профилирования производительности

## Настройка среды разработки

### Настройка для IntelliJ IDEA

1. **Клонирование репозитория**:
   ```bash
   git clone https://github.com/username/laprizmo.git
   cd laprizmo
   ```

2. **Открытие проекта**:
   - Запустите IntelliJ IDEA
   - Выберите "Open" и укажите корневую директорию проекта
   - Выберите "Open as Project"

3. **Настройка JDK**:
   - Откройте "File" → "Project Structure"
   - В разделе "Project" выберите Java 11 или выше
   - Если нужной версии нет, нажмите "Add SDK" → "JDK" и укажите путь к JDK

4. **Настройка Maven**:
   - IntelliJ IDEA обычно автоматически определяет Maven
   - Для ручной настройки: "File" → "Settings" → "Build, Execution, Deployment" → "Build Tools" → "Maven"
   - Укажите путь к Maven и settings.xml при необходимости

5. **Установка плагинов для разработки**:
   - "File" → "Settings" → "Plugins"
   - Рекомендуемые плагины:
     - Lombok
     - SonarLint
     - Maven Helper
     - CheckStyle-IDEA
     - SpotBugs
     - JUnit

6. **Импорт стиля кода**:
   - "File" → "Settings" → "Editor" → "Code Style"
   - В разделе "Scheme" нажмите иконку шестеренки и выберите "Import Scheme" → "IntelliJ IDEA code style XML"
   - Выберите файл `codestyle.xml` из корня проекта

### Настройка для Eclipse

1. **Клонирование репозитория**:
   ```bash
   git clone https://github.com/username/laprizmo.git
   cd laprizmo
   ```

2. **Установка плагина Maven (m2e)**:
   - "Help" → "Eclipse Marketplace"
   - Найдите "Maven" и установите "m2e"

3. **Импорт проекта**:
   - "File" → "Import"
   - Выберите "Maven" → "Existing Maven Projects"
   - Укажите корневую директорию проекта и нажмите "Finish"

4. **Настройка JDK**:
   - Правый клик на проекте → "Properties" → "Java Build Path" → "Libraries"
   - Удалите существующий JRE System Library
   - Нажмите "Add Library" → "JRE System Library"
   - Выберите "Execution Environment" → "JavaSE-11" (или выше)

5. **Установка плагинов для разработки**:
   - "Help" → "Eclipse Marketplace"
   - Рекомендуемые плагины:
     - Lombok
     - SonarLint
     - CheckStyle
     - SpotBugs

## Структура проекта

LaPrizmo организован как многомодульный Maven проект со следующей структурой:

```
laprizmo/
├── config/                  # Конфигурационные файлы
├── logs/                    # Директория для журналов
├── docs/                    # Документация
├── src/                     # Исходный код
│   ├── main/                # Основной код
│   │   ├── java/            # Java-код
│   │   │   └── com/
│   │   │       └── laprizmo/
│   │   │           ├── cli/            # Компоненты командной строки
│   │   │           ├── config/         # Конфигурация
│   │   │           ├── core/           # Ядро приложения
│   │   │           ├── crypto/         # Криптографические алгоритмы
│   │   │           │   ├── aes/        # Реализации AES
│   │   │           │   ├── blowfish/   # Реализации Blowfish
│   │   │           │   ├── lamecrypt/  # Реализации Lamecrypt
│   │   │           │   ├── rsa/        # Реализации RSA
│   │   │           │   ├── xor/        # Реализации XOR
│   │   │           ├── network/        # Сетевые компоненты
│   │   │           ├── plugin/         # Система плагинов
│   │   │           ├── ui/             # Пользовательский интерфейс
│   │   │           │   ├── components/ # UI компоненты
│   │   │           │   ├── panels/     # UI панели
│   │   │           ├── util/           # Утилиты
│   │   │           └── LaPrizmoApp.java # Точка входа
│   │   └── resources/      # Ресурсы
│   └── test/               # Тесты
├── plugins/                # Директория для плагинов
├── pom.xml                 # Maven POM файл
├── .gitignore              # Git ignore файл
├── README.md               # Readme файл
└── LICENSE                 # Лицензия
```

## Ключевые компоненты

### Пакет `com.laprizmo.core`

Содержит ядро приложения, включая базовые классы и интерфейсы:

- **CryptoEngine**: Основной движок для криптографических операций
- **CryptoOperations**: Выполняет операции шифрования/дешифрования
- **ProtocolManager**: Управляет различными протоколами Lineage 2
- **ProtocolDetector**: Определяет версию протокола файла
- **GameFileProcessor**: Обрабатывает игровые файлы

#### Пример использования `CryptoEngine`

```java
// Получение экземпляра CryptoEngine
CryptoEngine engine = CryptoEngine.getInstance();

// Создание параметров шифрования
CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
params.setProtocolVersion(120);
params.setCryptoType(CryptoOperations.CryptoType.XOR);
params.setCompressed(false);

// Шифрование файла
engine.encryptFile("input.dat", "output.dat", params);
```

### Пакет `com.laprizmo.crypto`

Содержит реализации различных криптографических алгоритмов, используемых в Lineage 2.

#### Интерфейсы

- **CryptoAlgorithm**: Базовый интерфейс для всех алгоритмов шифрования
- **FinishableOutputStream**: Интерфейс для потоков с завершением операций

#### Реализации

- **XOR**: Пакет `com.laprizmo.crypto.xor` с реализациями алгоритма XOR
- **Blowfish**: Пакет `com.laprizmo.crypto.blowfish` с реализациями Blowfish
- **RSA**: Пакет `com.laprizmo.crypto.rsa` с реализациями RSA и EnhancedRSAConfig
- **AES**: Пакет `com.laprizmo.crypto.aes` с реализациями AES
- **Lamecrypt**: Пакет `com.laprizmo.crypto.lamecrypt` с реализациями Lamecrypt

#### Пример создания шифра XOR

```java
// Создание экземпляра XOR шифра для протокола 120
L2Ver120 xorCipher = new L2Ver120();

// Настройка шифра
xorCipher.setKey(new byte[] { /* ключ */ });

// Использование для шифрования
byte[] plaintext = new byte[] { /* данные */ };
byte[] encrypted = xorCipher.encrypt(plaintext);

// Использование для дешифрования
byte[] decrypted = xorCipher.decrypt(encrypted);
```

### Пакет `com.laprizmo.network`

Содержит компоненты для работы с сетевыми пакетами:

- **L2Packet**: Представление сетевого пакета Lineage 2
- **LivePacketProcessor**: Обработка пакетов в реальном времени
- **PacketAnalyzer**: Анализ структуры и содержимого пакетов

#### Пример использования `PacketAnalyzer`

```java
// Создание анализатора
PacketAnalyzer analyzer = new PacketAnalyzer();

// Установка версии протокола
analyzer.setProtocolVersion(413);

// Анализ пакета
L2Packet packet = new L2Packet(rawData, L2Packet.Direction.CLIENT_TO_SERVER);
PacketAnalyzer.PacketInfo info = analyzer.analyzePacket(packet);

// Получение информации о пакете
System.out.println("Packet type: " + info.getType());
System.out.println("Fields: " + info.getFields());
```

### Пакет `com.laprizmo.plugin`

Содержит компоненты системы плагинов:

- **Plugin**: Интерфейс, который должен реализовывать каждый плагин
- **PluginManager**: Управляет загрузкой и использованием плагинов
- **PluginContext**: Предоставляет плагинам доступ к API приложения

### Пакет `com.laprizmo.ui`

Содержит компоненты пользовательского интерфейса:

- **LaPrizmoGUI**: Главное окно приложения
- **components**: Пакет с переиспользуемыми UI компонентами
- **panels**: Пакет с панелями для различных функций

### Пакет `com.laprizmo.util`

Содержит различные утилитарные классы:

- **BatchProcessor**: Обработка множества файлов
- **ZlibUtils**: Утилиты для сжатия данных
- **DatFileUtils**: Утилиты для работы с DAT-файлами

## Система плагинов

LaPrizmo предоставляет мощную систему плагинов для расширения функциональности без изменения основного кода.

### Интерфейс Plugin

Каждый плагин должен реализовывать интерфейс `com.laprizmo.plugin.Plugin`:

```java
public interface Plugin {
    /**
     * Возвращает уникальный идентификатор плагина.
     */
    String getId();
    
    /**
     * Возвращает отображаемое имя плагина.
     */
    String getName();
    
    /**
     * Возвращает версию плагина.
     */
    String getVersion();
    
    /**
     * Инициализирует плагин.
     * 
     * @param context контекст плагина
     * @throws Exception если произошла ошибка инициализации
     */
    void initialize(PluginContext context) throws Exception;
    
    /**
     * Завершает работу плагина.
     */
    void shutdown();
}
```

### Контекст плагина

Через `PluginContext` плагин получает доступ к API приложения:

```java
public interface PluginContext {
    /**
     * Возвращает API ядра приложения.
     */
    CoreAPI getCoreAPI();
    
    /**
     * Возвращает API пользовательского интерфейса.
     */
    UIAPI getUIAPI();
    
    /**
     * Возвращает API сетевого модуля.
     */
    NetworkAPI getNetworkAPI();
    
    /**
     * Возвращает API файлового модуля.
     */
    FileAPI getFileAPI();
    
    /**
     * Регистрирует обработчик события.
     */
    void registerEventHandler(String eventType, EventHandler handler);
    
    /**
     * Получает настройки плагина.
     */
    PluginSettings getSettings();
}
```

### Пример создания плагина

```java
package com.example.plugin;

import com.laprizmo.plugin.Plugin;
import com.laprizmo.plugin.PluginContext;

public class ExamplePlugin implements Plugin {
    private PluginContext context;
    
    @Override
    public String getId() {
        return "example-plugin";
    }
    
    @Override
    public String getName() {
        return "Example Plugin";
    }
    
    @Override
    public String getVersion() {
        return "1.0.0";
    }
    
    @Override
    public void initialize(PluginContext context) throws Exception {
        this.context = context;
        
        // Регистрация обработчиков событий
        context.registerEventHandler("file.open", event -> {
            System.out.println("File opened: " + event.getData());
        });
        
        // Добавление пунктов меню
        context.getUIAPI().addMenuItem("Tools", "Example Plugin", e -> {
            // Обработчик пункта меню
            context.getUIAPI().showMessage("Example Plugin", "Hello from Example Plugin!");
        });
    }
    
    @Override
    public void shutdown() {
        // Освобождение ресурсов при выгрузке плагина
    }
}
```

### Структура плагина

Плагин должен быть упакован как JAR-файл со следующей структурой:

```
example-plugin.jar
├── META-INF/
│   └── MANIFEST.MF             # С указанием Plugin-Class
├── com/
│   └── example/
│       └── plugin/
│           └── ExamplePlugin.class
└── plugin.properties           # Свойства плагина
```

Файл `MANIFEST.MF` должен содержать:

```
Manifest-Version: 1.0
Plugin-Class: com.example.plugin.ExamplePlugin
Plugin-Id: example-plugin
Plugin-Version: 1.0.0
Plugin-Provider: Example Developer
Plugin-Dependencies: another-plugin;resolution:=optional
```

Файл `plugin.properties` может содержать дополнительные настройки плагина:

```properties
plugin.name=Example Plugin
plugin.description=An example plugin for LaPrizmo
plugin.author=Example Developer
plugin.website=https://example.com/plugin
plugin.minAppVersion=1.0.0
```

### Жизненный цикл плагина

1. **Загрузка**: PluginManager находит JAR-файл плагина и загружает его
2. **Валидация**: Проверяется совместимость и зависимости
3. **Инициализация**: Вызывается метод `initialize()` с передачей контекста
4. **Использование**: Плагин выполняет свою функциональность
5. **Выгрузка**: При выгрузке плагина вызывается метод `shutdown()`

## Разработка пользовательского интерфейса

LaPrizmo использует Swing для создания пользовательского интерфейса. Компоненты UI организованы в модульную структуру для облегчения разработки и сопровождения.

### Основные UI-компоненты

- **LaPrizmoGUI**: Главное окно приложения
- **HexViewer**: Компонент для просмотра и редактирования данных в шестнадцатеричном формате
- **ProgressIndicator**: Компонент для отображения прогресса операций
- **PacketViewer**: Компонент для просмотра сетевых пакетов
- **DatFileViewer**: Компонент для просмотра структуры DAT-файлов

### Создание нового компонента интерфейса

```java
package com.laprizmo.ui.components;

import javax.swing.*;
import java.awt.*;

public class CustomComponent extends JPanel {
    private final JLabel titleLabel;
    private final JButton actionButton;
    
    public CustomComponent() {
        setLayout(new BorderLayout());
        
        titleLabel = new JLabel("Custom Component");
        titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        
        actionButton = new JButton("Action");
        actionButton.addActionListener(e -> performAction());
        
        add(titleLabel, BorderLayout.NORTH);
        add(actionButton, BorderLayout.SOUTH);
    }
    
    private void performAction() {
        // Логика действия
    }
    
    public void setTitle(String title) {
        titleLabel.setText(title);
    }
    
    public void setActionText(String text) {
        actionButton.setText(text);
    }
}
```

### Добавление компонента в панель

```java
package com.laprizmo.ui.panels;

import com.laprizmo.ui.components.CustomComponent;
import javax.swing.*;
import java.awt.*;

public class CustomPanel extends JPanel {
    private final CustomComponent customComponent;
    
    public CustomPanel() {
        setLayout(new BorderLayout());
        
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.add(new JButton("New"));
        toolBar.add(new JButton("Open"));
        toolBar.add(new JButton("Save"));
        
        customComponent = new CustomComponent();
        customComponent.setTitle("Custom Panel Component");
        
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.add(new JLabel("Ready"), BorderLayout.WEST);
        
        add(toolBar, BorderLayout.NORTH);
        add(customComponent, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);
    }
    
    public void initialize() {
        // Инициализация панели
    }
    
    public void refresh() {
        // Обновление содержимого
    }
}
```

### Рекомендации по UI-разработке

1. **Отделяйте UI от логики**: Используйте MVC или MVP паттерны
2. **Используйте компоненты многократно**: Создавайте переиспользуемые компоненты
3. **Поддерживайте темы**: Используйте UI-константы и настраиваемые темы
4. **Следите за масштабированием**: Компоненты должны корректно масштабироваться
5. **Создавайте доступный интерфейс**: Учитывайте вопросы доступности

## Крипто-модули

Модули шифрования в LaPrizmo реализуют различные алгоритмы, используемые в Lineage 2.

### Базовый интерфейс шифрования

```java
package com.laprizmo.crypto;

public interface CryptoAlgorithm {
    /**
     * Шифрует данные.
     * 
     * @param data данные для шифрования
     * @return зашифрованные данные
     */
    byte[] encrypt(byte[] data) throws CryptoException;
    
    /**
     * Дешифрует данные.
     * 
     * @param data данные для дешифрования
     * @return дешифрованные данные
     */
    byte[] decrypt(byte[] data) throws CryptoException;
    
    /**
     * Возвращает версию протокола, поддерживаемую этим алгоритмом.
     */
    int getProtocolVersion();
}
```

### Реализация алгоритма XOR

XOR — один из самых простых алгоритмов шифрования, используемых в ранних версиях Lineage 2.

```java
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.CryptoAlgorithm;
import com.laprizmo.crypto.CryptoException;

public class L2Ver120 implements CryptoAlgorithm {
    private byte[] key;
    
    public L2Ver120() {
        // Инициализация с ключом по умолчанию для версии 120
        this.key = new byte[] { 
            (byte)0x94, (byte)0x35, (byte)0x00, (byte)0x00, (byte)0xa1, (byte)0x6c, (byte)0x54, (byte)0x87
        };
    }
    
    public void setKey(byte[] key) {
        this.key = key;
    }
    
    @Override
    public byte[] encrypt(byte[] data) throws CryptoException {
        if (data == null) {
            return null;
        }
        
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte)(data[i] ^ key[i % key.length]);
        }
        
        return result;
    }
    
    @Override
    public byte[] decrypt(byte[] data) throws CryptoException {
        // XOR симметричен, поэтому шифрование и дешифрование идентичны
        return encrypt(data);
    }
    
    @Override
    public int getProtocolVersion() {
        return 120;
    }
}
```

### Реализация потоков ввода-вывода

Для эффективной обработки больших файлов LaPrizmo использует собственные реализации потоков ввода-вывода:

```java
package com.laprizmo.crypto.xor;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class L2Ver120InputStream extends FilterInputStream {
    private final byte[] key;
    private int position;
    
    public L2Ver120InputStream(InputStream in) {
        super(in);
        // Ключ по умолчанию для версии 120
        this.key = new byte[] { 
            (byte)0x94, (byte)0x35, (byte)0x00, (byte)0x00, (byte)0xa1, (byte)0x6c, (byte)0x54, (byte)0x87
        };
        this.position = 0;
    }
    
    @Override
    public int read() throws IOException {
        int b = super.read();
        if (b == -1) {
            return -1;
        }
        
        int result = b ^ key[position % key.length];
        position++;
        return result & 0xFF;
    }
    
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int bytesRead = super.read(b, off, len);
        if (bytesRead == -1) {
            return -1;
        }
        
        for (int i = 0; i < bytesRead; i++) {
            b[off + i] = (byte)(b[off + i] ^ key[(position + i) % key.length]);
        }
        
        position += bytesRead;
        return bytesRead;
    }
}
```

### Создание нового модуля шифрования

Если вам нужно добавить поддержку нового алгоритма шифрования:

1. Создайте новый пакет в `com.laprizmo.crypto` (например, `com.laprizmo.crypto.newcrypto`)
2. Реализуйте интерфейс `CryptoAlgorithm`
3. При необходимости создайте потоки ввода-вывода
4. Зарегистрируйте алгоритм в `ProtocolManager`

## Работа с сетевыми пакетами

LaPrizmo предоставляет мощные инструменты для работы с сетевыми пакетами Lineage 2.

### Структура пакета

```java
package com.laprizmo.network;

public class L2Packet {
    public enum Direction {
        CLIENT_TO_SERVER,
        SERVER_TO_CLIENT
    }
    
    private final byte[] rawData;
    private final Direction direction;
    private final long timestamp;
    private int opcode;
    private byte[] payload;
    
    public L2Packet(byte[] rawData, Direction direction) {
        this.rawData = rawData;
        this.direction = direction;
        this.timestamp = System.currentTimeMillis();
        parsePacket();
    }
    
    private void parsePacket() {
        // Извлечение opcode и payload из rawData
        if (rawData.length >= 2) {
            opcode = rawData[0] & 0xFF;
            payload = new byte[rawData.length - 1];
            System.arraycopy(rawData, 1, payload, 0, payload.length);
        } else {
            opcode = 0;
            payload = new byte[0];
        }
    }
    
    public byte[] getRawData() {
        return rawData;
    }
    
    public Direction getDirection() {
        return direction;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public int getOpcode() {
        return opcode;
    }
    
    public byte[] getPayload() {
        return payload;
    }
}
```

### Анализатор пакетов

```java
package com.laprizmo.network;

import java.util.HashMap;
import java.util.Map;

public class PacketAnalyzer {
    public static class PacketInfo {
        private final String type;
        private final Map<String, Object> fields;
        
        public PacketInfo(String type) {
            this.type = type;
            this.fields = new HashMap<>();
        }
        
        public void addField(String name, Object value) {
            fields.put(name, value);
        }
        
        public String getType() {
            return type;
        }
        
        public Map<String, Object> getFields() {
            return fields;
        }
    }
    
    private final Map<Integer, PacketDefinition> clientPackets;
    private final Map<Integer, PacketDefinition> serverPackets;
    private int protocolVersion;
    
    public PacketAnalyzer() {
        this.clientPackets = new HashMap<>();
        this.serverPackets = new HashMap<>();
        this.protocolVersion = 120; // По умолчанию
        
        loadPacketDefinitions();
    }
    
    public void setProtocolVersion(int protocolVersion) {
        this.protocolVersion = protocolVersion;
        loadPacketDefinitions();
    }
    
    private void loadPacketDefinitions() {
        // Загрузка определений пакетов для текущей версии протокола
        // ...
    }
    
    public PacketInfo analyzePacket(L2Packet packet) {
        Map<Integer, PacketDefinition> definitions;
        
        if (packet.getDirection() == L2Packet.Direction.CLIENT_TO_SERVER) {
            definitions = clientPackets;
        } else {
            definitions = serverPackets;
        }
        
        PacketDefinition definition = definitions.get(packet.getOpcode());
        if (definition == null) {
            return new PacketInfo("Unknown (" + packet.getOpcode() + ")");
        }
        
        PacketInfo info = new PacketInfo(definition.getName());
        
        // Разбор полей пакета
        byte[] payload = packet.getPayload();
        parseFields(payload, definition.getFields(), info);
        
        return info;
    }
    
    private void parseFields(byte[] data, List<FieldDefinition> fieldDefinitions, PacketInfo info) {
        // Разбор полей на основе их определений
        // ...
    }
    
    private static class PacketDefinition {
        private final String name;
        private final List<FieldDefinition> fields;
        
        // ...
    }
    
    private static class FieldDefinition {
        private final String name;
        private final String type;
        private final int offset;
        
        // ...
    }
}
```

### Обработка пакетов в реальном времени

```java
package com.laprizmo.network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LivePacketProcessor {
    public interface PacketListener {
        void onPacketReceived(L2Packet packet);
    }
    
    public interface PacketFilter {
        boolean accept(L2Packet packet);
    }
    
    private final String serverHost;
    private final int serverPort;
    private final int localPort;
    private final int protocolVersion;
    
    private ServerSocket serverSocket;
    private ExecutorService executorService;
    private boolean running;
    
    private final List<PacketListener> listeners;
    private final List<PacketFilter> filters;
    
    public LivePacketProcessor(String serverHost, int serverPort, int localPort, int protocolVersion) {
        this.serverHost = serverHost;
        this.serverPort = serverPort;
        this.localPort = localPort;
        this.protocolVersion = protocolVersion;
        
        this.listeners = new ArrayList<>();
        this.filters = new ArrayList<>();
    }
    
    public void addListener(PacketListener listener) {
        listeners.add(listener);
    }
    
    public void removeListener(PacketListener listener) {
        listeners.remove(listener);
    }
    
    public void addFilter(PacketFilter filter) {
        filters.add(filter);
    }
    
    public void removeFilter(PacketFilter filter) {
        filters.remove(filter);
    }
    
    public void start() throws IOException {
        if (running) {
            return;
        }
        
        serverSocket = new ServerSocket(localPort);
        executorService = Executors.newCachedThreadPool();
        running = true;
        
        executorService.submit(() -> {
            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    handleClient(clientSocket);
                } catch (IOException e) {
                    if (running) {
                        // Логирование ошибки
                    }
                }
            }
        });
    }
    
    public void stop() {
        running = false;
        
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // Логирование ошибки
            }
        }
        
        if (executorService != null) {
            executorService.shutdown();
        }
    }
    
    private void handleClient(Socket clientSocket) {
        // Установка соединения с сервером и обработка пакетов
        // ...
    }
    
    private void processPacket(L2Packet packet) {
        // Применение фильтров
        boolean accepted = true;
        for (PacketFilter filter : filters) {
            if (!filter.accept(packet)) {
                accepted = false;
                break;
            }
        }
        
        if (!accepted) {
            return;
        }
        
        // Уведомление слушателей
        for (PacketListener listener : listeners) {
            listener.onPacketReceived(packet);
        }
    }
}
```

## Обработка файлов

LaPrizmo предоставляет множество утилит для работы с файлами, включая пакетную обработку и специализированные функции для DAT-файлов.

### Пакетная обработка файлов

```java
package com.laprizmo.util;

import com.laprizmo.core.CryptoOperations;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class BatchProcessor {
    
    public static class ProgressInfo {
        private final int totalFiles;
        private final int processedFiles;
        private final int successfulFiles;
        private final int failedFiles;
        
        // ...
    }
    
    private final CryptoOperations cryptoOperations;
    private final CryptoOperations.CryptoParams params;
    private String outputDirectory;
    private boolean preserveDirectoryStructure = true;
    private boolean overwriteExisting = false;
    private int maxThreads = Runtime.getRuntime().availableProcessors();
    private Pattern fileFilter;
    private Consumer<ProgressInfo> progressHandler;
    private volatile boolean cancelled = false;
    
    public BatchProcessor(CryptoOperations cryptoOperations, CryptoOperations.CryptoParams params) {
        this.cryptoOperations = cryptoOperations;
        this.params = params;
    }
    
    public BatchProcessor setOutputDirectory(String outputDirectory) {
        this.outputDirectory = outputDirectory;
        return this;
    }
    
    public BatchProcessor setPreserveDirectoryStructure(boolean preserve) {
        this.preserveDirectoryStructure = preserve;
        return this;
    }
    
    public BatchProcessor setOverwriteExisting(boolean overwrite) {
        this.overwriteExisting = overwrite;
        return this;
    }
    
    public BatchProcessor setMaxThreads(int maxThreads) {
        this.maxThreads = maxThreads > 0 ? maxThreads : Runtime.getRuntime().availableProcessors();
        return this;
    }
    
    public BatchProcessor setFileFilter(String regex) {
        if (regex != null && !regex.isEmpty()) {
            this.fileFilter = Pattern.compile(regex);
        } else {
            this.fileFilter = null;
        }
        return this;
    }
    
    public BatchProcessor setProgressHandler(Consumer<ProgressInfo> progressHandler) {
        this.progressHandler = progressHandler;
        return this;
    }
    
    public void cancel() {
        this.cancelled = true;
    }
    
    public boolean isCancelled() {
        return cancelled;
    }
    
    public void resetCancel() {
        this.cancelled = false;
    }
    
    public int process(String inputPath, boolean isEncrypt) throws IOException {
        // Реализация пакетной обработки
        // ...
    }
    
    private void processFile(String inputPath, String outputPath, boolean isEncrypt, 
                             int[] processed, int[] successful, int[] failed, 
                             long[] processedBytes, long totalBytes) {
        // Обработка одного файла
        // ...
    }
    
    private List<File> collectFiles(String path) {
        // Сбор файлов для обработки
        // ...
    }
    
    private String determineOutputPath(String relativePath) {
        // Определение пути к выходному файлу
        // ...
    }
}
```

### Работа с DAT-файлами

```java
package com.laprizmo.util;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class DatFileUtils {
    
    public static class DatChunk {
        private final String id;
        private final int size;
        private final long offset;
        private String type;
        private final List<DatChunk> children;
        
        // ...
    }
    
    public static DatChunk analyzeDatFile(String filename) throws IOException {
        // Анализ структуры DAT-файла
        // ...
    }
    
    private static void readChunks(RandomAccessFile raf, long offset, int size, DatChunk parent) throws IOException {
        // Рекурсивное чтение разделов DAT-файла
        // ...
    }
    
    public static byte[] extractChunkData(String filename, DatChunk chunk) throws IOException {
        // Извлечение данных раздела
        // ...
    }
    
    public static List<String> extractFileNames(byte[] nameData) {
        // Извлечение имен файлов из раздела NAME
        // ...
    }
    
    public static List<byte[]> extractFileData(byte[] data, int fileCount) {
        // Извлечение данных файлов из раздела DATA
        // ...
    }
    
    public static String generateDatReport(String filename) throws IOException {
        // Генерация отчета о структуре DAT-файла
        // ...
    }
}
```

## Тестирование

LaPrizmo использует JUnit 5 для модульного и интеграционного тестирования.

### Пример модульного теста

```java
package com.laprizmo.crypto.xor;

import com.laprizmo.crypto.CryptoException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class L2Ver120Test {
    
    private L2Ver120 cipher;
    private byte[] testKey;
    
    @BeforeEach
    public void setUp() {
        cipher = new L2Ver120();
        testKey = new byte[] {
            (byte)0x94, (byte)0x35, (byte)0x00, (byte)0x00,
            (byte)0xa1, (byte)0x6c, (byte)0x54, (byte)0x87
        };
        cipher.setKey(testKey);
    }
    
    @Test
    public void testEncryption() throws CryptoException {
        // Подготовка данных
        byte[] plaintext = "Test message".getBytes(StandardCharsets.UTF_8);
        
        // Выполнение операции
        byte[] encrypted = cipher.encrypt(plaintext);
        
        // Проверка результата
        assertNotNull(encrypted);
        assertNotEquals(plaintext, encrypted);
        
        // Проверка соответствия ожидаемому результату
        byte[] expected = new byte[plaintext.length];
        for (int i = 0; i < plaintext.length; i++) {
            expected[i] = (byte)(plaintext[i] ^ testKey[i % testKey.length]);
        }
        assertArrayEquals(expected, encrypted);
    }
    
    @Test
    public void testDecryption() throws CryptoException {
        // Подготовка данных
        byte[] plaintext = "Another test".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = cipher.encrypt(plaintext);
        
        // Выполнение операции
        byte[] decrypted = cipher.decrypt(encrypted);
        
        // Проверка результата
        assertNotNull(decrypted);
        assertArrayEquals(plaintext, decrypted);
    }
    
    @Test
    public void testEmptyData() throws CryptoException {
        // Пустой массив
        byte[] empty = new byte[0];
        byte[] result = cipher.encrypt(empty);
        
        assertNotNull(result);
        assertEquals(0, result.length);
        
        // Null
        assertNull(cipher.encrypt(null));
    }
    
    @Test
    public void testGetProtocolVersion() {
        assertEquals(120, cipher.getProtocolVersion());
    }
}
```

### Пример интеграционного теста

```java
package com.laprizmo.core;

import com.laprizmo.crypto.CryptoException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

public class CryptoEngineIntegrationTest {
    
    @TempDir
    Path tempDir;
    
    private CryptoEngine engine;
    private Path originalFile;
    private Path encryptedFile;
    private Path decryptedFile;
    
    @BeforeEach
    public void setUp() throws IOException {
        engine = CryptoEngine.getInstance();
        
        // Создаем тестовый файл
        originalFile = tempDir.resolve("original.dat");
        Files.write(originalFile, "Test data for encryption".getBytes());
        
        encryptedFile = tempDir.resolve("encrypted.dat");
        decryptedFile = tempDir.resolve("decrypted.dat");
    }
    
    @Test
    public void testEncryptDecryptCycle() throws IOException, CryptoException {
        // Создаем параметры
        CryptoOperations.CryptoParams params = new CryptoOperations.CryptoParams();
        params.setProtocolVersion(120);
        params.setCryptoType(CryptoOperations.CryptoType.XOR);
        
        // Шифруем файл
        engine.encryptFile(originalFile.toString(), encryptedFile.toString(), params);
        
        // Проверяем, что зашифрованный файл существует и отличается от оригинала
        assertTrue(Files.exists(encryptedFile));
        assertFalse(Files.mismatch(originalFile, encryptedFile) == -1);
        
        // Дешифруем файл
        engine.decryptFile(encryptedFile.toString(), decryptedFile.toString(), params);
        
        // Проверяем, что дешифрованный файл совпадает с оригиналом
        assertTrue(Files.exists(decryptedFile));
        assertEquals(-1, Files.mismatch(originalFile, decryptedFile));
    }
    
    @Test
    public void testAutoDetectProtocol() throws IOException, CryptoException {
        // Создаем параметры для шифрования
        CryptoOperations.CryptoParams encParams = new CryptoOperations.CryptoParams();
        encParams.setProtocolVersion(212);
        encParams.setCryptoType(CryptoOperations.CryptoType.BLOWFISH);
        
        // Шифруем файл
        engine.encryptFile(originalFile.toString(), encryptedFile.toString(), encParams);
        
        // Создаем пустые параметры для автоопределения
        CryptoOperations.CryptoParams decParams = new CryptoOperations.CryptoParams();
        
        // Дешифруем файл с автоопределением
        engine.decryptFile(encryptedFile.toString(), decryptedFile.toString(), decParams);
        
        // Проверяем, что дешифрованный файл совпадает с оригиналом
        assertEquals(-1, Files.mismatch(originalFile, decryptedFile));
        
        // Проверяем, что параметры были определены верно
        assertEquals(212, decParams.getProtocolVersion());
        assertEquals(CryptoOperations.CryptoType.BLOWFISH, decParams.getCryptoType());
    }
}
```

### Рекомендации по тестированию

1. **Изолируйте тесты**: Каждый тест должен быть независимым от других
2. **Используйте моки**: Для изоляции внешних зависимостей (например, с Mockito)
3. **Тестируйте граничные условия**: Пустые данные, большие данные, ошибочные данные
4. **Используйте параметризованные тесты**: Для проверки разных входных данных
5. **Добавляйте интеграционные тесты**: Для проверки взаимодействия компонентов
6. **Проверяйте производительность**: С использованием JMH для критичных к производительности компонентов

## Сборка проекта

LaPrizmo использует Maven для сборки. Вот основные команды для работы с проектом:

### Компиляция

```bash
mvn compile
```

### Запуск тестов

```bash
mvn test
```

### Сборка JAR-файла

```bash
mvn package
```

### Сборка с пропуском тестов

```bash
mvn package -DskipTests
```

### Сборка с документацией и всеми зависимостями

```bash
mvn package javadoc:javadoc assembly:single
```

### Очистка проекта

```bash
mvn clean
```

### Установка в локальный репозиторий

```bash
mvn install
```

### Проверка зависимостей

```bash
mvn dependency:analyze
```

## Вклад в проект

Если вы хотите внести свой вклад в LaPrizmo, пожалуйста, следуйте этим рекомендациям:

### Процесс внесения изменений

1. **Форкните репозиторий** на GitHub
2. **Клонируйте свой форк** на локальную машину
3. **Создайте новую ветку** для ваших изменений
4. **Внесите изменения** и добавьте тесты
5. **Убедитесь, что все тесты проходят**: `mvn test`
6. **Отформатируйте код** в соответствии с принятым стилем
7. **Закоммитите изменения** с понятным сообщением коммита
8. **Отправьте ветку** в ваш форк на GitHub
9. **Создайте Pull Request** в основной репозиторий

### Стандарты кодирования

1. **Следуйте Java Code Conventions**
2. **Используйте преимущественно английский язык** для комментариев и документации
3. **Добавляйте Javadoc комментарии** для публичных API
4. **Пишите тесты** для вашего кода
5. **Соблюдайте принципы SOLID**
6. **Используйте паттерны проектирования** там, где это уместно

### Рекомендации по Pull Request

1. **Один Pull Request — одна функция**: Избегайте комбинирования не связанных изменений
2. **Объясните ваши изменения**: Предоставьте понятное описание
3. **Упомяните проблемы**: Укажите номера задач, которые решает ваш PR
4. **Проверяйте CI/CD**: Убедитесь, что все автоматические проверки проходят

## API документация

Подробная документация API доступна в JavaDoc формате. Вы можете сгенерировать ее с помощью Maven:

```bash
mvn javadoc:javadoc
```

Документация будет доступна в директории `target/site/apidocs/`.

### Основные пакеты API

1. **com.laprizmo.core**: Ядро приложения
2. **com.laprizmo.crypto**: Криптографические алгоритмы
3. **com.laprizmo.plugin**: API плагинов
4. **com.laprizmo.network**: Компоненты для работы с сетью
5. **com.laprizmo.ui**: Компоненты пользовательского интерфейса
6. **com.laprizmo.util**: Утилитарные классы

### Пример использования API

```java
import com.laprizmo.core.CryptoEngine;
import com.laprizmo.core.CryptoOperations;
import com.laprizmo.core.ProtocolDetector;

public class ApiExample {
    public static void main(String[] args) {
        try {
            // Анализ файла
            ProtocolDetector.ProtocolInfo info = ProtocolDetector.detectProtocol("input.dat");
            System.out.println("Detected protocol: " + info.getProtocolVersion());
            System.out.println("Crypto type: " + info.getCryptoType());
            
            // Создание параметров на основе обнаруженной информации
            CryptoOperations.CryptoParams params = 
                ProtocolDetector.createCryptoParams(info);
            
            // Получение экземпляра CryptoEngine
            CryptoEngine engine = CryptoEngine.getInstance();
            
            // Дешифрование файла
            engine.decryptFile("input.dat", "output.dat", params);
            
            System.out.println("File decrypted successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

## Заключение

Это руководство предоставляет основную информацию для разработчиков, работающих с LaPrizmo. Для более подробной информации обратитесь к JavaDoc документации и исходному коду.

Если у вас есть вопросы или предложения по улучшению этого руководства, пожалуйста, создайте issue в репозитории проекта.